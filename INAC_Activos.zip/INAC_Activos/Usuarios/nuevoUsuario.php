<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
if ($rolActual !== 'Administrador') {
    http_response_code(403);
    exit('No tienes permiso para registrar usuarios.');
}
if (empty($_SESSION['csrf_usuarios'])) {
    $_SESSION['csrf_usuarios'] = bin2hex(random_bytes(32));
}
$roles = mysqli_query(
    $conn,
    "SELECT id_rol, nombre_rol FROM rol ORDER BY id_rol"
);
if (!$roles) {
    exit('No se pudieron consultar los roles.');
}
function h($valor) {
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}
$errores = [
    'datos' => 'Completa todos los campos obligatorios.',
    'usuario' => 'Ese nombre de usuario ya está registrado.',
    'contrasena' => 'La contraseña debe tener entre 8 y 72 bytes.',
    'rol' => 'Selecciona un rol válido.',
    'nombre' => 'El nombre y apellido solo deben contener letras, espacios, puntos, apóstrofes o guiones.',
    'formato' => 'El usuario solo admite letras sin tildes, números, puntos, guiones y guiones bajos.',
    'token' => 'La solicitud expiró. Intenta nuevamente.',
    'guardar' => 'No se pudo registrar el usuario.'
];
$error = $errores[$_GET['error'] ?? ''] ?? '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registrar usuario | INAC Activos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../style.css" rel="stylesheet">
</head>
<body>
<main class="container py-4">
    <h2>Registrar usuario</h2>
    <p class="text-secondary">Completa los datos de la nueva cuenta.</p>
    <?php if ($error !== ''): ?>
        <div class="alert alert-danger"><?= h($error) ?></div>
    <?php endif; ?>
    <section class="card">
        <form method="POST" action="guardarUsuario.php">
            <input type="hidden" name="csrf_token"
                   value="<?= h($_SESSION['csrf_usuarios']) ?>">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="nombre" class="form-label">Nombre *</label>
                    <input class="form-control" type="text" id="nombre"
                           name="nombre" maxlength="100"
                           autocomplete="given-name" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="apellido" class="form-label">Apellido *</label>
                    <input class="form-control" type="text" id="apellido"
                           name="apellido" maxlength="100"
                           autocomplete="family-name" required>
                </div>
            </div>
            <div class="mb-3">
                <label for="usuario" class="form-label">Nombre de usuario *</label>
                <input class="form-control" type="text" id="usuario"
                       name="usuario" maxlength="50"
                       pattern="[A-Za-z0-9._-]+"
                       title="Usa letras sin tildes, números, puntos, guiones o guiones bajos."
                       autocomplete="username" required>
            </div>
            <div class="mb-3">
                <label for="contrasena" class="form-label">Contraseña *</label>
                <input class="form-control" type="password" id="contrasena"
                       name="contrasena" minlength="8" maxlength="72"
                       autocomplete="new-password" required>
                <small class="text-secondary">
                    Debe tener al menos 8 caracteres.
                </small>
            </div>
            <div class="mb-3">
                <label for="id_rol" class="form-label">Rol *</label>
                <select class="form-select" id="id_rol" name="id_rol" required>
                    <option value="">Selecciona un rol</option>
                    <?php while ($rol = mysqli_fetch_assoc($roles)): ?>
                        <option value="<?= (int)$rol['id_rol'] ?>">
                            <?= h($rol['nombre_rol']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <button type="submit" class="btn btn-primary">
                    Registrar usuario
                </button>
                <a href="usuarios.php" class="btn btn-outline-secondary">
                    Cancelar
                </a>
            </div>
        </form>
    </section>
</main>
</body>
</html>