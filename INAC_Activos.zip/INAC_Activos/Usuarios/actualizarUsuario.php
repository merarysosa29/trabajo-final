<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
if ($rolActual !== 'Administrador') {
    http_response_code(403);
    exit('No tienes permiso para actualizar usuarios.');
}
function volverEditar($id, $error) {
    header(
        'Location: editarUsuario.php?id=' . (int)$id .
        '&error=' . urlencode($error)
    );
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: usuarios.php');
    exit;
}
$id = filter_input(INPUT_POST, 'id_usuario', FILTER_VALIDATE_INT);
$token = $_POST['csrf_token'] ?? '';
if (
    empty($_SESSION['csrf_usuarios']) ||
    !hash_equals($_SESSION['csrf_usuarios'], $token)
) {
    volverEditar((int)$id, 'token');
}
if (!$id || $id < 1) {
    header('Location: usuarios.php?mensaje=error');
    exit;
}
$nombre = trim($_POST['nombre'] ?? '');
$apellido = trim($_POST['apellido'] ?? '');
$usuario = trim($_POST['usuario'] ?? '');
$nuevaClave = $_POST['contrasena'] ?? '';
$idRol = filter_var($_POST['id_rol'] ?? null, FILTER_VALIDATE_INT);
$longitud = function ($texto) {
    return function_exists('mb_strlen')
        ? mb_strlen($texto, 'UTF-8')
        : strlen($texto);
};
if (
    $nombre === '' || $apellido === '' || $usuario === '' ||
    $idRol === false || $idRol === null
) {
    volverEditar($id, 'datos');
}
if (
    $longitud($nombre) > 100 ||
    $longitud($apellido) > 100 ||
    strlen($usuario) > 50
) {
    volverEditar($id, 'datos');
}
if (
    !preg_match("/^[\p{L}\p{M} .'-]+$/u", $nombre) ||
    !preg_match("/^[\p{L}\p{M} .'-]+$/u", $apellido)
) {
    volverEditar($id, 'nombre');
}
if (!preg_match('/^[A-Za-z0-9._-]+$/', $usuario)) {
    volverEditar($id, 'formato');
}
if (
    $nuevaClave !== '' &&
    (strlen($nuevaClave) < 8 || strlen($nuevaClave) > 72)
) {
    volverEditar($id, 'contrasena');
}
$stmt = mysqli_prepare(
    $conn,
    "SELECT id_usuario, id_rol FROM usuario WHERE id_usuario = ?"
);
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$actual = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);
if (!$actual) {
    header('Location: usuarios.php?mensaje=error');
    exit;
}
if ((int)$id === (int)$_SESSION['id_usuario']) {
    $idRol = (int)$actual['id_rol'];
}
$stmt = mysqli_prepare(
    $conn,
    "SELECT id_usuario FROM usuario
     WHERE usuario = ? AND id_usuario <> ? LIMIT 1"
);
mysqli_stmt_bind_param($stmt, 'si', $usuario, $id);
mysqli_stmt_execute($stmt);
$duplicado = mysqli_num_rows(mysqli_stmt_get_result($stmt)) > 0;
mysqli_stmt_close($stmt);
if ($duplicado) {
    volverEditar($id, 'usuario');
}
$stmt = mysqli_prepare(
    $conn,
    "SELECT id_rol FROM rol WHERE id_rol = ?"
);
mysqli_stmt_bind_param($stmt, 'i', $idRol);
mysqli_stmt_execute($stmt);
$rolExiste = mysqli_num_rows(mysqli_stmt_get_result($stmt)) > 0;
mysqli_stmt_close($stmt);
if (!$rolExiste) {
    volverEditar($id, 'rol');
}
if ($nuevaClave !== '') {
    $hash = password_hash($nuevaClave, PASSWORD_DEFAULT);
    if ($hash === false) {
        volverEditar($id, 'guardar');
    }
    $stmt = mysqli_prepare(
        $conn,
        "UPDATE usuario
         SET nombre = ?, apellido = ?, usuario = ?,
             contrasena = ?, id_rol = ?
         WHERE id_usuario = ?"
    );
    mysqli_stmt_bind_param(
        $stmt, 'ssssii',
        $nombre, $apellido, $usuario, $hash, $idRol, $id
    );
} else {
    $stmt = mysqli_prepare(
        $conn,
        "UPDATE usuario
         SET nombre = ?, apellido = ?, usuario = ?, id_rol = ?
         WHERE id_usuario = ?"
    );
    mysqli_stmt_bind_param(
        $stmt, 'sssii',
        $nombre, $apellido, $usuario, $idRol, $id
    );
}
if (mysqli_stmt_execute($stmt)) {
    mysqli_stmt_close($stmt);
    header('Location: usuarios.php?mensaje=actualizado');
    exit;
}
$codigoError = mysqli_stmt_errno($stmt);
mysqli_stmt_close($stmt);
if ($codigoError === 1062) {
    volverEditar($id, 'usuario');
}
error_log('Error al actualizar usuario. Código: ' . $codigoError);
volverEditar($id, 'guardar');
?>