<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
if ($rolActual !== 'Administrador') {
    http_response_code(403);
    exit('No tienes permiso para cambiar el estado de usuarios.');
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: usuarios.php');
    exit;
}
$token = $_POST['csrf_token'] ?? '';
if (
    empty($_SESSION['csrf_usuarios']) ||
    !hash_equals($_SESSION['csrf_usuarios'], $token)
) {
    header('Location: usuarios.php?mensaje=error');
    exit;
}
$id = filter_input(INPUT_POST, 'id_usuario', FILTER_VALIDATE_INT);

if (!$id || $id < 1 || (int)$id === (int)$_SESSION['id_usuario']) {
    header('Location: usuarios.php?mensaje=error');
    exit;
}
$stmt = mysqli_prepare(
    $conn,
    "SELECT u.id_usuario, u.estado, r.nombre_rol
     FROM usuario u
     INNER JOIN rol r ON u.id_rol = r.id_rol
     WHERE u.id_usuario = ?"
);
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$cuenta = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);
if (
    !$cuenta ||
    !in_array($cuenta['estado'], ['Activo', 'Inactivo'], true)
) {
    header('Location: usuarios.php?mensaje=error');
    exit;
}
$nuevoEstado = $cuenta['estado'] === 'Activo'
    ? 'Inactivo'
    : 'Activo';
if (
    $cuenta['nombre_rol'] === 'Administrador' &&
    $cuenta['estado'] === 'Activo'
) {
    $consulta = mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM usuario u
         INNER JOIN rol r ON u.id_rol = r.id_rol
         WHERE r.nombre_rol = 'Administrador'
           AND u.estado = 'Activo'"
    );
    if (!$consulta) {
        header('Location: usuarios.php?mensaje=error');
        exit;
    }
    $fila = mysqli_fetch_assoc($consulta);
    if ((int)$fila['total'] <= 1) {
        header('Location: usuarios.php?mensaje=ultimo_admin');
        exit;
    }
}
$stmt = mysqli_prepare(
    $conn,
    "UPDATE usuario SET estado = ? WHERE id_usuario = ?"
);
mysqli_stmt_bind_param($stmt, 'si', $nuevoEstado, $id);
if (mysqli_stmt_execute($stmt)) {
    mysqli_stmt_close($stmt);
    header('Location: usuarios.php?mensaje=estado');
    exit;
}
mysqli_stmt_close($stmt);
header('Location: usuarios.php?mensaje=error');
exit;
?>