<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
if ($rolActual !== 'Administrador') {
    http_response_code(403);
    exit('No tienes permiso para editar usuarios.');
}
if (empty($_SESSION['csrf_usuarios'])) {
    $_SESSION['csrf_usuarios'] = bin2hex(random_bytes(32));
}
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    header('Location: usuarios.php?mensaje=error');
    exit;
}
$stmt = mysqli_prepare(
    $conn,
    "SELECT id_usuario, nombre, apellido, usuario, id_rol, estado
     FROM usuario WHERE id_usuario = ?"
);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);
$usuarioEditar = mysqli_fetch_assoc($resultado);
mysqli_stmt_close($stmt);
if (!$usuarioEditar) {
    header('Location: usuarios.php?mensaje=error');
    exit;
}
$roles = mysqli_query(
    $conn,
    "SELECT id_rol, nombre_rol FROM rol ORDER BY id_rol"
);
function h($valor) {
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Editar usuario | INAC Activos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">
    <link href="../style.css" rel="stylesheet">
</head>
<body>
<main class="container py-4">
    <h2>Editar usuario</h2>
    <?php if (isset($_GET['error'])): ?>
        <div class="alert alert-danger">
            <?php
            $errores = [
                'datos' => 'Revisa los campos obligatorios.',
                'usuario' => 'Ese nombre de usuario ya está ocupado.',
                'rol' => 'Selecciona un rol válido.',
                'contrasena' => 'La contraseña debe tener al menos 8 caracteres.',
                'token' => 'La solicitud expiró. Intenta nuevamente.',
                'guardar' => 'No se pudieron guardar los cambios.'
            ];
            echo h($errores[$_GET['error']] ?? 'No se pudo completar la operación.');
            ?>
        </div>
    <?php endif; ?>
    <section class="card">
        <form method="POST" action="actualizarUsuario.php">
            <input type="hidden" name="csrf_token"
                   value="<?= h($_SESSION['csrf_usuarios']) ?>">
            <input type="hidden" name="id_usuario"
                   value="<?= (int)$usuarioEditar['id_usuario'] ?>">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="nombre">Nombre *</label>
                    <input class="form-control" id="nombre" name="nombre"
                           maxlength="100" required
                           value="<?= h($usuarioEditar['nombre']) ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="apellido">Apellido *</label>
                    <input class="form-control" id="apellido" name="apellido"
                           maxlength="100" required
                           value="<?= h($usuarioEditar['apellido']) ?>">
                </div>
            </div>
            <div class="mb-3">
                <label for="usuario">Nombre de usuario *</label>
                <input class="form-control" id="usuario" name="usuario"
                       maxlength="50" required
                       pattern="[A-Za-z0-9._-]+"
                       value="<?= h($usuarioEditar['usuario']) ?>">
            </div>
            <div class="mb-3">
                <label for="contrasena">Nueva contraseña</label>
                <input class="form-control" type="password"
                       id="contrasena" name="contrasena"
                       minlength="8" autocomplete="new-password">
                <small class="text-secondary">
                    Déjala vacía si no deseas cambiarla.
                </small>
            </div>
            <div class="mb-3">
                <label for="id_rol">Rol *</label>
                <select class="form-select" id="id_rol" name="id_rol" required>
                    <?php while ($rol = mysqli_fetch_assoc($roles)): ?>
                        <option value="<?= (int)$rol['id_rol'] ?>"
                            <?= (int)$rol['id_rol'] === (int)$usuarioEditar['id_rol']
                                ? 'selected' : '' ?>>
                            <?= h($rol['nombre_rol']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <p>
                Estado actual:
                <strong><?= h($usuarioEditar['estado']) ?></strong>
            </p>
            <div class="d-flex gap-2 flex-wrap">
                <button type="submit" class="btn btn-primary">
                    Guardar cambios
                </button>
                <a href="usuarios.php" class="btn btn-outline-secondary">
                    Cancelar
                </a>
            </div>
        </form>
    </section>
</main>
</body>
</html>