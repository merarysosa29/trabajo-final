<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
if ($rolActual !== 'Administrador') {
    http_response_code(403);
    exit('No tienes permiso para registrar usuarios.');
}
function volver($error) {
    header('Location: nuevoUsuario.php?error=' . urlencode($error));
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: usuarios.php');
    exit;
}
$token = $_POST['csrf_token'] ?? '';
if (
    empty($_SESSION['csrf_usuarios']) ||
    !hash_equals($_SESSION['csrf_usuarios'], $token)
) {
    volver('token');
}
$nombre = trim($_POST['nombre'] ?? '');
$apellido = trim($_POST['apellido'] ?? '');
$usuario = trim($_POST['usuario'] ?? '');
$contrasena = $_POST['contrasena'] ?? '';
$idRol = filter_var($_POST['id_rol'] ?? null, FILTER_VALIDATE_INT);
$longitud = function ($texto) {
    return function_exists('mb_strlen')
        ? mb_strlen($texto, 'UTF-8')
        : strlen($texto);
};
if (
    $nombre === '' || $apellido === '' || $usuario === '' ||
    $contrasena === '' || $idRol === false || $idRol === null
) {
    volver('datos');
}
if (
    $longitud($nombre) > 100 ||
    $longitud($apellido) > 100 ||
    strlen($usuario) > 50
) {
    volver('datos');
}
if (
    !preg_match("/^[\p{L}\p{M} .'-]+$/u", $nombre) ||
    !preg_match("/^[\p{L}\p{M} .'-]+$/u", $apellido)
) {
    volver('nombre');
}
if (!preg_match('/^[A-Za-z0-9._-]+$/', $usuario)) {
    volver('formato');
}
if (strlen($contrasena) < 8 || strlen($contrasena) > 72) {
    volver('contrasena');
}
$stmt = mysqli_prepare(
    $conn,
    "SELECT id_usuario FROM usuario WHERE usuario = ? LIMIT 1"
);
mysqli_stmt_bind_param($stmt, 's', $usuario);
mysqli_stmt_execute($stmt);
$duplicado = mysqli_num_rows(mysqli_stmt_get_result($stmt)) > 0;
mysqli_stmt_close($stmt);
if ($duplicado) {
    volver('usuario');
}
$stmt = mysqli_prepare(
    $conn,
    "SELECT id_rol FROM rol WHERE id_rol = ?"
);
mysqli_stmt_bind_param($stmt, 'i', $idRol);
mysqli_stmt_execute($stmt);
$rolExiste = mysqli_num_rows(mysqli_stmt_get_result($stmt)) > 0;
mysqli_stmt_close($stmt);
if (!$rolExiste) {
    volver('rol');
}
$hash = password_hash($contrasena, PASSWORD_DEFAULT);
if ($hash === false) {
    volver('guardar');
}
$stmt = mysqli_prepare(
    $conn,
    "INSERT INTO usuario
        (nombre, apellido, usuario, contrasena, id_rol, estado)
     VALUES (?, ?, ?, ?, ?, 'Activo')"
);
mysqli_stmt_bind_param(
    $stmt,
    'ssssi',
    $nombre,
    $apellido,
    $usuario,
    $hash,
    $idRol
);
if (mysqli_stmt_execute($stmt)) {
    mysqli_stmt_close($stmt);
    header('Location: usuarios.php?mensaje=registrado');
    exit;
}
$codigoError = mysqli_stmt_errno($stmt);
mysqli_stmt_close($stmt);
if ($codigoError === 1062) {
    volver('usuario');
}
error_log('Error al registrar usuario. Código: ' . $codigoError);
volver('guardar');
?>