<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
if ($rolActual !== 'Administrador') {
    http_response_code(403);
    exit('No tienes permiso para gestionar usuarios.');
}
if (empty($_SESSION['csrf_usuarios'])) {
    $_SESSION['csrf_usuarios'] = bin2hex(random_bytes(32));
}
$busqueda = trim($_GET['buscar'] ?? '');
$sql = "SELECT
            u.id_usuario,
            u.nombre,
            u.apellido,
            u.usuario,
            u.id_rol,
            u.estado,
            r.nombre_rol
        FROM usuario u
        INNER JOIN rol r
            ON u.id_rol = r.id_rol";
if ($busqueda !== '') {
    $sql .= " WHERE u.nombre LIKE ?
              OR u.apellido LIKE ?
              OR u.usuario LIKE ?
              OR r.nombre_rol LIKE ?";
}
$sql .= " ORDER BY u.id_usuario ASC";
$stmt = mysqli_prepare($conn, $sql);
if (!$stmt) {
    error_log('Error al preparar listado de usuarios: ' . mysqli_error($conn));
    http_response_code(500);
    exit('No se pudo preparar la consulta de usuarios.');
}
if ($busqueda !== '') {
    $filtro = '%' . $busqueda . '%';
    mysqli_stmt_bind_param(
        $stmt,
        'ssss',
        $filtro,
        $filtro,
        $filtro,
        $filtro
    );
}
if (!mysqli_stmt_execute($stmt)) {
    error_log('Error al consultar usuarios: ' . mysqli_stmt_error($stmt));
    mysqli_stmt_close($stmt);
    http_response_code(500);
    exit('Ocurrió un error al consultar los usuarios.');
}
$resultado = mysqli_stmt_get_result($stmt);
function h($valor) {
    return htmlspecialchars((string)($valor ?? ''), ENT_QUOTES, 'UTF-8');
}
$mensajes = [
    'registrado' => 'Usuario registrado correctamente.',
    'actualizado' => 'Usuario actualizado correctamente.',
    'estado' => 'Estado del usuario actualizado correctamente.',
    'ultimo_admin' => 'No puedes desactivar al último Administrador activo.',
    'error' => 'No se pudo completar la operación.'
];
$claveMensaje = $_GET['mensaje'] ?? '';
$mensaje = $mensajes[$claveMensaje] ?? '';
$tipoMensaje = in_array(
    $claveMensaje,
    ['error', 'ultimo_admin'],
    true
) ? 'danger' : 'success';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Usuarios | INAC Activos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="../style.css" rel="stylesheet">
    <script src="../JavaScript/script.js" defer></script>
    <style>
        body {
            background: #F4F6F8;
            color: #263746;
        }
        h2 {
            color: #123B63;
            font-weight: 600;
        }
        .tarjeta-usuarios {
            background: #FFFFFF;
            border: 0;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 3px 12px rgba(18, 59, 99, 0.07);
        }
        .tabla-usuarios thead th {
            background: #123B63;
            color: #FFFFFF;
            white-space: nowrap;
        }
        .acciones {
            white-space: nowrap;
        }
        @media (max-width: 576px) {
            .tarjeta-usuarios {
                padding: 12px;
            }
        }
    </style>
</head>
<body>
<main class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h2>Gestión de usuarios</h2>
            <p class="text-secondary mb-0">
                Administra las cuentas y sus permisos.
            </p>
        </div>
        <a href="nuevoUsuario.php" class="btn btn-primary">
            <i class="bi bi-person-plus me-1"></i>
            Registrar usuario
        </a>
    </div>
    <?php if ($mensaje !== ''): ?>
        <div
            class="alert alert-<?= h($tipoMensaje) ?> alert-dismissible fade show"
            role="alert">
            <?= h($mensaje) ?>
            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="alert"
                aria-label="Cerrar">
            </button>
        </div>
    <?php endif; ?>
    <section class="tarjeta-usuarios">
        <form
            method="GET"
            action="usuarios.php"
            class="row g-2 mb-3">
            <div class="col-md-8">
                <input
                    type="search"
                    name="buscar"
                    class="form-control"
                    placeholder="Buscar por nombre, apellido, usuario o rol"
                    value="<?= h($busqueda) ?>"
                    aria-label="Buscar usuarios">
            </div>
            <div class="col-md-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary flex-fill">
                    <i class="bi bi-search"></i>
                    Buscar
                </button>
                <a href="usuarios.php" class="btn btn-outline-secondary">
                    Limpiar
                </a>
            </div>
        </form>
        <div class="table-responsive">
            <table class="table table-hover align-middle tabla-usuarios">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nombre completo</th>
                        <th>Usuario</th>
                        <th>Rol</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (mysqli_num_rows($resultado) > 0): ?>
                    <?php while ($fila = mysqli_fetch_assoc($resultado)): ?>
                        <tr>
                            <td><?= (int)$fila['id_usuario'] ?></td>
                            <td>
                                <?= h($fila['nombre'] . ' ' . $fila['apellido']) ?>
                            </td>
                            <td><?= h($fila['usuario']) ?></td>
                            <td><?= h($fila['nombre_rol']) ?></td>
                            <td>
                                <?php if ($fila['estado'] === 'Activo'): ?>
                                    <span class="badge text-bg-success">
                                        Activo
                                    </span>
                                <?php else: ?>
                                    <span class="badge text-bg-secondary">
                                        <?= h($fila['estado']) ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="acciones">
                                <a
                                    class="btn btn-sm btn-outline-primary"
                                    href="verUsuario.php?id=<?= (int)$fila['id_usuario'] ?>"
                                    title="Consultar">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <a
                                    class="btn btn-sm btn-outline-warning"
                                    href="editarUsuario.php?id=<?= (int)$fila['id_usuario'] ?>"
                                    title="Editar">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <?php if (
                                    (int)$fila['id_usuario'] !==
                                    (int)$_SESSION['id_usuario']
                                ): ?>
                                    <form
                                        method="POST"
                                        action="cambiarEstadoUsuario.php"
                                        class="d-inline"
                                        data-confirm="¿Deseas cambiar el estado de esta cuenta?"
                                        data-confirm-type="estado">
                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?= h($_SESSION['csrf_usuarios']) ?>">
                                        <input
                                            type="hidden"
                                            name="id_usuario"
                                            value="<?= (int)$fila['id_usuario'] ?>">
                                        <button
                                            type="submit"
                                            class="btn btn-sm btn-outline-secondary"
                                            title="Cambiar estado">
                                            <i class="bi bi-person-check"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center text-secondary py-4">
                            No se encontraron usuarios.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
mysqli_stmt_close($stmt);
?>