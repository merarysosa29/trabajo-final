<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
if ($rolActual !== 'Administrador') {
    http_response_code(403);
    exit('No tienes permiso para consultar usuarios.');
}
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    header('Location: usuarios.php?mensaje=error');
    exit;
}
$stmt = mysqli_prepare(
    $conn,
    "SELECT u.id_usuario, u.nombre, u.apellido, u.usuario,
            u.id_rol, u.estado, r.nombre_rol, r.descripcion
     FROM usuario u
     INNER JOIN rol r ON u.id_rol = r.id_rol
     WHERE u.id_usuario = ?"
);
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$datos = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);
if (!$datos) {
    header('Location: usuarios.php?mensaje=error');
    exit;
}
function h($valor) {
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Consultar usuario | INAC Activos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../style.css" rel="stylesheet">
</head>
<body>
<main class="container py-4">
    <h2>Detalles del usuario</h2>
    <section class="card">
        <dl class="row mb-0">
            <dt class="col-sm-4">Código</dt>
            <dd class="col-sm-8"><?= (int)$datos['id_usuario'] ?></dd>
            <dt class="col-sm-4">Nombre</dt>
            <dd class="col-sm-8"><?= h($datos['nombre']) ?></dd>
            <dt class="col-sm-4">Apellido</dt>
            <dd class="col-sm-8"><?= h($datos['apellido']) ?></dd>
            <dt class="col-sm-4">Nombre de usuario</dt>
            <dd class="col-sm-8"><?= h($datos['usuario']) ?></dd>
            <dt class="col-sm-4">Rol</dt>
            <dd class="col-sm-8"><?= h($datos['nombre_rol']) ?></dd>
            <dt class="col-sm-4">Descripción del rol</dt>
            <dd class="col-sm-8"><?= h($datos['descripcion'] ?? 'Sin descripción') ?></dd>
            <dt class="col-sm-4">Estado</dt>
            <dd class="col-sm-8"><?= h($datos['estado']) ?></dd>
        </dl>
        <div class="d-flex gap-2 mt-3 flex-wrap">
            <a href="editarUsuario.php?id=<?= (int)$datos['id_usuario'] ?>"
               class="btn btn-primary">
                Editar usuario
            </a>
            <a href="usuarios.php" class="btn btn-outline-secondary">
                Volver
            </a>
        </div>
    </section>
</main>
</body>
</html>