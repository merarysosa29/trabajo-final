<?php
$host ="sql300.infinityfree.com";
$usuario ="if0_42034035";
$contrasena ="";
$base_de_datos = "if0_42034035_inac_activos"; 
$conn = mysqli_connect($host, $usuario, $contrasena, $base_de_datos);
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}
mysqli_set_charset($conn, "utf8mb4");
?>