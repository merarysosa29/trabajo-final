<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
$rolActual = $_SESSION['rol'] ?? '';
if (!in_array($rolActual, ['Administrador', 'Editor'], true)) {
    header('Location: ubicaciones.php?mensaje=sin_permiso');
    exit;
}
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$id = $id ?: 0;
$nombre = '';
$descripcion = '';
$error = $_SESSION['mensaje_ubicacion'] ?? '';
unset($_SESSION['mensaje_ubicacion']);
if (isset($_SESSION['ubicacion_formulario'])) {
    $datos = $_SESSION['ubicacion_formulario'];
    $nombre = $datos['nombre'] ?? '';
    $descripcion = $datos['descripcion'] ?? '';
    unset($_SESSION['ubicacion_formulario']);
} elseif ($id > 0) {
    $stmt = $conn->prepare(
        'SELECT nombre, descripcion FROM ubicacion WHERE id_ubicacion = ?'
    );
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $ubicacion = $resultado->fetch_assoc();
    $stmt->close();
    if (!$ubicacion) {
        header('Location: ubicaciones.php?mensaje=no_encontrada');
        exit;
    }
    $nombre = $ubicacion['nombre'];
    $descripcion = $ubicacion['descripcion'] ?? '';
}
function h($valor) {
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $id > 0 ? 'Editar' : 'Registrar' ?> ubicación | INAC Activos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #F4F6F8;
            font-family: Arial, sans-serif;
        }
        .formulario {
            max-width: 700px;
            margin: 40px auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,.07);
        }
        .encabezado {
            background: #123B63;
            color: white;
            padding: 18px;
            border-radius: 10px;
            margin-bottom: 24px;
        }
        .btn-principal {
            background: #123B63;
            color: white;
        }
        .btn-principal:hover {
            background: #0c2c4b;
            color: white;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="formulario">
        <div class="encabezado">
            <h3 class="mb-1">
                <?= $id > 0 ? 'Editar ubicación' : 'Registrar ubicación' ?>
            </h3>
            <p class="mb-0">Completa los datos de la ubicación.</p>
        </div>
        <?php if ($error !== ''): ?>
            <div class="alert alert-warning">
                <?= h($error) ?>
            </div>
        <?php endif; ?>
        <form action="guardarUbicacion.php" method="POST">
            <input type="hidden" name="id_ubicacion" value="<?= (int)$id ?>">
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre de la ubicación</label>
                <input type="text" id="nombre" name="nombre"
                       class="form-control" maxlength="100"
                       value="<?= h($nombre) ?>" required>
            </div>
            <div class="mb-4">
                <label for="descripcion" class="form-label">Descripción</label>
                <textarea id="descripcion" name="descripcion"
                          class="form-control" rows="4" maxlength="255"
                          placeholder="Describe la ubicación (opcional)"><?= h($descripcion) ?></textarea>
            </div>
            <div class="d-flex flex-wrap gap-2">
                <button type="submit" class="btn btn-principal">
                    Guardar ubicación
                </button>
                <a href="ubicaciones.php" class="btn btn-outline-secondary">
                    Cancelar
                </a>
            </div>
        </form>
    </div>
</div>
</body>
</html>