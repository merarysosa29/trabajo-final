<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
$rolActual = $_SESSION['rol'] ?? '';
$puedeEditar = in_array($rolActual, ['Administrador', 'Editor'], true);
$busqueda = trim($_GET['buscar'] ?? '');
$mensaje = $_GET['mensaje'] ?? '';
$mensajes = [
    'creada' => 'Ubicación registrada correctamente.',
    'actualizada' => 'Ubicación actualizada correctamente.',
    'eliminada' => 'Ubicación eliminada correctamente.',
    'desactivada' => 'Ubicación desactivada correctamente.',
    'reactivada' => 'Ubicación reactivada correctamente.',
    'duplicada' => 'Ya existe una ubicación con ese nombre.',
    'relacionada' => 'No se puede eliminar: la ubicación tiene activos asociados.',
    'no_encontrada' => 'La ubicación no existe.',
    'error' => 'Ocurrió un error al realizar la operación.',
    'sin_permiso' => 'No tienes permiso para realizar esta operación.',
    'solicitud_invalida' => 'La solicitud no es válida.'
];
$ubicaciones = [];
$sql = "SELECT
            u.id_ubicacion,
            u.nombre,
            u.descripcion,
            u.estado,
            COUNT(a.id_activo) AS total_activos
        FROM ubicacion u
        LEFT JOIN activo a
            ON a.id_ubicacion = u.id_ubicacion";
if ($busqueda !== '') {
    $sql .= " WHERE u.nombre LIKE ?
              OR u.descripcion LIKE ?";
}
$sql .= " GROUP BY
              u.id_ubicacion,
              u.nombre,
              u.descripcion,
              u.estado
          ORDER BY u.id_ubicacion ASC";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log('Error al preparar ubicaciones: ' . $conn->error);
    http_response_code(500);
    exit('No se pudo preparar la consulta de ubicaciones.');
}
if ($busqueda !== '') {
    $filtro = "%{$busqueda}%";
    $stmt->bind_param('ss', $filtro, $filtro);
}
if (!$stmt->execute()) {
    error_log('Error al consultar ubicaciones: ' . $stmt->error);
    $stmt->close();
    http_response_code(500);
    exit('Ocurrió un error al consultar las ubicaciones.');
}
$resultado = $stmt->get_result();
while ($fila = $resultado->fetch_assoc()) {
    $ubicaciones[] = $fila;
}
$stmt->close();
function h($valor) {
    return htmlspecialchars((string)($valor ?? ''), ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ubicaciones | INAC Activos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="../style.css" rel="stylesheet">
    <script src="../JavaScript/script.js" defer></script>
    <style>
        body {
            background: #F4F6F8;
            font-family: Arial, sans-serif;
            color: #263238;
        }
        .encabezado {
            background: #123B63;
            color: white;
            padding: 22px;
            border-radius: 12px;
            margin-bottom: 22px;
        }
        .tarjeta {
            background: white;
            border: 0;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, .06);
        }
        .btn-principal {
            background: #123B63;
            color: white;
        }
        .btn-principal:hover {
            background: #0c2c4b;
            color: white;
        }
        .tabla th {
            background: #123B63;
            color: white;
            white-space: nowrap;
        }
        .acciones {
            white-space: nowrap;
        }
        @media (max-width: 576px) {
            .encabezado {
                padding: 16px;
            }
        }
    </style>
</head>
<body>
<div class="container py-4">
    <div class="encabezado d-flex flex-wrap justify-content-between align-items-center gap-3">
        <div>
            <h2 class="mb-1">
                <i class="bi bi-geo-alt"></i>
                Gestión de ubicaciones
            </h2>
            <p class="mb-0">
                Consulta y administra las ubicaciones de los activos.
            </p>
        </div>
        <?php if ($puedeEditar): ?>
            <a href="formularioUbicacion.php" class="btn btn-light">
                <i class="bi bi-plus-circle"></i>
                Registrar ubicación
            </a>
        <?php endif; ?>
    </div>
    <?php if (isset($mensajes[$mensaje])): ?>
        <div class="alert <?= in_array($mensaje, ['creada', 'actualizada', 'eliminada', 'desactivada', 'reactivada'], true) ? 'alert-success' : 'alert-warning' ?> alert-dismissible fade show" role="alert">
            <?= h($mensajes[$mensaje]) ?>
            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="alert"
                aria-label="Cerrar">
            </button>
        </div>
    <?php endif; ?>
    <div class="card tarjeta p-3 mb-4">
        <form method="GET" action="ubicaciones.php" class="row g-2">
            <div class="col-md-9">
                <input
                    type="search"
                    name="buscar"
                    class="form-control"
                    placeholder="Buscar por nombre o descripción..."
                    value="<?= h($busqueda) ?>"
                    aria-label="Buscar ubicaciones">
            </div>
            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-principal flex-fill">
                    <i class="bi bi-search"></i>
                    Buscar
                </button>
                <a href="ubicaciones.php" class="btn btn-outline-secondary">
                    Limpiar
                </a>
            </div>
        </form>
    </div>
    <div class="card tarjeta">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle tabla">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Activos asociados</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if (count($ubicaciones) > 0): ?>
                        <?php foreach ($ubicaciones as $u): ?>
                            <tr>
                                <td><?= (int)$u['id_ubicacion'] ?></td>
                                <td><?= h($u['nombre']) ?></td>
                                <td>
                                    <?= h($u['descripcion'] ?: 'Sin descripción') ?>
                                </td>
                                <td><?= (int)$u['total_activos'] ?></td>
                                <td>
                                    <?php if ($u['estado'] === 'Activa'): ?>
                                        <span class="badge text-bg-success">Activa</span>
                                    <?php else: ?>
                                        <span class="badge text-bg-secondary">Inactiva</span>
                                    <?php endif; ?>
                                </td>
                                <td class="acciones">
                                    <?php if ($puedeEditar): ?>
                                        <a
                                            href="formularioUbicacion.php?id=<?= (int)$u['id_ubicacion'] ?>"
                                            class="btn btn-sm btn-outline-primary"
                                            title="Editar">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <form
                                            action="cambiarEstadoUbicacion.php"
                                            method="POST"
                                            class="d-inline"
                                            data-confirm="¿Deseas cambiar el estado de esta ubicación?"
                                            data-confirm-type="estado">
                                            <input
                                                type="hidden"
                                                name="id_ubicacion"
                                                value="<?= (int)$u['id_ubicacion'] ?>">
                                            <button
                                                type="submit"
                                                class="btn btn-sm <?= $u['estado'] === 'Activa' ? 'btn-outline-warning' : 'btn-outline-success' ?>"
                                                title="<?= $u['estado'] === 'Activa' ? 'Desactivar' : 'Reactivar' ?>">
                                                <i class="bi <?= $u['estado'] === 'Activa' ? 'bi-toggle-on' : 'bi-toggle-off' ?>"></i>
                                            </button>
                                        </form>
                                        <?php if ((int)$u['total_activos'] === 0): ?>
                                            <form
                                                action="eliminarUbicacion.php"
                                                method="POST"
                                                class="d-inline"
                                                data-confirm="¿Seguro que deseas eliminar permanentemente esta ubicación?"
                                                data-confirm-type="eliminar">
                                                <input
                                                    type="hidden"
                                                    name="id_ubicacion"
                                                    value="<?= (int)$u['id_ubicacion'] ?>">
                                                <button
                                                    type="submit"
                                                    class="btn btn-sm btn-outline-danger"
                                                    title="Eliminar">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <button
                                                type="button"
                                                class="btn btn-sm btn-outline-secondary"
                                                disabled
                                                title="Tiene activos asociados">
                                                <i class="bi bi-lock"></i>
                                            </button>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">Solo consulta</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center py-4">
                                No se encontraron ubicaciones registradas.
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="mt-3">
        <a href="../Index.php" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i>
            Volver al inicio
        </a>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>