<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
$rolActual = $_SESSION['rol'] ?? '';
if (!in_array($rolActual, ['Administrador', 'Editor'], true)) {
    header('Location: ubicaciones.php?mensaje=sin_permiso');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ubicaciones.php?mensaje=solicitud_invalida');
    exit;
}
$id = filter_input(INPUT_POST, 'id_ubicacion', FILTER_VALIDATE_INT);
$id = $id ?: 0;
$nombre = trim($_POST['nombre'] ?? '');
$descripcion = trim($_POST['descripcion'] ?? '');
$_SESSION['ubicacion_formulario'] = [
    'nombre' => $nombre,
    'descripcion' => $descripcion
];
function volverConError($mensaje) {
    $_SESSION['mensaje_ubicacion'] = $mensaje;
    $id = (int)($_POST['id_ubicacion'] ?? 0);
    header('Location: formularioUbicacion.php' . ($id > 0 ? '?id=' . $id : ''));
    exit;
}
if ($nombre === '') {
    volverConError('El nombre de la ubicación es obligatorio.');
}
if (mb_strlen($nombre) > 100) {
    volverConError('El nombre no puede superar los 100 caracteres.');
}
if (mb_strlen($descripcion) > 255) {
    volverConError('La descripción no puede superar los 255 caracteres.');
}
if ($id > 0) {
    $stmt = $conn->prepare(
        'SELECT id_ubicacion FROM ubicacion
         WHERE LOWER(TRIM(nombre)) = LOWER(TRIM(?))
         AND id_ubicacion <> ?
         LIMIT 1'
    );
    $stmt->bind_param('si', $nombre, $id);
} else {
    $stmt = $conn->prepare(
        'SELECT id_ubicacion FROM ubicacion
         WHERE LOWER(TRIM(nombre)) = LOWER(TRIM(?))
         LIMIT 1'
    );
    $stmt->bind_param('s', $nombre);
}
$stmt->execute();
$duplicado = $stmt->get_result()->num_rows > 0;
$stmt->close();
if ($duplicado) {
    volverConError('Ya existe una ubicación con ese nombre.');
}
try {
    if ($id > 0) {
        $stmt = $conn->prepare(
            'SELECT id_ubicacion FROM ubicacion WHERE id_ubicacion = ?'
        );
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $existe = $stmt->get_result()->num_rows > 0;
        $stmt->close();
        if (!$existe) {
            unset($_SESSION['ubicacion_formulario']);
            header('Location: ubicaciones.php?mensaje=no_encontrada');
            exit;
        }
        $stmt = $conn->prepare(
            "UPDATE ubicacion
             SET nombre = ?, descripcion = NULLIF(?, '')
             WHERE id_ubicacion = ?"
        );
        $stmt->bind_param('ssi', $nombre, $descripcion, $id);
        $mensajeExito = 'actualizada';
    } else {
        $stmt = $conn->prepare(
            "INSERT INTO ubicacion (nombre, descripcion)
             VALUES (?, NULLIF(?, ''))"
        );
        $stmt->bind_param('ss', $nombre, $descripcion);
        $mensajeExito = 'creada';
    }
    $stmt->execute();
    $stmt->close();
    unset($_SESSION['ubicacion_formulario'], $_SESSION['mensaje_ubicacion']);
    header('Location: ubicaciones.php?mensaje=' . $mensajeExito);
    exit;
} catch (mysqli_sql_exception $e) {
    if (isset($stmt) && $stmt instanceof mysqli_stmt) {
        $stmt->close();
    }
    if ((int)$e->getCode() === 1062) {
        volverConError('Ya existe una ubicación con ese nombre.');
    }
    volverConError('No se pudo guardar la ubicación. Intenta nuevamente.');
}