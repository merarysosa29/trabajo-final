<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
$rolActual = $_SESSION['rol'] ?? '';
if (!in_array($rolActual, ['Administrador', 'Editor'], true)) {
    header('Location: ubicaciones.php?mensaje=sin_permiso');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ubicaciones.php?mensaje=solicitud_invalida');
    exit;
}
$id = filter_input(INPUT_POST, 'id_ubicacion', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    header('Location: ubicaciones.php?mensaje=solicitud_invalida');
    exit;
}
$stmt = $conn->prepare(
    'SELECT estado FROM ubicacion WHERE id_ubicacion = ?'
);
$stmt->bind_param('i', $id);
$stmt->execute();
$ubicacion = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$ubicacion) {
    header('Location: ubicaciones.php?mensaje=no_encontrada');
    exit;
}
if ($ubicacion['estado'] === 'Activa') {
    $nuevoEstado = 'Inactiva';
    $mensaje = 'desactivada';
} else {
    $nuevoEstado = 'Activa';
    $mensaje = 'reactivada';
}
$stmt = $conn->prepare(
    'UPDATE ubicacion SET estado = ? WHERE id_ubicacion = ?'
);
$stmt->bind_param('si', $nuevoEstado, $id);
if ($stmt->execute()) {
    $stmt->close();
    header('Location: ubicaciones.php?mensaje=' . $mensaje);
    exit;
}
$stmt->close();
header('Location: ubicaciones.php?mensaje=error');
exit;