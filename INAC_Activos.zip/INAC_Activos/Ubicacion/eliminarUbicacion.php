<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
$rolActual = $_SESSION['rol'] ?? '';
if (!in_array($rolActual, ['Administrador', 'Editor'], true)) {
    header('Location: ubicaciones.php?mensaje=sin_permiso');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ubicaciones.php?mensaje=solicitud_invalida');
    exit;
}
$id = filter_input(INPUT_POST, 'id_ubicacion', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    header('Location: ubicaciones.php?mensaje=solicitud_invalida');
    exit;
}
$stmt = $conn->prepare(
    'SELECT id_ubicacion FROM ubicacion WHERE id_ubicacion = ?'
);
$stmt->bind_param('i', $id);
$stmt->execute();
$existe = $stmt->get_result()->num_rows > 0;
$stmt->close();
if (!$existe) {
    header('Location: ubicaciones.php?mensaje=no_encontrada');
    exit;
}
$stmt = $conn->prepare(
    'SELECT COUNT(*) AS total FROM activo WHERE id_ubicacion = ?'
);
$stmt->bind_param('i', $id);
$stmt->execute();
$total = (int)$stmt->get_result()->fetch_assoc()['total'];
$stmt->close();
if ($total > 0) {
    header('Location: ubicaciones.php?mensaje=relacionada');
    exit;
}
try {
    $stmt = $conn->prepare(
        'DELETE FROM ubicacion WHERE id_ubicacion = ?'
    );
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $eliminada = $stmt->affected_rows > 0;
    $stmt->close();
    header(
        'Location: ubicaciones.php?mensaje=' .
        ($eliminada ? 'eliminada' : 'no_encontrada')
    );
    exit;
} catch (mysqli_sql_exception $e) {
    header('Location: ubicaciones.php?mensaje=relacionada');
    exit;
}