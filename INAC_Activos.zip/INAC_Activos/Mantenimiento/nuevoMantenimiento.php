<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
if (!in_array($rolActual, ['Administrador', 'Editor'], true)) {
    http_response_code(403);
    exit('No tienes permiso para registrar mantenimientos.');
}
$activos = $conn->query("SELECT id_activo, codigo, nombre FROM activo ORDER BY id_activo ASC");
$tipos = $conn->query("SELECT id_tipo_mantenimiento, nombre FROM tipo_mantenimiento ORDER BY id_tipo_mantenimiento ASC");

if (!$activos || !$tipos) {
    die('Error al cargar activos o tipos de mantenimiento.');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Nuevo mantenimiento | INAC Activos</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:#F4F6F8;font-family:Arial,sans-serif}
.tarjeta{background:white;padding:24px;border-radius:12px;max-width:950px;margin:25px auto;box-shadow:0 2px 8px #0000000d}
h3{color:#123B63}
</style>
</head>
<body>
<div class="container">
<div class="tarjeta">
<h3>Registrar mantenimiento</h3>
<p class="text-muted">Los campos marcados con * son obligatorios.</p>
<form action="guardarMantenimiento.php" method="POST">
<div class="row g-3">
<div class="col-md-6">
<label class="form-label">Activo *</label>
<select name="id_activo" class="form-select" required>
<option value="">Seleccionar activo</option>
<?php while ($a = $activos->fetch_assoc()): ?>
<option value="<?= (int)$a['id_activo'] ?>">
<?= htmlspecialchars($a['codigo'] . ' - ' . $a['nombre']) ?>
</option>
<?php endwhile; ?>
</select>
</div>
<div class="col-md-6">
<label class="form-label">Tipo de mantenimiento *</label>
<select name="id_tipo_mantenimiento" class="form-select" required>
<option value="">Seleccionar tipo</option>
<?php while ($t = $tipos->fetch_assoc()): ?>
<option value="<?= (int)$t['id_tipo_mantenimiento'] ?>">
<?= htmlspecialchars($t['nombre']) ?>
</option>
<?php endwhile; ?>
</select>
</div>
<div class="col-md-4">
<label class="form-label">Fecha del mantenimiento *</label>
<input type="date" name="fecha" class="form-control" required>
</div>
<div class="col-md-4">
<label class="form-label">Fecha de la falla</label>
<input type="date" name="fecha_falla" class="form-control">
</div>
<div class="col-md-4">
<label class="form-label">Próxima fecha</label>
<input type="date" name="proxima_fecha" class="form-control">
</div>
<div class="col-md-8">
<label class="form-label">Descripción del problema o mantenimiento *</label>
<input type="text" name="descripcion" maxlength="255" class="form-control" required>
</div>
<div class="col-md-4">
<label class="form-label">Costo ($)</label>
<input type="number" name="costo" min="0" step="0.01" value="0.00" class="form-control" required>
</div>
<div class="col-md-6">
<label class="form-label">Reparación realizada</label>
<textarea name="reparacion_realizada" maxlength="255" class="form-control" rows="3"></textarea>
</div>
<div class="col-md-6">
<label class="form-label">Observaciones</label>
<textarea name="observaciones" maxlength="255" class="form-control" rows="3"></textarea>
</div>
<div class="col-md-4">
<label class="form-label">Estado</label>
<select name="estado_mantenimiento" class="form-select">
<option value="Pendiente">Pendiente</option>
<option value="En proceso">En proceso</option>
<option value="Realizado">Realizado</option>
</select>
</div>
<div class="col-12">
<button type="submit" class="btn text-white" style="background:#123B63">Guardar mantenimiento</button>
<a href="mantenimientos.php" class="btn btn-secondary">Cancelar</a>
</div>
</div>
</form>
</div>
</div>
</body>
</html>