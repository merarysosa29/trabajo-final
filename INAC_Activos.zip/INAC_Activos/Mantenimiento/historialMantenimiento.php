<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
$sql = "SELECT m.id_mantenimiento, m.fecha, m.descripcion,
               m.estado_mantenimiento, m.costo,
               a.codigo, a.nombre AS activo,
               tm.nombre AS tipo
        FROM mantenimiento m
        INNER JOIN activo a ON m.id_activo = a.id_activo
        INNER JOIN tipo_mantenimiento tm
            ON m.id_tipo_mantenimiento = tm.id_tipo_mantenimiento
        ORDER BY m.fecha DESC, m.id_mantenimiento DESC";
$resultado = $conn->query($sql);
if (!$resultado) {
    die('Error al consultar el historial.');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Historial de mantenimiento | INAC Activos</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:#F4F6F8;font-family:Arial,sans-serif}
.tarjeta{background:white;padding:22px;border-radius:12px;margin:25px auto}
h3{color:#123B63}
</style>
</head>
<body>
<div class="container-fluid p-3 p-md-4">
<div class="tarjeta">
<h3>Historial de mantenimientos</h3>
<p class="text-muted">Registros ordenados por fecha, del más reciente al más antiguo.</p>
<div class="table-responsive">
<table class="table table-bordered table-hover">
<thead class="table-dark">
<tr>
<th>ID</th>
<th>Fecha</th>
<th>Código del activo</th>
<th>Activo</th>
<th>Tipo</th>
<th>Descripción</th>
<th>Estado</th>
<th>Costo</th>
<th>Detalle</th>
</tr>
</thead>
<tbody>
<?php while ($m = $resultado->fetch_assoc()): ?>
<tr>
<td><?= (int)$m['id_mantenimiento'] ?></td>
<td><?= htmlspecialchars($m['fecha']) ?></td>
<td><?= htmlspecialchars($m['codigo']) ?></td>
<td><?= htmlspecialchars($m['activo']) ?></td>
<td><?= htmlspecialchars($m['tipo']) ?></td>
<td><?= htmlspecialchars($m['descripcion']) ?></td>
<td><?= htmlspecialchars($m['estado_mantenimiento']) ?></td>
<td>$<?= number_format((float)$m['costo'], 2) ?></td>
<td>
<a href="verMantenimiento.php?id=<?= (int)$m['id_mantenimiento'] ?>"
   class="btn btn-sm btn-info">Ver</a>
</td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
<a href="mantenimientos.php" class="btn btn-secondary">Volver a mantenimientos</a>
</div>
</div>
</body>
</html>