<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
if (!in_array($rolActual, ['Administrador', 'Editor'], true)) {
    http_response_code(403);
    exit('No tienes permiso para actualizar mantenimientos.');
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: mantenimientos.php');
    exit;
}
$id = (int)($_POST['id_mantenimiento'] ?? 0);
$idActivo = (int)($_POST['id_activo'] ?? 0);
$idTipo = (int)($_POST['id_tipo_mantenimiento'] ?? 0);
$fecha = trim($_POST['fecha'] ?? '');
$fechaFalla = trim($_POST['fecha_falla'] ?? '');
$proximaFecha = trim($_POST['proxima_fecha'] ?? '');
$descripcion = trim($_POST['descripcion'] ?? '');
$reparacion = trim($_POST['reparacion_realizada'] ?? '');
$observaciones = trim($_POST['observaciones'] ?? '');
$costoTexto = $_POST['costo'] ?? '';
$estado = trim($_POST['estado_mantenimiento'] ?? '');
if (
    $id <= 0 || $idActivo <= 0 || $idTipo <= 0 ||
    $fecha === '' || $descripcion === '' ||
    !is_numeric($costoTexto) || (float)$costoTexto < 0 ||
    !in_array($estado, ['Pendiente', 'En proceso', 'Realizado'], true)
) {
    exit('Datos inválidos. Regresa al formulario e inténtalo nuevamente.');
}
$costo = (float)$costoTexto;
$stmt = $conn->prepare("
    UPDATE mantenimiento
    SET id_activo = ?, id_tipo_mantenimiento = ?, fecha = ?,
        fecha_falla = NULLIF(?, ''), descripcion = ?,
        reparacion_realizada = NULLIF(?, ''), costo = ?,
        observaciones = NULLIF(?, ''), estado_mantenimiento = ?,
        proxima_fecha = NULLIF(?, '')
    WHERE id_mantenimiento = ?
");
$stmt->bind_param(
    'iissssdsssi',
    $idActivo, $idTipo, $fecha, $fechaFalla, $descripcion,
    $reparacion, $costo, $observaciones, $estado, $proximaFecha, $id
);
if ($stmt->execute() && $stmt->affected_rows >= 0) {
    $stmt->close();
    header('Location: mantenimientos.php?mensaje=actualizado');
    exit;
}
$stmt->close();
exit('No se pudieron actualizar los datos.');