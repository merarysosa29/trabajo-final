<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
if (!in_array($rolActual, ['Administrador', 'Editor'], true)) {
    http_response_code(403);
    exit('No tienes permiso para registrar mantenimientos.');
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: mantenimientos.php');
    exit;
}
$idActivo = (int)($_POST['id_activo'] ?? 0);
$idTipo = (int)($_POST['id_tipo_mantenimiento'] ?? 0);
$idUsuario = (int)($_SESSION['id_usuario'] ?? 0);
$fecha = trim($_POST['fecha'] ?? '');
$fechaFalla = trim($_POST['fecha_falla'] ?? '');
$proximaFecha = trim($_POST['proxima_fecha'] ?? '');
$descripcion = trim($_POST['descripcion'] ?? '');
$reparacion = trim($_POST['reparacion_realizada'] ?? '');
$observaciones = trim($_POST['observaciones'] ?? '');
$costoTexto = $_POST['costo'] ?? '0';
$estado = trim($_POST['estado_mantenimiento'] ?? 'Pendiente');
$estadosPermitidos = ['Pendiente', 'En proceso', 'Realizado'];
if (
    $idActivo <= 0 || $idTipo <= 0 || $idUsuario <= 0 ||
    $fecha === '' || $descripcion === '' ||
    !is_numeric($costoTexto) || (float)$costoTexto < 0 ||
    !in_array($estado, $estadosPermitidos, true)
) {
    exit('Datos inválidos. Regresa al formulario y verifica los campos.');
}
$costo = (float)$costoTexto;
$validar = $conn->prepare("
    SELECT
        (SELECT COUNT(*) FROM activo WHERE id_activo = ?) AS activo_valido,
        (SELECT COUNT(*) FROM tipo_mantenimiento WHERE id_tipo_mantenimiento = ?) AS tipo_valido
");
$validar->bind_param('ii', $idActivo, $idTipo);
$validar->execute();
$validacion = $validar->get_result()->fetch_assoc();
$validar->close();
if (!$validacion || !$validacion['activo_valido'] || !$validacion['tipo_valido']) {
    exit('El activo o el tipo de mantenimiento seleccionado no existe.');
}
$sql = "INSERT INTO mantenimiento
(id_activo, id_tipo_mantenimiento, id_usuario, fecha, fecha_falla,
 descripcion, reparacion_realizada, costo, observaciones,
 estado_mantenimiento, proxima_fecha)
VALUES (?, ?, ?, ?, NULLIF(?, ''), ?, NULLIF(?, ''), ?,
        NULLIF(?, ''), ?, NULLIF(?, ''))";
$stmt = $conn->prepare($sql);
$stmt->bind_param(
    'iiissssdsss',
    $idActivo, $idTipo, $idUsuario, $fecha, $fechaFalla,
    $descripcion, $reparacion, $costo, $observaciones,
    $estado, $proximaFecha
);
if ($stmt->execute()) {
    $stmt->close();
    header('Location: mantenimientos.php?mensaje=registrado');
    exit;
}
$stmt->close();
exit('No se pudo guardar el mantenimiento. Verifica los datos e inténtalo nuevamente.');