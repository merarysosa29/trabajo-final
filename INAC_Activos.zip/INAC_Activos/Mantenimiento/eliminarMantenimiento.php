<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
if ($rolActual !== 'Administrador') {
    http_response_code(403);
    exit('Solo el Administrador puede eliminar mantenimientos.');
}
$id = filter_input(
    $_SERVER['REQUEST_METHOD'] === 'POST' ? INPUT_POST : INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);
if (!$id || $id <= 0) {
    header('Location: mantenimientos.php');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $conn->prepare("DELETE FROM mantenimiento WHERE id_mantenimiento = ?");
    $stmt->bind_param('i', $id);
    if ($stmt->execute() && $stmt->affected_rows === 1) {
        $stmt->close();
        header('Location: mantenimientos.php?mensaje=eliminado');
        exit;
    }
    $stmt->close();
    header('Location: mantenimientos.php?mensaje=error');
    exit;
}
$stmt = $conn->prepare("
    SELECT m.id_mantenimiento, m.fecha, m.descripcion, a.codigo, a.nombre
    FROM mantenimiento m
    INNER JOIN activo a ON m.id_activo = a.id_activo
    WHERE m.id_mantenimiento = ?
");
$stmt->bind_param('i', $id);
$stmt->execute();
$m = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$m) {
    exit('El mantenimiento no existe.');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Eliminar mantenimiento | INAC Activos</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background:#F4F6F8;font-family:Arial,sans-serif">
<div class="container" style="max-width:650px;margin:60px auto">
<div class="card border-0 shadow-sm">
<div class="card-body p-4">
<h4 class="text-danger">Confirmar eliminación</h4>
<p>¿Seguro que deseas eliminar este mantenimiento? Esta acción no se puede deshacer.</p>
<ul>
<li><strong>Activo:</strong> <?= htmlspecialchars($m['codigo'] . ' - ' . $m['nombre']) ?></li>
<li><strong>Fecha:</strong> <?= htmlspecialchars($m['fecha']) ?></li>
<li><strong>Descripción:</strong> <?= htmlspecialchars($m['descripcion']) ?></li>
</ul>
<form method="POST">
<input type="hidden" name="id" value="<?= (int)$m['id_mantenimiento'] ?>">
<button type="submit" class="btn btn-danger">Sí, eliminar</button>
<a href="mantenimientos.php" class="btn btn-secondary">Cancelar</a>
</form>
</div>
</div>
</div>
</body>
</html>