<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
$puedeEditar = in_array($rolActual, ['Administrador', 'Editor'], true);
$sql = "SELECT m.id_mantenimiento, m.fecha, m.descripcion,
               m.costo, m.estado_mantenimiento, m.proxima_fecha,
               a.codigo, a.nombre AS activo,
               tm.nombre AS tipo,
               u.nombre AS nombre_usuario,
               u.apellido AS apellido_usuario
        FROM mantenimiento m
        INNER JOIN activo a ON m.id_activo = a.id_activo
        INNER JOIN tipo_mantenimiento tm
            ON m.id_tipo_mantenimiento = tm.id_tipo_mantenimiento
        LEFT JOIN usuario u ON m.id_usuario = u.id_usuario
        ORDER BY m.fecha DESC, m.id_mantenimiento DESC";
$resultado = $conn->query($sql);
if (!$resultado) {
    die('Error al consultar mantenimientos: ' . htmlspecialchars($conn->error));
}
$mensaje = $_GET['mensaje'] ?? '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mantenimientos | INAC Activos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body {
            background: #F4F6F8;
            font-family: Arial, sans-serif;
        }
        .encabezado {
            background: #123B63;
            color: white;
            padding: 22px;
            border-radius: 12px;
            margin-bottom: 20px;
        }
        .tarjeta {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px #0000000d;
        }
        .btn-principal {
            background: #123B63;
            color: white;
        }
        .btn-principal:hover {
            background: #0b2c4a;
            color: white;
        }
        th {
            white-space: nowrap;
        }
    </style>
</head>
<body>
<div class="container-fluid p-3 p-md-4">
    <div class="encabezado">
        <h3>
            <i class="bi bi-tools"></i>
            Gestión de mantenimientos
        </h3>
        <p class="mb-0">
            Consulta y control de mantenimientos preventivos y correctivos.
        </p>
    </div>
    <?php
    $mensajes = [
        'registrado' => ['success', 'Mantenimiento registrado correctamente.'],
        'actualizado' => ['success', 'Mantenimiento actualizado correctamente.'],
        'eliminado' => ['success', 'Mantenimiento eliminado correctamente.'],
        'error' => ['danger', 'No se pudo completar la operación.']
    ];
    if (isset($mensajes[$mensaje])):
    ?>
        <div class="alert alert-<?= $mensajes[$mensaje][0] ?> alert-dismissible fade show">
            <?= htmlspecialchars($mensajes[$mensaje][1]) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if ($puedeEditar): ?>
        <div class="mb-3">
            <a href="nuevoMantenimiento.php" class="btn btn-principal">
                <i class="bi bi-plus-circle"></i>
                Nuevo mantenimiento
            </a>
        </div>
    <?php endif; ?>
    <div class="tarjeta">
        <div class="row mb-3">
            <div class="col-md-6">
                <input
                    type="search"
                    id="buscar"
                    class="form-control"
                    placeholder="Buscar por activo, código, tipo o estado..."
                >
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered table-hover" id="tabla">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Activo</th>
                        <th>Tipo</th>
                        <th>Fecha</th>
                        <th>Descripción</th>
                        <th>Costo</th>
                        <th>Estado</th>
                        <th>Próxima fecha</th>
                        <th>Registrado por</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($m = $resultado->fetch_assoc()): ?>
                    <tr>
                        <td>
                            <?= (int)$m['id_mantenimiento'] ?>
                        </td>
                        <td>
                            <?= htmlspecialchars($m['codigo']) ?><br>
                            <?= htmlspecialchars($m['activo']) ?>
                        </td>
                        <td>
                            <?= htmlspecialchars($m['tipo']) ?>
                        </td>
                        <td>
                            <?= htmlspecialchars($m['fecha']) ?>
                        </td>
                        <td>
                            <?= htmlspecialchars($m['descripcion']) ?>
                        </td>
                        <td>
                            $<?= number_format((float)$m['costo'], 2) ?>
                        </td>
                        <td>
                            <?= htmlspecialchars($m['estado_mantenimiento']) ?>
                        </td>
                        <td>
                            <?= htmlspecialchars($m['proxima_fecha'] ?? '') ?>
                        </td>
                        <td>
                            <?= htmlspecialchars(
                                trim(
                                    ($m['nombre_usuario'] ?? '') . ' ' .
                                    ($m['apellido_usuario'] ?? '')
                                ) ?: 'No disponible'
                            ) ?>
                        </td>
                        <td>
                            <a
                                href="verMantenimiento.php?id=<?= (int)$m['id_mantenimiento'] ?>"
                                class="btn btn-sm btn-info mb-1"
                                title="Ver detalles"
                            >
                                <i class="bi bi-eye"></i>
                            </a>
                            <?php if ($puedeEditar): ?>
                                <a
                                    href="editarMantenimiento.php?id=<?= (int)$m['id_mantenimiento'] ?>"
                                    class="btn btn-sm btn-primary mb-1"
                                    title="Editar"
                                >
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <?php if ($rolActual === 'Administrador'): ?>
                                    <a
                                        href="eliminarMantenimiento.php?id=<?= (int)$m['id_mantenimiento'] ?>"
                                        class="btn btn-sm btn-danger mb-1"
                                        title="Eliminar"
                                    >
                                        <i class="bi bi-trash"></i>
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
document.getElementById('buscar').addEventListener('input', function () {
    const texto = this.value.toLowerCase();
    document.querySelectorAll('#tabla tbody tr').forEach(fila => {
        fila.style.display = fila.textContent.toLowerCase().includes(texto)
            ? ''
            : 'none';
    });
});
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>