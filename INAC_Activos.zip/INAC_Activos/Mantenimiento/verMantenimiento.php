<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id || $id <= 0) {
    exit('Identificador inválido.');
}
$stmt = $conn->prepare("
    SELECT m.*, a.codigo, a.nombre AS nombre_activo,
           tm.nombre AS tipo,
           u.nombre AS nombre_usuario, u.apellido AS apellido_usuario
    FROM mantenimiento m
    INNER JOIN activo a ON m.id_activo = a.id_activo
    INNER JOIN tipo_mantenimiento tm
        ON m.id_tipo_mantenimiento = tm.id_tipo_mantenimiento
    LEFT JOIN usuario u ON m.id_usuario = u.id_usuario
    WHERE m.id_mantenimiento = ?
");
$stmt->bind_param('i', $id);
$stmt->execute();
$m = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$m) {
    exit('El mantenimiento solicitado no existe.');
}
function mostrarDato($dato) {
    return htmlspecialchars((string)($dato ?? 'No especificado'));
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Detalle de mantenimiento | INAC Activos</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:#F4F6F8;font-family:Arial,sans-serif}
.tarjeta{background:white;padding:24px;border-radius:12px;max-width:900px;margin:25px auto}
h3{color:#123B63}
.dato{padding:12px;border-bottom:1px solid #e9ecef}
</style>
</head>
<body>
<div class="container">
<div class="tarjeta">
<h3>Detalle del mantenimiento #<?= (int)$m['id_mantenimiento'] ?></h3>
<div class="row">
<?php
$campos = [
    'Activo' => $m['codigo'] . ' - ' . $m['nombre_activo'],
    'Tipo de mantenimiento' => $m['tipo'],
    'Fecha del mantenimiento' => $m['fecha'],
    'Fecha de la falla' => $m['fecha_falla'],
    'Descripción' => $m['descripcion'],
    'Reparación realizada' => $m['reparacion_realizada'],
    'Costo' => '$' . number_format((float)$m['costo'], 2),
    'Observaciones' => $m['observaciones'],
    'Estado' => $m['estado_mantenimiento'],
    'Próxima fecha' => $m['proxima_fecha'],
    'Registrado por' => trim(($m['nombre_usuario'] ?? '') . ' ' . ($m['apellido_usuario'] ?? '')) ?: 'No disponible'
];
foreach ($campos as $titulo => $valor):
?>
<div class="col-md-6 dato">
    <strong><?= htmlspecialchars($titulo) ?>:</strong><br>
    <?= mostrarDato($valor) ?>
</div>
<?php endforeach; ?>
</div>
<div class="mt-4">
<a href="mantenimientos.php" class="btn btn-secondary">Volver</a>
<?php if (in_array($rolActual, ['Administrador', 'Editor'], true)): ?>
<a href="editarMantenimiento.php?id=<?= (int)$m['id_mantenimiento'] ?>" class="btn btn-primary">Editar</a>
<?php endif; ?>
</div>
</div>
</div>
</body>
</html>