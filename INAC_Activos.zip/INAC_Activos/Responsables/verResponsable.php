<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
require_once 'funcionesResponsable.php';
$id=filter_input(INPUT_GET,'id',FILTER_VALIDATE_INT);
if(!$id || $id<1){header('Location: responsables.php?mensaje=error');exit;}
$stmt=$conn->prepare("SELECT r.*, (SELECT COUNT(*) FROM activo a WHERE a.id_responsable=r.id_responsable) AS total_activos FROM responsable r WHERE r.id_responsable=?");
$stmt->bind_param('i',$id);$stmt->execute();$r=$stmt->get_result()->fetch_assoc();$stmt->close();
if(!$r){header('Location: responsables.php?mensaje=error');exit;}
?>
<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Consultar responsable | INAC Activos</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet"><link href="../style.css" rel="stylesheet"><style>body{background:#F4F6F8;padding:22px}.panel{background:white;border-radius:12px;padding:24px;box-shadow:0 3px 12px #123b6310}.titulo{color:#123B63}.foto{width:130px;height:130px;object-fit:cover;border-radius:50%;border:3px solid #dce5ee}.foto-vacia{width:130px;height:130px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:#e8eef5;color:#123B63;font-size:54px}</style></head><body><main class="container">
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2"><div><h2 class="titulo mb-1"><i class="bi bi-person-vcard me-2"></i>Datos del responsable</h2><p class="text-secondary mb-0">Información registrada en el sistema.</p></div><a href="responsables.php" class="btn btn-outline-secondary">Volver</a></div>
<div class="panel"><div class="row g-4 align-items-start"><div class="col-md-3 text-center"><?php if(!empty($r['foto']) && is_file(__DIR__.'/'.$r['foto'])): ?><img class="foto" src="<?= h($r['foto']) ?>" alt="Fotografía de <?= h($r['nombre']) ?>"><?php else: ?><div class="foto-vacia mx-auto"><i class="bi bi-person"></i></div><?php endif; ?></div>
<div class="col-md-9"><h4 class="titulo"><?= h($r['nombre'].' '.$r['apellido']) ?></h4><span class="badge text-bg-<?= $r['estado']==='Activo'?'success':'secondary' ?> mb-3"><?= h($r['estado']) ?></span>
<div class="row g-3"><div class="col-sm-6"><strong>Cargo</strong><div><?= h($r['cargo'] ?: 'No especificado') ?></div></div><div class="col-sm-6"><strong>Teléfono</strong><div><?= h($r['telefono'] ?: 'No especificado') ?></div></div><div class="col-sm-6"><strong>Correo</strong><div><?= h($r['correo'] ?: 'No especificado') ?></div></div><div class="col-sm-6"><strong>Activos asignados</strong><div><?= (int)$r['total_activos'] ?></div></div><div class="col-sm-6"><strong>ID de responsable</strong><div><?= (int)$r['id_responsable'] ?></div></div></div>
<div class="mt-4"><a href="editarResponsable.php?id=<?= (int)$r['id_responsable'] ?>" class="btn btn-primary"><i class="bi bi-pencil me-1"></i>Editar</a></div></div></div></div></main></body></html>
