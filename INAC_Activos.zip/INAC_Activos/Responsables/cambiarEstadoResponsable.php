<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
if (!in_array($rolActual, ['Administrador', 'Editor'], true)) { http_response_code(403); exit('No tienes permiso para modificar responsables.'); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: responsables.php'); exit; }
if (empty($_SESSION['csrf_responsables']) || !hash_equals($_SESSION['csrf_responsables'], $_POST['csrf_token'] ?? '')) { header('Location: responsables.php?mensaje=error'); exit; }
$id=filter_var($_POST['id_responsable']??null,FILTER_VALIDATE_INT);
if(!$id || $id<1){header('Location: responsables.php?mensaje=error');exit;}
$stmt=$conn->prepare("UPDATE responsable SET estado=IF(estado='Activo','Inactivo','Activo') WHERE id_responsable=?");
$stmt->bind_param('i',$id);
if($stmt->execute() && $stmt->affected_rows===1){$stmt->close();header('Location: responsables.php?mensaje=estado');exit;}
$stmt->close();header('Location: responsables.php?mensaje=error');exit;
?>
