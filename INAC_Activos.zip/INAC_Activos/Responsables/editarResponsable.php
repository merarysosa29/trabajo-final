<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
require_once 'funcionesResponsable.php';
if (!in_array($rolActual, ['Administrador', 'Editor'], true)) { http_response_code(403); exit('No tienes permiso para editar responsables.'); }
if (empty($_SESSION['csrf_responsables'])) $_SESSION['csrf_responsables']=bin2hex(random_bytes(32));
$id=filter_input(INPUT_GET,'id',FILTER_VALIDATE_INT);
if(!$id || $id<1){header('Location: responsables.php?mensaje=error');exit;}
$stmt=$conn->prepare("SELECT * FROM responsable WHERE id_responsable=?");$stmt->bind_param('i',$id);$stmt->execute();$r=$stmt->get_result()->fetch_assoc();$stmt->close();
if(!$r){header('Location: responsables.php?mensaje=error');exit;}
$errores=['foto'=>'La fotografía no pasó la validación.','duplicado'=>'El correo o teléfono ya está registrado en otro responsable.','datos'=>'Revisa los campos obligatorios.'];
$error=$_SESSION['error_foto_responsable']??($errores[$_GET['error']??'']??'');unset($_SESSION['error_foto_responsable']);
?>
<!DOCTYPE html><html lang="es">
    <head><meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Editar responsable | INAC Activos</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet"><link href="../style.css" rel="stylesheet"><style>body{background:#F4F6F8;padding:22px;color:#263746}.panel{background:#fff;border-radius:12px;padding:24px;box-shadow:0 3px 12px #123b6310}.titulo{color:#123B63}.btn-principal{background:#123B63;color:#fff}.btn-principal:hover{background:#2F80ED;color:#fff}.preview{width:100px;height:100px;object-fit:cover;border-radius:50%;border:2px solid #dce5ee;background:#edf2f7}</style></head><body><main class="container">
<h2 class="titulo mb-1"><i class="bi bi-pencil-square me-2"></i>Editar responsable</h2><p class="text-secondary mb-4">Actualiza la información del responsable.</p>
<?php if($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>
<div class="panel"><form method="POST" action="actualizarResponsable.php" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_responsables']) ?>"><input type="hidden" name="id_responsable" value="<?= (int)$r['id_responsable'] ?>">
<div class="row g-3">
<div class="col-md-6"><label class="form-label" for="nombre">Nombre *</label><input class="form-control" id="nombre" name="nombre" maxlength="100" value="<?= h($r['nombre']) ?>" required></div>
<div class="col-md-6"><label class="form-label" for="apellido">Apellido *</label><input class="form-control" id="apellido" name="apellido" maxlength="100" value="<?= h($r['apellido']) ?>" required></div>
<div class="col-md-4"><label class="form-label" for="cargo">Cargo</label><input class="form-control" id="cargo" name="cargo" maxlength="100" value="<?= h($r['cargo']) ?>"></div>
<div class="col-md-4"><label class="form-label" for="telefono">Teléfono</label><input class="form-control" id="telefono" name="telefono" maxlength="30" value="<?= h($r['telefono']) ?>"></div>
<div class="col-md-4">
    <label class="form-label" for="correo">Correo electrónico</label><input type="email" class="form-control" id="correo" name="correo" maxlength="100" value="<?= h($r['correo']) ?>">
    </div>
<div class="col-md-4"><label class="form-label" for="estado">Estado</label><select class="form-select" id="estado" name="estado"><option value="Activo" <?= $r['estado']==='Activo'?'selected':'' ?>>Activo</option><option value="Inactivo" <?= $r['estado']==='Inactivo'?'selected':'' ?>>Inactivo</option></select></div>
<div class="col-md-8"><label class="form-label" for="foto">Cambiar fotografía (opcional)</label><input type="file" class="form-control" id="foto" name="foto" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"><div class="form-text">Si no seleccionas otra imagen, se conservará la actual. JPG, PNG o WEBP, máximo 2 MB. La API comprobará que sea una persona.</div></div>
<div class="col-12 d-flex align-items-center gap-3">
<?php if(!empty($r['foto']) && is_file(__DIR__.'/'.$r['foto'])): ?><img id="vistaFoto" class="preview" src="<?= h($r['foto']) ?>" alt="Fotografía actual"><?php else: ?><img id="vistaFoto" class="preview" src="" alt="Vista previa" hidden><?php endif; ?><span id="textoFoto" class="text-secondary small">Fotografía actual</span></div>
<div class="col-12 d-flex gap-2"><button class="btn btn-principal" type="submit"><i class="bi bi-save me-1"></i>Guardar cambios</button><a href="responsables.php" class="btn btn-outline-secondary">Cancelar</a></div>
</div></form></div></main><script>document.getElementById('foto').addEventListener('change',function(){const f=this.files[0],v=document.getElementById('vistaFoto');if(f){v.src=URL.createObjectURL(f);v.hidden=false;document.getElementById('textoFoto').textContent='Nueva fotografía seleccionada';}});
    </script>
    </body>
</html>
