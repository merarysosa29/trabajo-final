<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
require_once 'funcionesResponsable.php';
if (!in_array($rolActual, ['Administrador', 'Editor'], true)) {
    http_response_code(403);
    exit('No tienes permiso para editar responsables.');
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: responsables.php');
    exit;
}
if (
    empty($_SESSION['csrf_responsables']) ||
    !hash_equals(
        $_SESSION['csrf_responsables'],
        $_POST['csrf_token'] ?? ''
    )
) {
    header('Location: responsables.php?mensaje=error');
    exit;
}
$id       = filter_var($_POST['id_responsable'] ?? null, FILTER_VALIDATE_INT);
$nombre   = trim($_POST['nombre'] ?? '');
$apellido = trim($_POST['apellido'] ?? '');
$cargo    = trim($_POST['cargo'] ?? '');
$telefono = trim($_POST['telefono'] ?? '');
$correo   = trim($_POST['correo'] ?? '');
$estado   = $_POST['estado'] ?? 'Activo';
if (
    !$id || $id < 1 ||
    $nombre === '' ||
    $apellido === '' ||
    mb_strlen($nombre) > 100 ||
    mb_strlen($apellido) > 100 ||
    mb_strlen($cargo) > 100 ||
    mb_strlen($telefono) > 30 ||
    mb_strlen($correo) > 100 ||
    !in_array($estado, ['Activo', 'Inactivo'], true) ||
    ($correo !== '' && !filter_var($correo, FILTER_VALIDATE_EMAIL))
) {
    header('Location: editarResponsable.php?id=' . (int)$id . '&error=datos');
    exit;
}
$stmt = $conn->prepare(
    "SELECT foto FROM responsable WHERE id_responsable = ?"
);
$stmt->bind_param('i', $id);
$stmt->execute();
$actual = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$actual) {
    header('Location: responsables.php?mensaje=error');
    exit;
}
$sql = "SELECT id_responsable
        FROM responsable
        WHERE (
            (? <> '' AND correo = ?)
            OR (? <> '' AND telefono = ?)
            OR (
                LOWER(TRIM(nombre)) = LOWER(TRIM(?))
                AND LOWER(TRIM(apellido)) = LOWER(TRIM(?))
            )
        )
        AND id_responsable <> ?
        LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param(
    'ssssssi',
    $correo,
    $correo,
    $telefono,
    $telefono,
    $nombre,
    $apellido,
    $id
);
$stmt->execute();
$existe = $stmt->get_result()->fetch_assoc();
$stmt->close();
if ($existe) {
    header('Location: editarResponsable.php?id=' . $id . '&error=duplicado');
    exit;
}
$fotoNueva = null;
$fotoFinal = $actual['foto'] ?? null;

if (
    isset($_FILES['foto']) &&
    $_FILES['foto']['error'] !== UPLOAD_ERR_NO_FILE
) {
    if ($_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
        $_SESSION['error_foto_responsable'] =
            'No se pudo recibir la nueva fotografía.';
        header('Location: editarResponsable.php?id=' . $id . '&error=foto');
        exit;
    }
    $validacion = validarFotoResponsable($_FILES['foto']);
    if (empty($validacion['ok']) || !empty($validacion['sin_foto'])) {
        $_SESSION['error_foto_responsable'] =
            $validacion['mensaje'] ?? 'La fotografía no es válida.';
        header('Location: editarResponsable.php?id=' . $id . '&error=foto');
        exit;
    }
    $fotoNueva = guardarFotoResponsable($validacion);
    if ($fotoNueva === false || empty($fotoNueva)) {
        $_SESSION['error_foto_responsable'] =
            'No se pudo guardar la nueva fotografía.';
        header('Location: editarResponsable.php?id=' . $id . '&error=foto');
        exit;
    }
    $fotoFinal = $fotoNueva;
}
$stmt = $conn->prepare(
    "UPDATE responsable
     SET nombre = ?, apellido = ?, cargo = ?, telefono = ?,
         correo = ?, estado = ?, foto = ?
     WHERE id_responsable = ?"
);
$stmt->bind_param(
    'sssssssi',
    $nombre,
    $apellido,
    $cargo,
    $telefono,
    $correo,
    $estado,
    $fotoFinal,
    $id
);
if ($stmt->execute()) {
    $stmt->close();
    if ($fotoNueva && !empty($actual['foto'])) {
        eliminarFotoResponsable($actual['foto']);
    }
    header('Location: responsables.php?mensaje=actualizado');
    exit;
}
$stmt->close();
if ($fotoNueva) {
    eliminarFotoResponsable($fotoNueva);
}
header('Location: responsables.php?mensaje=error');
exit;