<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
require_once 'funcionesResponsable.php';
if (!in_array($rolActual, ['Administrador', 'Editor'], true)) {
    http_response_code(403);
    exit('No tienes permiso para registrar responsables.');
}
if (empty($_SESSION['csrf_responsables'])) {
    $_SESSION['csrf_responsables'] = bin2hex(random_bytes(32));
}
$errores = [
    'foto' => 'La fotografía no pasó la validación. Selecciona una imagen válida de una persona.',
    'duplicado' => 'Ya existe un responsable con ese nombre y apellido, correo o teléfono.',
    'datos' => 'Revisa los campos obligatorios.',
    'api' => 'No se pudo validar la fotografía. Inténtalo nuevamente.'
];
$error = $_SESSION['error_foto_responsable']
    ?? ($errores[$_GET['error'] ?? ''] ?? '');

unset($_SESSION['error_foto_responsable']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Nuevo responsable | INAC Activos</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="../style.css" rel="stylesheet">
<style>
body {
    background: #F4F6F8;
    padding: 22px;
    color: #263746;
}
.panel {
    background: #fff;
    border-radius: 12px;
    padding: 24px;
    box-shadow: 0 3px 12px #123b6310;
}
.titulo { color: #123B63; }
.btn-principal {
    background: #123B63;
    color: #fff;
}
.btn-principal:hover {
    background: #2F80ED;
    color: #fff;
}
.preview {
    width: 120px;
    height: 120px;
    object-fit: cover;
    border-radius: 50%;
    border: 2px solid #dce5ee;
    background: #edf2f7;
}
</style>
</head>
<body>
<main class="container">
<h2 class="titulo mb-1">
    <i class="bi bi-person-plus me-2"></i>Registrar responsable
</h2>
<p class="text-secondary mb-4">
    Completa los datos de la persona encargada.
</p>
<?php if ($error): ?>
<div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>
<div class="panel">
<form method="POST" action="guardarResponsable.php" enctype="multipart/form-data">
<input type="hidden" name="csrf_token"
       value="<?= h($_SESSION['csrf_responsables']) ?>">
<div class="row g-3">
    <div class="col-md-6">
        <label class="form-label" for="nombre">Nombre *</label>
        <input class="form-control" id="nombre" name="nombre"
               maxlength="100" required>
    </div>
    <div class="col-md-6">
        <label class="form-label" for="apellido">Apellido *</label>
        <input class="form-control" id="apellido" name="apellido"
               maxlength="100" required>
    </div>
    <div class="col-md-4">
        <label class="form-label" for="cargo">Cargo</label>
        <input class="form-control" id="cargo" name="cargo"
               maxlength="100">
    </div>
    <div class="col-md-4">
        <label class="form-label" for="telefono">Teléfono</label>
        <input class="form-control" id="telefono" name="telefono"
               maxlength="30">
    </div>
    <div class="col-md-4">
        <label class="form-label" for="correo">Correo electrónico</label>
        <input type="email" class="form-control" id="correo"
               name="correo" maxlength="100">
    </div>
    <div class="col-md-6">
        <label class="form-label" for="estado">Estado</label>
        <select class="form-select" id="estado" name="estado">
            <option value="Activo">Activo</option>
            <option value="Inactivo">Inactivo</option>
        </select>
    </div>
    <div class="col-md-6">
        <label class="form-label" for="foto">Fotografía *</label>
        <input type="file" class="form-control" id="foto"
               name="foto"
               accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
               required>
        <div class="form-text">
            Selecciona una fotografía de una persona.
            Formatos JPG, PNG o WEBP; máximo 2 MB.
            La imagen será validada antes de guardarse.
        </div>
    </div>
    <div class="col-12 d-flex align-items-center gap-3">
        <img id="vistaFoto" class="preview" src=""
             alt="Vista previa de la fotografía" hidden>
        <span id="textoFoto" class="text-secondary small">
            Aquí aparecerá la fotografía seleccionada.
        </span>
    </div>
    <div class="col-12 d-flex gap-2">
        <button class="btn btn-principal" type="submit">
            <i class="bi bi-save me-1"></i>Guardar responsable
        </button>
        <a href="responsables.php" class="btn btn-outline-secondary">
            Cancelar
        </a>
    </div>
</div>
</form>
</div>
</main>
<script>
const entrada = document.getElementById('foto');
const vista = document.getElementById('vistaFoto');
const texto = document.getElementById('textoFoto');

entrada.addEventListener('change', () => {
    const archivo = entrada.files[0];
    if (!archivo) {
        vista.hidden = true;
        vista.removeAttribute('src');
        texto.hidden = false;
        return;
    }
    if (archivo.size > 2 * 1024 * 1024) {
        alert('La fotografía no puede superar los 2 MB.');
        entrada.value = '';
        vista.hidden = true;
        vista.removeAttribute('src');
        texto.hidden = false;
        return;
    }
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(archivo.type)) {
        alert('Selecciona una imagen JPG, PNG o WEBP.');
        entrada.value = '';
        vista.hidden = true;
        vista.removeAttribute('src');
        texto.hidden = false;
        return;
    }
    vista.src = URL.createObjectURL(archivo);
    vista.hidden = false;
    texto.hidden = true;
});
</script>
</body>
</html>