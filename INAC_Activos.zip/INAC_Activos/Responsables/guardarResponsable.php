<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
require_once 'funcionesResponsable.php';

if (!in_array($rolActual, ['Administrador', 'Editor'], true)) {
    http_response_code(403);
    exit('No tienes permiso para registrar responsables.');
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: nuevoResponsable.php');
    exit;
}
if (
    empty($_SESSION['csrf_responsables']) ||
    !hash_equals(
        $_SESSION['csrf_responsables'],
        $_POST['csrf_token'] ?? ''
    )
) {
    header('Location: nuevoResponsable.php?error=datos');
    exit;
}
$nombre   = trim($_POST['nombre'] ?? '');
$apellido = trim($_POST['apellido'] ?? '');
$cargo    = trim($_POST['cargo'] ?? '');
$telefono = trim($_POST['telefono'] ?? '');
$correo   = trim($_POST['correo'] ?? '');
$estado   = $_POST['estado'] ?? 'Activo';
if (
    $nombre === '' ||
    $apellido === '' ||
    mb_strlen($nombre) > 100 ||
    mb_strlen($apellido) > 100 ||
    mb_strlen($cargo) > 100 ||
    mb_strlen($telefono) > 30 ||
    mb_strlen($correo) > 100 ||
    !in_array($estado, ['Activo', 'Inactivo'], true) ||
    ($correo !== '' && !filter_var($correo, FILTER_VALIDATE_EMAIL))
) {
    header('Location: nuevoResponsable.php?error=datos');
    exit;
}
$sql = "SELECT id_responsable
        FROM responsable
        WHERE
            (? <> '' AND correo = ?)
            OR (? <> '' AND telefono = ?)
            OR (
                LOWER(TRIM(nombre)) = LOWER(TRIM(?))
                AND LOWER(TRIM(apellido)) = LOWER(TRIM(?))
            )
        LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param(
    'ssssss',
    $correo,
    $correo,
    $telefono,
    $telefono,
    $nombre,
    $apellido
);
$stmt->execute();
$existe = $stmt->get_result()->fetch_assoc();
$stmt->close();
if ($existe) {
    header('Location: nuevoResponsable.php?error=duplicado');
    exit;
}
if (
    !isset($_FILES['foto']) ||
    $_FILES['foto']['error'] === UPLOAD_ERR_NO_FILE
) {
    $_SESSION['error_foto_responsable'] =
        'Debes seleccionar una fotografía de una persona.';
    header('Location: nuevoResponsable.php?error=foto');
    exit;
}
if ($_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
    $_SESSION['error_foto_responsable'] =
        'No se pudo recibir la fotografía. Inténtalo nuevamente.';
    header('Location: nuevoResponsable.php?error=foto');
    exit;
}
$validacion = validarFotoResponsable($_FILES['foto']);
if (empty($validacion['ok']) || !empty($validacion['sin_foto'])) {
    $_SESSION['error_foto_responsable'] =
        $validacion['mensaje'] ?? 'La fotografía no es válida.';
    header('Location: nuevoResponsable.php?error=foto');
    exit;
}
$foto = guardarFotoResponsable($validacion);
if ($foto === false || empty($foto)) {
    $_SESSION['error_foto_responsable'] =
        'No se pudo guardar la fotografía.';
    header('Location: nuevoResponsable.php?error=foto');
    exit;
}
$stmt = $conn->prepare(
    "INSERT INTO responsable
    (nombre, apellido, cargo, telefono, correo, estado, foto)
    VALUES (?, ?, ?, ?, ?, ?, ?)"
);
$stmt->bind_param(
    'sssssss',
    $nombre,
    $apellido,
    $cargo,
    $telefono,
    $correo,
    $estado,
    $foto
);
if ($stmt->execute()) {
    $stmt->close();
    header('Location: responsables.php?mensaje=guardado');
    exit;
}
$stmt->close();
eliminarFotoResponsable($foto);

if ($conn->errno === 1062) {
    header('Location: nuevoResponsable.php?error=duplicado');
    exit;
}
header('Location: responsables.php?mensaje=error');
exit;