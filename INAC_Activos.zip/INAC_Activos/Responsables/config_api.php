<?php
define('GROQ_API_KEY', '');
define('GROQ_VISION_MODEL', 'qwen/qwen3.8-27b');