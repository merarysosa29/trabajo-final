<?php
require_once __DIR__ . '/config_api.php';
function h($valor) {
    return htmlspecialchars((string)($valor ?? ''), ENT_QUOTES, 'UTF-8');
}
function redirigirResponsables($parametro) {
    header('Location: responsables.php?' . $parametro);
    exit;
}
function validarFotoResponsable($archivo) {
    if (!isset($archivo) || $archivo['error'] === UPLOAD_ERR_NO_FILE) {
        return [
            'ok' => false,
            'sin_foto' => true,
            'mensaje' => 'Debes subir una fotografía donde aparezca una persona.'
        ];
    }
    if ($archivo['error'] !== UPLOAD_ERR_OK) {
        return [
            'ok' => false,
            'mensaje' => 'No se pudo subir la fotografía. Intenta nuevamente.'
        ];
    }
    if (
        !is_uploaded_file($archivo['tmp_name']) ||
        $archivo['size'] <= 0 ||
        $archivo['size'] > 2 * 1024 * 1024
    ) {
        return [
            'ok' => false,
            'mensaje' => 'La fotografía debe pesar menos de 2 MB.'
        ];
    }
    $info = @getimagesize($archivo['tmp_name']);
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($archivo['tmp_name']);
    $permitidos = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp'
    ];

    if (
        !$info ||
        !isset($permitidos[$mime]) ||
        $info[0] < 80 ||
        $info[1] < 80
    ) {
        return [
            'ok' => false,
            'mensaje' => 'Sube una imagen JPG, PNG o WEBP válida, de al menos 80 × 80 píxeles.'
        ];
    }
    if (
    !defined('GROQ_API_KEY') ||
    GROQ_API_KEY === '' ||
    GROQ_API_KEY === '...'
) {
        return [
            'ok' => false,
            'mensaje' => 'No está configurada la clave de Groq para validar la fotografía.'
        ];
    }
    $contenido = file_get_contents($archivo['tmp_name']);
    if ($contenido === false) {
        return [
            'ok' => false,
            'mensaje' => 'No se pudo leer la fotografía.'
        ];
    }
    $dataUrl = 'data:' . $mime . ';base64,' . base64_encode($contenido);
    $payload = [
        'model' => GROQ_VISION_MODEL,
        'messages' => [
            [
                'role' => 'user',
                'content' => [
                    [
                        'type' => 'text',
                        'text' => 'Determina si esta imagen contiene al menos una persona real visible. Responde únicamente JSON con las claves "persona" (boolean) y "motivo" (texto breve en español). persona=true si se distingue claramente al menos una persona real, aunque aparezca de cuerpo completo, en grupo, de perfil, a distancia o como parte de una fotografía normal. No exijas un retrato individual ni un fondo específico. persona=false si la imagen muestra únicamente objetos, animales, paisajes, logos, texto, dibujos, ilustraciones, avatares o personas que no pueden distinguirse claramente como reales. Si se rechaza, explica brevemente la razón. No identifiques a nadie ni infieras atributos personales.'
                    ],
                    [
                        'type' => 'image_url',
                        'image_url' => [
                            'url' => $dataUrl
                        ]
                    ]
                ]
            ]
        ],
        'temperature' => 0,
        'max_tokens' => 100,
        'response_format' => [
            'type' => 'json_object'
        ]
    ];
    $ch = curl_init('https://api.groq.com/openai/v1/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . GROQ_API_KEY,
            'Content-Type: application/json'
        ],
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 35
    ]);
    $respuesta = curl_exec($ch);
    $errorCurl = curl_error($ch);
    $codigoHttp = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if (
        $respuesta === false ||
        $codigoHttp < 200 ||
        $codigoHttp >= 300
    ) {
        error_log(
            'Error API Groq foto responsable. HTTP ' .
            $codigoHttp . ' ' . $errorCurl
        );
        return [
            'ok' => false,
            'mensaje' => 'No se pudo validar la fotografía. Intenta nuevamente más tarde.'
        ];
    }
    $datos = json_decode($respuesta, true);
    $texto = $datos['choices'][0]['message']['content'] ?? '';
    $evaluacion = json_decode($texto, true);
    if (
        !is_array($evaluacion) ||
        !array_key_exists('persona', $evaluacion) ||
        !is_bool($evaluacion['persona'])
    ) {
        return [
            'ok' => false,
            'mensaje' => 'No se pudo confirmar si aparece una persona. Prueba con otra fotografía.'
        ];
    }
    if ($evaluacion['persona'] !== true) {
        $motivo = trim(
            (string) (
                $evaluacion['motivo'] ??
                'No se distingue claramente a una persona real.'
            )
        );
        if ($motivo === '') {
            $motivo = 'No se distingue claramente a una persona real.';
        }
        return [
            'ok' => false,
            'mensaje' => 'Fotografía rechazada: ' . mb_substr($motivo, 0, 180)
        ];
    }
    return [
        'ok' => true,
        'sin_foto' => false,
        'mensaje' => '',
        'temporal' => $archivo['tmp_name'],
        'extension' => $permitidos[$mime]
    ];
}
function guardarFotoResponsable($validacion) {
    if (
        empty($validacion['ok']) ||
        !empty($validacion['sin_foto'])
    ) {
        return null;
    }
    $directorio = __DIR__ . '/uploads';
    if (
        !is_dir($directorio) &&
        !mkdir($directorio, 0755, true)
    ) {
        return false;
    }
    $nombre = 'responsable_' .
        bin2hex(random_bytes(16)) .
        '.' .
        $validacion['extension'];
    $destino = $directorio . '/' . $nombre;
    if (!move_uploaded_file($validacion['temporal'], $destino)) {
        return false;
    }
    return 'uploads/' . $nombre;
}
function eliminarFotoResponsable($ruta) {
    if (!$ruta || strpos($ruta, 'uploads/') !== 0) {
        return;
    }
    $archivo = __DIR__ . '/' . $ruta;
    if (is_file($archivo)) {
        @unlink($archivo);
    }
}