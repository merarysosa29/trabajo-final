<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
require_once 'funcionesResponsable.php';
$puedeEditar = in_array($rolActual, ['Administrador', 'Editor'], true);
if (empty($_SESSION['csrf_responsables'])) {
    $_SESSION['csrf_responsables'] = bin2hex(random_bytes(32));
}
$buscar = trim($_GET['buscar'] ?? '');
$mensajes = [
    'guardado' => ['success', 'Responsable registrado correctamente.'],
    'actualizado' => ['success', 'Responsable actualizado correctamente.'],
    'estado' => ['success', 'Estado actualizado correctamente.'],
    'error' => ['danger', 'No se pudo completar la operación.'],
    'duplicado' => ['warning', 'El correo, teléfono o nombre completo ya está registrado en otro responsable.']
];
$aviso = $mensajes[$_GET['mensaje'] ?? ''] ?? null;
$sql = "SELECT
            r.id_responsable,
            r.nombre,
            r.apellido,
            r.cargo,
            r.telefono,
            r.correo,
            r.estado,
            r.foto,
            COUNT(a.id_activo) AS total_activos
        FROM responsable r
        LEFT JOIN activo a
            ON a.id_responsable = r.id_responsable";
if ($buscar !== '') {
    $sql .= " WHERE r.nombre LIKE ?
              OR r.apellido LIKE ?
              OR r.cargo LIKE ?
              OR r.correo LIKE ?
              OR r.telefono LIKE ?";
}
$sql .= " GROUP BY
              r.id_responsable,
              r.nombre,
              r.apellido,
              r.cargo,
              r.telefono,
              r.correo,
              r.estado,
              r.foto
          ORDER BY r.id_responsable ASC";
$stmt = mysqli_prepare($conn, $sql);
if (!$stmt) {
    exit('Error al preparar la consulta de responsables.');
}
if ($buscar !== '') {
    $filtro = '%' . $buscar . '%';
    mysqli_stmt_bind_param($stmt, 'sssss', $filtro, $filtro, $filtro, $filtro, $filtro);
}
mysqli_stmt_execute($stmt);
$responsables = mysqli_stmt_get_result($stmt);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Responsables | INAC Activos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="../style.css" rel="stylesheet">
    <style>
        body {
            background: #F4F6F8;
            color: #263746;
            padding: 22px;
        }
        .encabezado {
            background: #123B63;
            color: #fff;
            border-radius: 12px;
            padding: 22px;
            margin-bottom: 18px;
        }
        .tarjeta {
            border: 0;
            border-radius: 12px;
            box-shadow: 0 3px 12px #123b6310;
        }
        .btn-principal {
            background: #123B63;
            color: #fff;
        }
        .btn-principal:hover {
            background: #2F80ED;
            color: #fff;
        }
        .tabla thead th {
            background: #123B63;
            color: #fff;
            white-space: nowrap;
        }
        .foto-persona {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #e2e8f0;
        }
        .acciones {
            white-space: nowrap;
        }
        @media (max-width: 576px) {
            body {
                padding: 10px;
            }
            .encabezado {
                padding: 16px;
            }
        }
    </style>
    <script src="../JavaScript/script.js" defer></script>
</head>
<body>
<main class="container-fluid">
    <header class="encabezado d-flex flex-wrap justify-content-between align-items-center gap-3">
        <div>
            <h2 class="mb-1">
                <i class="bi bi-person-badge me-2"></i>
                Gestión de responsables
            </h2>
            <p class="mb-0">
                Personas encargadas de los activos institucionales.
            </p>
        </div>
        <?php if ($puedeEditar): ?>
            <a href="nuevoResponsable.php" class="btn btn-light">
                <i class="bi bi-plus-circle me-1"></i>
                Registrar responsable
            </a>
        <?php endif; ?>
    </header>
    <?php if ($aviso): ?>
        <div class="alert alert-<?= h($aviso[0]) ?> alert-dismissible fade show" role="alert">
            <?= h($aviso[1]) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
        </div>
    <?php endif; ?>
    <section class="card tarjeta p-3 mb-3">
        <form method="GET" class="row g-2">
            <div class="col-md-9">
                <input type="search" name="buscar" class="form-control" placeholder="Buscar por nombre, cargo, teléfono o correo" value="<?= h($buscar) ?>">
            </div>
            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-principal flex-fill">
                    <i class="bi bi-search me-1"></i>
                    Buscar
                </button>
                <a href="responsables.php" class="btn btn-outline-secondary">Limpiar</a>
            </div>
        </form>
    </section>
    <section class="card tarjeta">
        <div class="table-responsive p-2">
            <table class="table table-hover align-middle tabla mb-0">
                <thead>
                    <tr>
                        <th>Foto</th>
                        <th>ID</th>
                        <th>Nombre completo</th>
                        <th>Cargo</th>
                        <th>Teléfono</th>
                        <th>Correo</th>
                        <th>Activos asignados</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($responsables && mysqli_num_rows($responsables) > 0): ?>
                    <?php while ($r = mysqli_fetch_assoc($responsables)): ?>
                        <tr>
                            <td>
                                <?php
                                $rutaFoto = 'IMG/default.jpg';
                                if (!empty($r['foto'])) {
                                    $fotoGuardada = $r['foto'];
                                    if (is_file(__DIR__ . '/' . $fotoGuardada)) {
                                        $rutaFoto = $fotoGuardada;
                                    }
                                }
                                ?>
                                <img class="foto-persona" src="<?= h($rutaFoto) ?>" alt="Fotografía de <?= h($r['nombre']) ?>" onerror="this.onerror=null;this.src='IMG/default.jpg';">
                            </td>
                            <td><?= (int)$r['id_responsable'] ?></td>
                            <td><?= h($r['nombre'] . ' ' . $r['apellido']) ?></td>
                            <td><?= h($r['cargo'] ?: 'No especificado') ?></td>
                            <td><?= h($r['telefono'] ?: 'No especificado') ?></td>
                            <td><?= h($r['correo'] ?: 'No especificado') ?></td>
                            <td><?= (int)$r['total_activos'] ?></td>
                            <td>
                                <span class="badge text-bg-<?= $r['estado'] === 'Activo' ? 'success' : 'secondary' ?>">
                                    <?= h($r['estado']) ?>
                                </span>
                            </td>
                            <td class="acciones">
                                <a class="btn btn-sm btn-outline-primary" href="verResponsable.php?id=<?= (int)$r['id_responsable'] ?>" title="Ver">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <?php if ($puedeEditar): ?>
                                    <a class="btn btn-sm btn-outline-warning" href="editarResponsable.php?id=<?= (int)$r['id_responsable'] ?>" title="Editar">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form method="POST" action="cambiarEstadoResponsable.php" class="d-inline" data-confirm="¿Confirmas que deseas cambiar el estado de este responsable?" data-confirm-type="estado">
                                        <input type="hidden" name="id_responsable" value="<?= (int)$r['id_responsable'] ?>">
                                        <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_responsables']) ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-secondary" title="Cambiar estado">
                                            <i class="bi bi-arrow-repeat"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center py-4 text-secondary">
                            No se encontraron responsables.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
    <div class="mt-3">
        <a href="../Index.php" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>
            Volver al inicio
        </a>
    </div>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
mysqli_stmt_close($stmt);
?>