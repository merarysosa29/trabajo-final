<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
/* Solo Administrador y Editor pueden dar de baja activos. */
if (!in_array($rolActual, ['Administrador', 'Editor'], true)) {
    header('Location: activos.php?sin_permiso=1');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: activos.php');
    exit;
}
$idActivo = filter_input(INPUT_POST, 'id_activo', FILTER_VALIDATE_INT);

if (!$idActivo || $idActivo < 1) {
    header('Location: activos.php?error_baja=1');
    exit;
}
$transaccionIniciada = false;
try {
    if (!$conn->begin_transaction()) {
        throw new Exception('No se pudo iniciar la transacción.');
    }
    $transaccionIniciada = true;
    $sqlEstado = "SELECT id_estado
                  FROM estado_activo
                  WHERE LOWER(TRIM(nombre_estado)) = 'baja'
                  LIMIT 1";
    $resultadoEstado = mysqli_query($conn, $sqlEstado);
    if (!$resultadoEstado) {
        throw new Exception('No se pudo consultar el catálogo de estados.');
    }
    $filaEstado = mysqli_fetch_assoc($resultadoEstado);
    if (!$filaEstado) {
        throw new Exception('No se encontró el estado Baja.');
    }
    $idEstadoBaja = (int)$filaEstado['id_estado'];
    $stmt = mysqli_prepare(
        $conn,
        "SELECT id_activo, id_estado
         FROM activo
         WHERE id_activo = ?
         LIMIT 1
         FOR UPDATE"
    );
    if (!$stmt) {
        throw new Exception('No se pudo preparar la consulta del activo.');
    }
    mysqli_stmt_bind_param($stmt, 'i', $idActivo);
    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        throw new Exception('No se pudo consultar el activo.');
    }
    $resultadoActivo = mysqli_stmt_get_result($stmt);
    $activo = mysqli_fetch_assoc($resultadoActivo);
    mysqli_stmt_close($stmt);
    if (!$activo) {
        throw new Exception('El activo no existe.');
    }
    if ((int)$activo['id_estado'] !== $idEstadoBaja) {
        $stmtActualizar = mysqli_prepare(
            $conn,
            "UPDATE activo
             SET id_estado = ?
             WHERE id_activo = ?"
        );
        if (!$stmtActualizar) {
            throw new Exception('No se pudo preparar la actualización del estado.');
        }
        mysqli_stmt_bind_param(
            $stmtActualizar,
            'ii',
            $idEstadoBaja,
            $idActivo
        );
        if (!mysqli_stmt_execute($stmtActualizar)) {
            mysqli_stmt_close($stmtActualizar);
            throw new Exception('No se pudo actualizar el estado del activo.');
        }
        mysqli_stmt_close($stmtActualizar);
    }
    $stmtAsignacion = mysqli_prepare(
        $conn,
        "UPDATE asignacion_activo
         SET fecha_fin = CURDATE()
         WHERE id_activo = ?
           AND fecha_fin IS NULL"
    );
    if (!$stmtAsignacion) {
        throw new Exception('No se pudo preparar el cierre de la asignación.');
    }
    mysqli_stmt_bind_param($stmtAsignacion, 'i', $idActivo);
    if (!mysqli_stmt_execute($stmtAsignacion)) {
        mysqli_stmt_close($stmtAsignacion);
        throw new Exception('No se pudo cerrar la asignación vigente.');
    }
    mysqli_stmt_close($stmtAsignacion);
    if (!$conn->commit()) {
        throw new Exception('No se pudieron confirmar los cambios.');
    }
    $transaccionIniciada = false;
    header('Location: activos.php?baja=1');
    exit;
} catch (Throwable $e) {
    if ($transaccionIniciada) {
        $conn->rollback();
    }
    error_log(
        'Error al dar de baja el activo ' . (int)$idActivo .
        ': ' . $e->getMessage()
    );
    header('Location: activos.php?error_baja=1');
    exit;
}
?>