<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
if (!in_array($rolActual, ['Administrador', 'Editor'], true)) {
    http_response_code(403);
    exit('No tienes permiso para editar activos.');
}
function e($valor) {
    return htmlspecialchars((string)($valor ?? ''), ENT_QUOTES, 'UTF-8');
}
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    header('Location: activos.php');
    exit;
}
$stmt = mysqli_prepare(
    $conn,
    "SELECT * FROM activo WHERE id_activo = ? LIMIT 1"
);
if (!$stmt) {
    exit('No se pudo preparar la consulta del activo.');
}
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);
$activo = mysqli_fetch_assoc($resultado);
mysqli_stmt_close($stmt);
if (!$activo) {
    header('Location: activos.php');
    exit;
}
$stmt = mysqli_prepare(
    $conn,
    "SELECT id_asignacion, id_ubicacion, id_responsable
     FROM asignacion_activo
     WHERE id_activo = ?
       AND fecha_fin IS NULL
     ORDER BY id_asignacion DESC
     LIMIT 1"
);
if (!$stmt) {
    exit('No se pudo consultar la asignación actual.');
}
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);
$asignacionActual = mysqli_fetch_assoc($resultado);
mysqli_stmt_close($stmt);
if ($asignacionActual) {
    $activo['id_ubicacion'] = $asignacionActual['id_ubicacion'];
    $activo['id_responsable'] = $asignacionActual['id_responsable'];
}
function catalogo($conn, $tabla, $idActual = 0) {
    $permitidas = [
        'tipo_activo',
        'ubicacion',
        'responsable',
        'estado_activo'
    ];
    if (!in_array($tabla, $permitidas, true)) {
        return [];
    }
    if ($tabla === 'ubicacion') {
        $sql = "SELECT *
                FROM ubicacion
                WHERE estado = 'Activa'
                   OR id_ubicacion = ?
                ORDER BY nombre ASC";
        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) {
            return [];
        }
        mysqli_stmt_bind_param($stmt, 'i', $idActual);
        mysqli_stmt_execute($stmt);
        $resultado = mysqli_stmt_get_result($stmt);
        $filas = $resultado
            ? mysqli_fetch_all($resultado, MYSQLI_ASSOC)
            : [];
        mysqli_stmt_close($stmt);
        return $filas;
    }
    if ($tabla === 'responsable') {
        $sql = "SELECT *
                FROM responsable
                WHERE estado = 'Activo'
                   OR id_responsable = ?
                ORDER BY apellido ASC, nombre ASC";
        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) {
            return [];
        }
        mysqli_stmt_bind_param($stmt, 'i', $idActual);
        mysqli_stmt_execute($stmt);
        $resultado = mysqli_stmt_get_result($stmt);
        $filas = $resultado
            ? mysqli_fetch_all($resultado, MYSQLI_ASSOC)
            : [];
        mysqli_stmt_close($stmt);
        return $filas;
    }
    $resultado = mysqli_query(
        $conn,
        "SELECT * FROM `$tabla`"
    );
    return $resultado
        ? mysqli_fetch_all($resultado, MYSQLI_ASSOC)
        : [];
}
function etiqueta($fila, $tabla = '') {
    if ($tabla === 'responsable') {
        $nombreCompleto = trim(
            ($fila['nombre'] ?? '') . ' ' .
            ($fila['apellido'] ?? '')
        );
        return $nombreCompleto !== ''
            ? $nombreCompleto
            : 'Responsable sin nombre';
    }
    foreach ([
        'nombre',
        'nombre_tipo',
        'nombre_tipo_activo',
        'nombre_ubicacion',
        'nombre_estado',
        'tipo',
        'descripcion'
    ] as $campo) {
        if (isset($fila[$campo]) && $fila[$campo] !== '') {
            return $fila[$campo];
        }
    }
    foreach ($fila as $campo => $valor) {
        if (stripos($campo, 'id_') !== 0 && $valor !== '') {
            return $valor;
        }
    }
    return 'Registro';
}
$tipoActual = (int)($activo['id_tipo_activo'] ?? 0);
$ubicacionActual = (int)($activo['id_ubicacion'] ?? 0);
$responsableActual = (int)($activo['id_responsable'] ?? 0);
$estadoActual = (int)($activo['id_estado'] ?? 0);
$tipos = catalogo($conn, 'tipo_activo');
$ubicaciones = catalogo($conn, 'ubicacion', $ubicacionActual);
$responsables = catalogo($conn, 'responsable', $responsableActual);
$estados = catalogo($conn, 'estado_activo');
$mensaje = $_SESSION['mensaje_activo'] ?? '';
unset($_SESSION['mensaje_activo']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Editar activo | INAC Activos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Roboto:wght@400;500&display=swap"
          rel="stylesheet">
    <style>
        body {
            background: #F4F6F8;
            font-family: 'Roboto', sans-serif;
            padding: 24px;
            color: #263746;
        }
        h2, h5, .btn {
            font-family: 'Poppins', sans-serif;
        }
        h2 {
            color: #123B63;
            font-weight: 700;
        }
        .panel {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 12px #123b6310;
        }
        .seccion {
            color: #123B63;
            font-weight: 600;
            border-bottom: 1px solid #ddd;
            padding-bottom: 8px;
            margin: 22px 0 16px;
        }
        .form-label {
            font-weight: 500;
        }
        .btn-principal {
            background: #123B63;
            color: white;
        }
        .btn-principal:hover {
            background: #2F80ED;
            color: white;
        }
        @media (max-width: 576px) {
            body {
                padding: 12px;
            }
            .panel {
                padding: 16px;
            }
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <h2>Editar activo</h2>
    <p class="text-secondary">INAC-ACT-03 · Actualización de información.</p>
    <?php if ($mensaje !== ''): ?>
        <div class="alert alert-warning">
            <?= e($mensaje) ?>
        </div>
    <?php endif; ?>
    <?php if (empty($tipos) || empty($ubicaciones) || empty($estados)): ?>
        <div class="alert alert-warning">
            Verifica que existan tipos de activo, ubicaciones y estados registrados.
        </div>
    <?php endif; ?>
    <div class="panel">
        <form action="actualizarActivo.php" method="POST">
            <input type="hidden" name="id_activo"
                   value="<?= (int)$activo['id_activo'] ?>">
            <h5 class="seccion">Información del activo</h5>
            <div class="row g-3">
                <div class="col-md-4">
                    <label for="codigo" class="form-label">Código permanente *</label>
                    <input type="text" id="codigo" name="codigo"
                           class="form-control" maxlength="30"
                           value="<?= e($activo['codigo'] ?? '') ?>"
                           readonly required>
                    <small class="text-secondary">
                        El código se conserva aunque cambie la ubicación o el responsable.
                    </small>
                </div>
                <div class="col-md-4">
                    <label for="nombre" class="form-label">Nombre *</label>
                    <input type="text" id="nombre" name="nombre"
                           class="form-control" maxlength="150"
                           value="<?= e($activo['nombre'] ?? '') ?>" required>
                </div>
                <div class="col-md-4">
                    <label for="id_tipo_activo" class="form-label">Tipo de activo *</label>
                    <select id="id_tipo_activo" name="id_tipo_activo"
                            class="form-select" required>
                        <option value="">Seleccionar tipo</option>
                        <?php foreach ($tipos as $fila): ?>
                            <option value="<?= (int)$fila['id_tipo_activo'] ?>"
                                <?= (int)$fila['id_tipo_activo'] === $tipoActual
                                    ? 'selected' : '' ?>>
                                <?= e(etiqueta($fila)) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="marca" class="form-label">Marca</label>
                    <input type="text" id="marca" name="marca"
                           class="form-control" maxlength="100"
                           value="<?= e($activo['marca'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label for="modelo" class="form-label">Modelo</label>
                    <input type="text" id="modelo" name="modelo"
                           class="form-control" maxlength="100"
                           value="<?= e($activo['modelo'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label for="numero_serie" class="form-label">Número de serie</label>
                    <input type="text" id="numero_serie" name="numero_serie"
                           class="form-control" maxlength="100"
                           value="<?= e($activo['numero_serie'] ?? '') ?>">
                </div>
                <div class="col-12">
                    <label for="descripcion" class="form-label">Descripción</label>
                    <textarea id="descripcion" name="descripcion"
                              class="form-control" rows="2"><?= e($activo['descripcion'] ?? '') ?></textarea>
                </div>
            </div>
            <h5 class="seccion">Datos de adquisición</h5>
            <div class="row g-3">
                <div class="col-md-4">
                    <label for="fecha_adquisicion" class="form-label">Fecha de adquisición *</label>
                    <input type="date" id="fecha_adquisicion"
                           name="fecha_adquisicion" class="form-control"
                           value="<?= e($activo['fecha_adquisicion'] ?? '') ?>"
                           required>
                </div>
                <div class="col-md-4">
                    <label for="valor" class="form-label">Valor ($) *</label>
                    <input type="number" id="valor" name="valor"
                           class="form-control" min="0" step="0.01"
                           value="<?= e($activo['valor'] ?? '') ?>" required>
                </div>
                <div class="col-md-4">
                    <label for="ubicacion_compra" class="form-label">Lugar de compra</label>
                    <input type="text" id="ubicacion_compra"
                           name="ubicacion_compra" class="form-control"
                           maxlength="150"
                           value="<?= e($activo['ubicacion_compra'] ?? '') ?>">
                </div>
            </div>
            <h5 class="seccion">Asignación y estado</h5>
            <div class="row g-3">
                <div class="col-md-4">
                    <label for="id_ubicacion" class="form-label">Ubicación actual *</label>
                    <select id="id_ubicacion" name="id_ubicacion"
                            class="form-select" required>
                        <option value="">Seleccionar ubicación</option>
                        <?php foreach ($ubicaciones as $fila): ?>
                            <option value="<?= (int)$fila['id_ubicacion'] ?>"
                                <?= (int)$fila['id_ubicacion'] === $ubicacionActual
                                    ? 'selected' : '' ?>>
                                <?= e(etiqueta($fila)) ?>
                                <?= ($fila['estado'] ?? '') !== 'Activa'
                                    ? ' (Inactiva: asignación existente)' : '' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <small class="text-secondary">
                        Al cambiar la ubicación se registrará el traslado en el historial.
                    </small>
                </div>
                <div class="col-md-4">
                    <label for="id_responsable" class="form-label">Responsable actual</label>
                    <select id="id_responsable" name="id_responsable"
                            class="form-select">
                        <option value="0"
                            <?= $responsableActual === 0 ? 'selected' : '' ?>>
                            Sin asignar
                        </option>
                        <?php foreach ($responsables as $fila): ?>
                            <option value="<?= (int)$fila['id_responsable'] ?>"
                                <?= (int)$fila['id_responsable'] === $responsableActual
                                    ? 'selected' : '' ?>>
                                <?= e(etiqueta($fila, 'responsable')) ?>
                                <?= ($fila['estado'] ?? '') !== 'Activo'
                                    ? ' (Inactivo: asignación existente)' : '' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <small class="text-secondary">
                        Los responsables inactivos solo aparecen si ya estaban asignados.
                    </small>
                </div>
                <div class="col-md-4">
                    <label for="id_estado" class="form-label">Estado *</label>
                    <select id="id_estado" name="id_estado"
                            class="form-select" required>
                        <option value="">Seleccionar estado</option>
                        <?php foreach ($estados as $fila): ?>
                            <option value="<?= (int)$fila['id_estado'] ?>"
                                <?= (int)$fila['id_estado'] === $estadoActual
                                    ? 'selected' : '' ?>>
                                <?= e(etiqueta($fila)) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <small class="text-secondary">
                        Si seleccionas Baja, se cerrará la asignación vigente.
                    </small>
                </div>
            </div>
            <div class="d-flex gap-2 mt-4 flex-wrap">
                <button class="btn btn-principal" type="submit">Guardar cambios</button>
                <a href="activos.php" class="btn btn-outline-secondary">Cancelar</a>
            </div>
        </form>
    </div>
</div>
</body>
</html>