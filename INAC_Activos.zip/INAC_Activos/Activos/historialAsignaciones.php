<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
$rolActual = $_SESSION['rol'] ?? '';
function escapar($valor) {
    return htmlspecialchars((string)($valor ?? ''), ENT_QUOTES, 'UTF-8');
}
$idActivo = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$idActivo || $idActivo < 1) {
    header('Location: activos.php?error=1');
    exit;
}
$sqlActivo = "
    SELECT
        a.id_activo,
        a.codigo,
        a.nombre,
        a.marca,
        a.modelo,
        a.numero_serie,
        a.fecha_adquisicion,
        a.valor,
        e.nombre_estado AS estado_nombre
    FROM activo a
    LEFT JOIN estado_activo e
        ON e.id_estado = a.id_estado
    WHERE a.id_activo = ?
    LIMIT 1
";
$stmtActivo = $conn->prepare($sqlActivo);
if (!$stmtActivo) {
    error_log('Error al preparar consulta del activo: ' . $conn->error);
    http_response_code(500);
    exit('No se pudo consultar la información del activo.');
}
$stmtActivo->bind_param('i', $idActivo);
if (!$stmtActivo->execute()) {
    error_log('Error al consultar activo: ' . $stmtActivo->error);
    $stmtActivo->close();
    http_response_code(500);
    exit('Ocurrió un error al consultar el activo.');
}
$resultadoActivo = $stmtActivo->get_result();
$activo = $resultadoActivo->fetch_assoc();
$stmtActivo->close();
if (!$activo) {
    header('Location: activos.php?error=1');
    exit;
}
$sqlHistorial = "
    SELECT
        aa.id_asignacion,
        aa.fecha_asignacion,
        aa.fecha_fin,
        aa.observaciones,
        u.nombre AS ubicacion_nombre,
        r.nombre AS responsable_nombre,
        r.apellido AS responsable_apellido
    FROM asignacion_activo aa
    LEFT JOIN ubicacion u
        ON u.id_ubicacion = aa.id_ubicacion
    LEFT JOIN responsable r
        ON r.id_responsable = aa.id_responsable
    WHERE aa.id_activo = ?
    ORDER BY aa.id_asignacion DESC
";
$stmtHistorial = $conn->prepare($sqlHistorial);
if (!$stmtHistorial) {
    error_log('Error al preparar historial de asignaciones: ' . $conn->error);
    http_response_code(500);
    exit('No se pudo consultar el historial de asignaciones.');
}
$stmtHistorial->bind_param('i', $idActivo);
if (!$stmtHistorial->execute()) {
    error_log('Error al consultar historial: ' . $stmtHistorial->error);
    $stmtHistorial->close();
    http_response_code(500);
    exit('Ocurrió un error al consultar el historial.');
}
$resultadoHistorial = $stmtHistorial->get_result();
$historial = $resultadoHistorial->fetch_all(MYSQLI_ASSOC);
$stmtHistorial->close();
$totalAsignaciones = count($historial);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de asignaciones - INAC Activos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../style.css">
    <style>
        body {
            margin: 0;
            padding: 20px;
            background: #F4F6F8;
            color: #263445;
            font-family: 'Roboto', sans-serif;
        }
        h2, h3, h4, h5, .btn {
            font-family: 'Poppins', sans-serif;
        }
        .page-title {
            color: #123B63;
            font-weight: 600;
        }
        .panel {
            background: #FFFFFF;
            border-radius: 12px;
            padding: 22px;
            box-shadow: 0 3px 12px rgba(18, 59, 99, 0.07);
            margin-bottom: 20px;
        }
        .dato-label {
            color: #6C757D;
            font-size: 0.85rem;
            margin-bottom: 4px;
        }
        .dato-valor {
            font-weight: 600;
            color: #123B63;
            overflow-wrap: anywhere;
        }
        .tabla-historial {
            margin-bottom: 0;
        }
        .tabla-historial th {
            background: #123B63;
            color: #FFFFFF;
            white-space: nowrap;
        }
        .tabla-historial td {
            vertical-align: middle;
        }
        .badge-vigente {
            background: #D1E7DD;
            color: #0F5132;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
            white-space: nowrap;
        }
        .badge-finalizada {
            background: #E9ECEF;
            color: #495057;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
            white-space: nowrap;
        }
        .contador {
            background: #E8F1FC;
            color: #123B63;
            padding: 7px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
        }
        @media (max-width: 576px) {
            body {
                padding: 10px;
            }
            .panel {
                padding: 14px;
            }
        }
        @media print {
            body {
                padding: 0;
                background: #FFFFFF;
            }
            .no-imprimir {
                display: none !important;
            }
            .panel {
                box-shadow: none;
                border: 1px solid #DDD;
                break-inside: avoid;
            }
            .table-responsive {
                overflow: visible;
            }
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h2 class="page-title mb-1">
                <i class="bi bi-clock-history"></i>
                Historial de asignaciones
            </h2>
            <p class="text-secondary mb-0">
                Registro de los cambios de ubicación y responsable del activo.
            </p>
        </div>
        <div class="d-flex flex-wrap gap-2 no-imprimir">
            <button type="button" onclick="window.print()" class="btn btn-outline-primary">
                <i class="bi bi-printer"></i> Imprimir
            </button>
            <a href="activos.php" class="btn btn-primary">
                <i class="bi bi-arrow-left"></i> Volver a activos
            </a>
        </div>
    </div>
    <section class="panel">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <h5 class="mb-0">
                <i class="bi bi-pc-display"></i>
                Información del activo
            </h5>
            <span class="contador">
                <?= $totalAsignaciones ?> asignación(es)
            </span>
        </div>
        <div class="row g-3">
            <div class="col-md-3 col-sm-6">
                <div class="dato-label">Código</div>
                <div class="dato-valor"><?= escapar($activo['codigo']) ?></div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="dato-label">Nombre</div>
                <div class="dato-valor"><?= escapar($activo['nombre']) ?></div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="dato-label">Marca</div>
                <div class="dato-valor"><?= escapar($activo['marca'] ?: 'No registrada') ?></div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="dato-label">Modelo</div>
                <div class="dato-valor"><?= escapar($activo['modelo'] ?: 'No registrado') ?></div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="dato-label">Número de serie</div>
                <div class="dato-valor"><?= escapar($activo['numero_serie'] ?: 'No registrado') ?></div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="dato-label">Fecha de adquisición</div>
                <div class="dato-valor"><?= escapar($activo['fecha_adquisicion'] ?: 'No registrada') ?></div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="dato-label">Valor</div>
                <div class="dato-valor">
                    <?php if ($activo['valor'] !== null && $activo['valor'] !== ''): ?>
                        $<?= number_format((float)$activo['valor'], 2) ?>
                    <?php else: ?>
                        No registrado
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="dato-label">Estado actual</div>
                <div class="dato-valor"><?= escapar($activo['estado_nombre'] ?? 'Sin estado') ?></div>
            </div>
        </div>
    </section>
    <section class="panel">
        <div class="mb-3">
            <h5 class="mb-1">Movimientos registrados</h5>
            <p class="text-secondary small mb-0">
                Las asignaciones se muestran de la más reciente a la más antigua.
            </p>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered table-hover tabla-historial">
                <thead>
                    <tr>
                        <th>N.º</th>
                        <th>Ubicación</th>
                        <th>Responsable</th>
                        <th>Fecha de asignación</th>
                        <th>Fecha de finalización</th>
                        <th>Estado de asignación</th>
                        <th>Observaciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($totalAsignaciones > 0): ?>
                    <?php $contadorHistorial = 1; ?>
                    <?php foreach ($historial as $registro): ?>
                        <?php
                        $vigente = ($registro['fecha_fin'] === null || $registro['fecha_fin'] === '');
                        $nombreResponsable = trim(
                            ($registro['responsable_nombre'] ?? '') . ' ' .
                            ($registro['responsable_apellido'] ?? '')
                        );
                        ?>
                        <tr>
                            <td><?= $contadorHistorial++ ?></td>
                            <td>
                                <?= escapar($registro['ubicacion_nombre'] ?: 'Sin ubicación') ?>
                            </td>
                            <td>
                                <?= escapar($nombreResponsable !== '' ? $nombreResponsable : 'Sin responsable') ?>
                            </td>
                            <td>
                                <?= escapar($registro['fecha_asignacion'] ?: 'No registrada') ?>
                            </td>
                            <td>
                                <?= escapar($registro['fecha_fin'] ?: '—') ?>
                            </td>
                            <td>
                                <?php if ($vigente): ?>
                                    <span class="badge-vigente">Vigente</span>
                                <?php else: ?>
                                    <span class="badge-finalizada">Finalizada</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?= escapar($registro['observaciones'] ?: 'Sin observaciones') ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center text-secondary py-4">
                            Este activo todavía no tiene asignaciones registradas.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>
</body>
</html>