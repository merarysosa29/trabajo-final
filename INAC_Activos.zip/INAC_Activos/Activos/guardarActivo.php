<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
if (!in_array($rolActual, ['Administrador', 'Editor'], true)) {
    http_response_code(403);
    exit('No tienes permiso para registrar activos.');
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: nuevoActivo.php');
    exit;
}
$codigo = trim($_POST['codigo'] ?? '');
$nombre = trim($_POST['nombre'] ?? '');
$descripcion = trim($_POST['descripcion'] ?? '');
$marca = trim($_POST['marca'] ?? '');
$modelo = trim($_POST['modelo'] ?? '');
$numero_serie = trim($_POST['numero_serie'] ?? '');
$fecha = trim($_POST['fecha_adquisicion'] ?? '');
$valorEntrada = $_POST['valor'] ?? '';
$compra = trim($_POST['ubicacion_compra'] ?? '');
$id_tipo = filter_var($_POST['id_tipo_activo'] ?? null, FILTER_VALIDATE_INT);
$id_ubicacion = filter_var($_POST['id_ubicacion'] ?? null, FILTER_VALIDATE_INT);
$id_responsable = filter_var($_POST['id_responsable'] ?? 0, FILTER_VALIDATE_INT);
$id_estado = filter_var($_POST['id_estado'] ?? null, FILTER_VALIDATE_INT);
function volverConMensaje($mensaje) {
    $_SESSION['mensaje_activo'] = $mensaje;
    header('Location: nuevoActivo.php');
    exit;
}
if (
    $codigo === '' ||
    mb_strlen($codigo) > 30 ||
    $nombre === '' ||
    mb_strlen($nombre) > 150 ||
    mb_strlen($descripcion) > 65535 ||
    mb_strlen($marca) > 100 ||
    mb_strlen($modelo) > 100 ||
    mb_strlen($numero_serie) > 100 ||
    mb_strlen($compra) > 150 ||
    $fecha === '' ||
    $valorEntrada === '' ||
    !is_numeric($valorEntrada) ||
    !is_finite((float)$valorEntrada) ||
    (float)$valorEntrada < 0 ||
    $id_tipo === false || $id_tipo < 1 ||
    $id_ubicacion === false || $id_ubicacion < 1 ||
    $id_responsable === false || $id_responsable < 0 ||
    $id_estado === false || $id_estado < 1
) {
    volverConMensaje('Completa los campos obligatorios con datos válidos.');
}
$fechaObjeto = DateTime::createFromFormat('!Y-m-d', $fecha);
if (!$fechaObjeto || $fechaObjeto->format('Y-m-d') !== $fecha) {
    volverConMensaje('La fecha de adquisición no es válida.');
}
$valor = (float)$valorEntrada;
$stmt = mysqli_prepare(
    $conn,
    "SELECT id_tipo_activo
     FROM tipo_activo
     WHERE id_tipo_activo = ?
     LIMIT 1"
);
if (!$stmt) {
    volverConMensaje('No se pudo validar el tipo de activo.');
}
mysqli_stmt_bind_param($stmt, 'i', $id_tipo);
mysqli_stmt_execute($stmt);
$tipoValido = mysqli_stmt_get_result($stmt)->fetch_assoc();
mysqli_stmt_close($stmt);
if (!$tipoValido) {
    volverConMensaje('El tipo de activo seleccionado no existe.');
}
$stmt = mysqli_prepare(
    $conn,
    "SELECT id_ubicacion
     FROM ubicacion
     WHERE id_ubicacion = ?
       AND estado = 'Activa'
     LIMIT 1"
);
if (!$stmt) {
    volverConMensaje('No se pudo validar la ubicación.');
}
mysqli_stmt_bind_param($stmt, 'i', $id_ubicacion);
mysqli_stmt_execute($stmt);
$ubicacionValida = mysqli_stmt_get_result($stmt)->fetch_assoc();
mysqli_stmt_close($stmt);
if (!$ubicacionValida) {
    volverConMensaje('La ubicación seleccionada no existe o está inactiva.');
}
if ($id_responsable > 0) {
    $stmt = mysqli_prepare(
        $conn,
        "SELECT id_responsable
         FROM responsable
         WHERE id_responsable = ?
           AND estado = 'Activo'
         LIMIT 1"
    );
    if (!$stmt) {
        volverConMensaje('No se pudo validar el responsable.');
    }
    mysqli_stmt_bind_param($stmt, 'i', $id_responsable);
    mysqli_stmt_execute($stmt);
    $responsableValido = mysqli_stmt_get_result($stmt)->fetch_assoc();
    mysqli_stmt_close($stmt);
    if (!$responsableValido) {
        volverConMensaje('El responsable seleccionado no existe o está inactivo.');
    }
}
$stmt = mysqli_prepare(
    $conn,
    "SELECT id_estado
     FROM estado_activo
     WHERE id_estado = ?
     LIMIT 1"
);
if (!$stmt) {
    volverConMensaje('No se pudo validar el estado del activo.');
}
mysqli_stmt_bind_param($stmt, 'i', $id_estado);
mysqli_stmt_execute($stmt);
$estadoValido = mysqli_stmt_get_result($stmt)->fetch_assoc();
mysqli_stmt_close($stmt);
if (!$estadoValido) {
    volverConMensaje('El estado seleccionado no existe.');
}
$stmt = mysqli_prepare(
    $conn,
    "SELECT id_activo
     FROM activo
     WHERE codigo = ?
     LIMIT 1"
);
if (!$stmt) {
    volverConMensaje('No se pudo validar el código del activo.');
}
mysqli_stmt_bind_param($stmt, 's', $codigo);
mysqli_stmt_execute($stmt);
$codigoDuplicado = mysqli_stmt_get_result($stmt)->fetch_assoc();
mysqli_stmt_close($stmt);
if ($codigoDuplicado) {
    volverConMensaje('Ese código ya está registrado. Utiliza otro.');
}
$sql = "INSERT INTO activo (
            codigo,
            nombre,
            descripcion,
            marca,
            modelo,
            numero_serie,
            fecha_adquisicion,
            valor,
            ubicacion_compra,
            id_tipo_activo,
            id_ubicacion,
            id_responsable,
            id_estado
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULLIF(?, 0), ?
        )";
$stmt = mysqli_prepare($conn, $sql);
if (!$stmt) {
    volverConMensaje('No se pudo preparar el registro del activo.');
}
mysqli_stmt_bind_param(
    $stmt,
    'sssssssdsiiii',
    $codigo,
    $nombre,
    $descripcion,
    $marca,
    $modelo,
    $numero_serie,
    $fecha,
    $valor,
    $compra,
    $id_tipo,
    $id_ubicacion,
    $id_responsable,
    $id_estado
);
try {
    if (!mysqli_begin_transaction($conn)) {
        throw new Exception('No se pudo iniciar la transacción.');
    }
    if (!mysqli_stmt_execute($stmt)) {
        if (mysqli_stmt_errno($stmt) === 1062) {
            throw new Exception('CODIGO_DUPLICADO');
        }
        throw new Exception('No se pudo guardar el activo.');
    }
    $idNuevo = mysqli_insert_id($conn);
    mysqli_stmt_close($stmt);
    $stmt = null;
    $fechaAsignacion = date('Y-m-d');
    $observaciones = 'Asignación inicial del activo';
    $sqlAsignacion = "INSERT INTO asignacion_activo (
                          id_activo,
                          id_responsable,
                          id_ubicacion,
                          fecha_asignacion,
                          fecha_fin,
                          observaciones
                      ) VALUES (
                          ?, NULLIF(?, 0), ?, ?, NULL, ?
                      )";
    $stmtAsignacion = mysqli_prepare($conn, $sqlAsignacion);
    if (!$stmtAsignacion) {
        throw new Exception('No se pudo preparar la asignación inicial.');
    }
    mysqli_stmt_bind_param(
        $stmtAsignacion,
        'iiiss',
        $idNuevo,
        $id_responsable,
        $id_ubicacion,
        $fechaAsignacion,
        $observaciones
    );
    if (!mysqli_stmt_execute($stmtAsignacion)) {
        mysqli_stmt_close($stmtAsignacion);
        throw new Exception('No se pudo guardar la asignación inicial.');
    }
    mysqli_stmt_close($stmtAsignacion);
    if (!mysqli_commit($conn)) {
        throw new Exception('No se pudo confirmar el registro.');
    }
    header('Location: activos.php?guardado=1');
    exit;
} catch (Throwable $e) {
    mysqli_rollback($conn);
    if (isset($stmt) && $stmt instanceof mysqli_stmt) {
        mysqli_stmt_close($stmt);
    }
    error_log('Error al registrar activo: ' . $e->getMessage());
    if ($e->getMessage() === 'CODIGO_DUPLICADO') {
        volverConMensaje('Ese código ya está registrado. Utiliza otro.');
    }
    volverConMensaje(
        'No se pudo guardar el activo y su asignación. Verifica los datos e inténtalo nuevamente.'
    );
}
?>