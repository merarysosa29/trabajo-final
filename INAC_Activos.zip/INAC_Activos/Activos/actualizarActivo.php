<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
if (!in_array($rolActual, ['Administrador', 'Editor'], true)) {
    http_response_code(403);
    exit('No tienes permiso para editar activos.');
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: activos.php');
    exit;
}
function volverConMensaje($mensaje, $id = 0) {
    $_SESSION['mensaje_activo'] = $mensaje;
    if ($id > 0) {
        header('Location: editarActivo.php?id=' . $id);
    } else {
        header('Location: activos.php');
    }
    exit;
}
function fallarConRollback($conn, $mensaje, $id) {
    $conn->rollback();
    volverConMensaje($mensaje, $id);
}
function insertarAsignacion(
    $conn,
    $idActivo,
    $idResponsable,
    $idUbicacion,
    $fecha,
    $observaciones
) {
    $sql = "INSERT INTO asignacion_activo (
                id_activo,
                id_responsable,
                id_ubicacion,
                fecha_asignacion,
                fecha_fin,
                observaciones
            ) VALUES (?, NULLIF(?, 0), ?, ?, NULL, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        return false;
    }
    mysqli_stmt_bind_param(
        $stmt,
        'iiiss',
        $idActivo,
        $idResponsable,
        $idUbicacion,
        $fecha,
        $observaciones
    );
    $correcto = mysqli_stmt_execute($stmt);
    $nuevoId = $correcto ? mysqli_insert_id($conn) : false;
    mysqli_stmt_close($stmt);
    return $nuevoId;
}
function cerrarAsignacion($conn, $idAsignacion, $fecha) {
    $sql = "UPDATE asignacion_activo
            SET fecha_fin = ?
            WHERE id_asignacion = ?
              AND fecha_fin IS NULL";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        return false;
    }
    mysqli_stmt_bind_param($stmt, 'si', $fecha, $idAsignacion);
    $correcto = mysqli_stmt_execute($stmt)
        && mysqli_stmt_affected_rows($stmt) === 1;
    mysqli_stmt_close($stmt);
    return $correcto;
}
function existeCatalogo($conn, $tabla, $columna, $id) {
    $permitidos = [
        'tipo_activo' => 'id_tipo_activo',
        'estado_activo' => 'id_estado'
    ];
    if (
        !isset($permitidos[$tabla]) ||
        $permitidos[$tabla] !== $columna
    ) {
        return false;
    }
    $sql = "SELECT `$columna`
            FROM `$tabla`
            WHERE `$columna` = ?
            LIMIT 1";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        return false;
    }
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    $fila = $resultado ? mysqli_fetch_assoc($resultado) : null;
    mysqli_stmt_close($stmt);
    return (bool)$fila;
}
$id = filter_var(
    $_POST['id_activo'] ?? null,
    FILTER_VALIDATE_INT
);
$nombre = trim($_POST['nombre'] ?? '');
$descripcion = trim($_POST['descripcion'] ?? '');
$marca = trim($_POST['marca'] ?? '');
$modelo = trim($_POST['modelo'] ?? '');
$serie = trim($_POST['numero_serie'] ?? '');
$fecha = trim($_POST['fecha_adquisicion'] ?? '');
$valorRecibido = $_POST['valor'] ?? '';
$compra = trim($_POST['ubicacion_compra'] ?? '');
$tipo = filter_var(
    $_POST['id_tipo_activo'] ?? null,
    FILTER_VALIDATE_INT
);
$ubicacion = filter_var(
    $_POST['id_ubicacion'] ?? null,
    FILTER_VALIDATE_INT
);
$responsable = filter_var(
    $_POST['id_responsable'] ?? 0,
    FILTER_VALIDATE_INT
);
$estado = filter_var(
    $_POST['id_estado'] ?? null,
    FILTER_VALIDATE_INT
);
if (!$id || $id < 1) {
    volverConMensaje('El identificador del activo no es válido.');
}
if (
    $nombre === '' ||
    mb_strlen($nombre) > 150 ||
    mb_strlen($descripcion) > 65535 ||
    mb_strlen($marca) > 100 ||
    mb_strlen($modelo) > 100 ||
    mb_strlen($serie) > 100 ||
    mb_strlen($compra) > 150 ||
    $fecha === '' ||
    $valorRecibido === '' ||
    !is_numeric($valorRecibido) ||
    !is_finite((float)$valorRecibido) ||
    (float)$valorRecibido < 0 ||
    $tipo === false || $tipo < 1 ||
    $ubicacion === false || $ubicacion < 1 ||
    $responsable === false || $responsable < 0 ||
    $estado === false || $estado < 1
) {
    volverConMensaje(
        'Verifica los campos obligatorios y sus valores.',
        $id
    );
}
$fechaObjeto = DateTime::createFromFormat('!Y-m-d', $fecha);
if (
    !$fechaObjeto ||
    $fechaObjeto->format('Y-m-d') !== $fecha
) {
    volverConMensaje('La fecha de adquisición no es válida.', $id);
}
$valor = (float)$valorRecibido;
$fechaHoy = date('Y-m-d');
$transaccionIniciada = false;
try {
    if (!$conn->begin_transaction()) {
        throw new Exception('No se pudo iniciar la transacción.');
    }
    $transaccionIniciada = true;
    $stmt = mysqli_prepare(
        $conn,
        "SELECT
            id_activo,
            id_ubicacion,
            id_responsable,
            id_estado
         FROM activo
         WHERE id_activo = ?
         LIMIT 1
         FOR UPDATE"
    );
    if (!$stmt) {
        throw new Exception('No se pudo consultar el activo.');
    }
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    $activoAnterior = mysqli_fetch_assoc($resultado);
    mysqli_stmt_close($stmt);
    if (!$activoAnterior) {
        fallarConRollback(
            $conn,
            'El activo que intentas editar no existe.',
            $id
        );
    }
    $stmt = mysqli_prepare(
        $conn,
        "SELECT id_asignacion, id_ubicacion, id_responsable
         FROM asignacion_activo
         WHERE id_activo = ?
           AND fecha_fin IS NULL
         ORDER BY id_asignacion DESC
         LIMIT 1
         FOR UPDATE"
    );
    if (!$stmt) {
        throw new Exception('No se pudo consultar el historial.');
    }
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    $asignacionActual = mysqli_fetch_assoc($resultado);
    mysqli_stmt_close($stmt);
    $habiaAsignacion = (bool)$asignacionActual;
    $estadoAnterior = (int)$activoAnterior['id_estado'];
    if ($asignacionActual) {
        $ubicacionAnterior = (int)$asignacionActual['id_ubicacion'];
        $responsableAnterior = (int)(
            $asignacionActual['id_responsable'] ?? 0
        );
        $idAsignacionVigente = (int)$asignacionActual['id_asignacion'];
    } else {
        $ubicacionAnterior = (int)$activoAnterior['id_ubicacion'];
        $responsableAnterior = (int)(
            $activoAnterior['id_responsable'] ?? 0
        );
        $idAsignacionVigente = 0;
    }
    if (!existeCatalogo($conn, 'tipo_activo', 'id_tipo_activo', $tipo)) {
        fallarConRollback(
            $conn,
            'El tipo de activo seleccionado no existe.',
            $id
        );
    }
    if (!existeCatalogo($conn, 'estado_activo', 'id_estado', $estado)) {
        fallarConRollback(
            $conn,
            'El estado seleccionado no existe.',
            $id
        );
    }
    $stmt = mysqli_prepare(
        $conn,
        "SELECT id_ubicacion, estado
         FROM ubicacion
         WHERE id_ubicacion = ?
         LIMIT 1"
    );
    if (!$stmt) {
        throw new Exception('No se pudo validar la ubicación.');
    }
    mysqli_stmt_bind_param($stmt, 'i', $ubicacion);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    $filaUbicacion = mysqli_fetch_assoc($resultado);
    mysqli_stmt_close($stmt);
    if (!$filaUbicacion) {
        fallarConRollback(
            $conn,
            'La ubicación seleccionada no existe.',
            $id
        );
    }
    if (
        $filaUbicacion['estado'] !== 'Activa' &&
        $ubicacion !== $ubicacionAnterior
    ) {
        fallarConRollback(
            $conn,
            'No puedes asignar el activo a una ubicación inactiva.',
            $id
        );
    }
    if ($responsable > 0) {
        $stmt = mysqli_prepare(
            $conn,
            "SELECT id_responsable, estado
             FROM responsable
             WHERE id_responsable = ?
             LIMIT 1"
        );
        if (!$stmt) {
            throw new Exception('No se pudo validar el responsable.');
        }
        mysqli_stmt_bind_param($stmt, 'i', $responsable);
        mysqli_stmt_execute($stmt);
        $resultado = mysqli_stmt_get_result($stmt);
        $filaResponsable = mysqli_fetch_assoc($resultado);
        mysqli_stmt_close($stmt);
        if (!$filaResponsable) {
            fallarConRollback(
                $conn,
                'El responsable seleccionado no existe.',
                $id
            );
        }
        $puedeConservarResponsableInactivo =
            $responsable === $responsableAnterior;
        if (
            $filaResponsable['estado'] !== 'Activo' &&
            !$puedeConservarResponsableInactivo
        ) {
            fallarConRollback(
                $conn,
                'No puedes asignar el activo a un responsable inactivo.',
                $id
            );
        }
    }
    $resultadoBaja = mysqli_query(
        $conn,
        "SELECT id_estado
         FROM estado_activo
         WHERE LOWER(TRIM(nombre_estado)) = 'baja'
         LIMIT 1"
    );
    $filaBaja = $resultadoBaja
        ? mysqli_fetch_assoc($resultadoBaja)
        : null;
    $idEstadoBaja = $filaBaja ? (int)$filaBaja['id_estado'] : 0;
    $esBaja = $idEstadoBaja > 0 && $estado === $idEstadoBaja;
    if (
        !$habiaAsignacion &&
        $estadoAnterior !== $idEstadoBaja &&
        $ubicacionAnterior > 0
    ) {
        $idAsignacionVigente = insertarAsignacion(
            $conn,
            $id,
            $responsableAnterior,
            $ubicacionAnterior,
            $fechaHoy,
            'Registro inicial automático; no existía historial previo'
        );
        if (!$idAsignacionVigente) {
            throw new Exception('No se pudo registrar la asignación anterior.');
        }
        $habiaAsignacion = true;
    }
    $sqlActualizar = "UPDATE activo SET
                          nombre = ?,
                          descripcion = ?,
                          marca = ?,
                          modelo = ?,
                          numero_serie = ?,
                          fecha_adquisicion = ?,
                          valor = ?,
                          ubicacion_compra = ?,
                          id_tipo_activo = ?,
                          id_ubicacion = ?,
                          id_responsable = NULLIF(?, 0),
                          id_estado = ?
                      WHERE id_activo = ?";
    $stmt = mysqli_prepare($conn, $sqlActualizar);
    if (!$stmt) {
        throw new Exception('No se pudo preparar la actualización del activo.');
    }
    mysqli_stmt_bind_param(
        $stmt,
        'ssssssdsiiiii',
        $nombre,
        $descripcion,
        $marca,
        $modelo,
        $serie,
        $fecha,
        $valor,
        $compra,
        $tipo,
        $ubicacion,
        $responsable,
        $estado,
        $id
    );
    if (!mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        throw new Exception('No se pudieron actualizar los datos del activo.');
    }
    mysqli_stmt_close($stmt);
    if ($esBaja) {
        if ($habiaAsignacion) {
            if (!cerrarAsignacion($conn, $idAsignacionVigente, $fechaHoy)) {
                throw new Exception('No se pudo cerrar la asignación del activo.');
            }
        }
    } else {
        $cambioAsignacion =
            $ubicacionAnterior !== $ubicacion ||
            $responsableAnterior !== $responsable;
        if ($habiaAsignacion && $cambioAsignacion) {
            if (!cerrarAsignacion($conn, $idAsignacionVigente, $fechaHoy)) {
                throw new Exception('No se pudo cerrar la asignación anterior.');
            }
            $nuevoId = insertarAsignacion(
                $conn,
                $id,
                $responsable,
                $ubicacion,
                $fechaHoy,
                'Cambio de ubicación o responsable'
            );
            if (!$nuevoId) {
                throw new Exception('No se pudo registrar la nueva asignación.');
            }
        } elseif (!$habiaAsignacion) {
            $nuevoId = insertarAsignacion(
                $conn,
                $id,
                $responsable,
                $ubicacion,
                $fechaHoy,
                'Nueva asignación del activo'
            );
            if (!$nuevoId) {
                throw new Exception('No se pudo registrar la asignación actual.');
            }
        }
    }
    if (!$conn->commit()) {
        throw new Exception('No se pudieron confirmar los cambios.');
    }
    $transaccionIniciada = false;
    header('Location: activos.php?actualizado=1');
    exit;
} catch (Throwable $e) {
    if ($transaccionIniciada) {
        $conn->rollback();
    }
    error_log(
        'Error al actualizar el activo ' . (int)$id . ': ' .
        $e->getMessage()
    );
    volverConMensaje(
        'No se pudieron guardar los cambios. Verifica los datos e inténtalo nuevamente.',
        (int)$id
    );
}
?>