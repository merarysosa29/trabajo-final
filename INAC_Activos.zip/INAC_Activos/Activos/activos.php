<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
$rolActual = $_SESSION['rol'] ?? '';
$esAdmin = ($rolActual === 'Administrador');
$puedeEditar = in_array($rolActual, ['Administrador', 'Editor'], true);
function escapar($valor) {
    return htmlspecialchars((string)($valor ?? ''), ENT_QUOTES, 'UTF-8');
}
function buscarColumna($conn, $tabla, $candidatas) {
    $tablasPermitidas = ['ubicacion', 'responsable', 'estado_activo'];
    if (!in_array($tabla, $tablasPermitidas, true)) {
        return null;
    }
    $columnas = [];
    $resultado = $conn->query("SHOW COLUMNS FROM `$tabla`");
    if ($resultado) {
        while ($fila = $resultado->fetch_assoc()) {
            $columnas[strtolower($fila['Field'])] = $fila['Field'];
        }
        $resultado->free();
    }
    foreach ($candidatas as $candidata) {
        if (isset($columnas[strtolower($candidata)])) {
            return $columnas[strtolower($candidata)];
        }
    }
    return null;
}
$existeAsignacion = false;
$consultaTabla = $conn->query("SHOW TABLES LIKE 'asignacion_activo'");
if ($consultaTabla && $consultaTabla->num_rows > 0) {
    $existeAsignacion = true;
}
if ($consultaTabla) {
    $consultaTabla->free();
}
$joinAsignacion = '';
$idUbicacionActual = 'a.id_ubicacion';
$idResponsableActual = 'a.id_responsable';
if ($existeAsignacion) {
    $joinAsignacion = "
        LEFT JOIN asignacion_activo aa
            ON aa.id_activo = a.id_activo
            AND aa.fecha_fin IS NULL
            AND aa.id_asignacion = (
                SELECT MAX(aa2.id_asignacion)
                FROM asignacion_activo aa2
                WHERE aa2.id_activo = a.id_activo
                  AND aa2.fecha_fin IS NULL
            )";
    $idUbicacionActual = 'COALESCE(aa.id_ubicacion, a.id_ubicacion)';
    $idResponsableActual = 'COALESCE(aa.id_responsable, a.id_responsable)';
}
$colUbicacion = buscarColumna(
    $conn,
    'ubicacion',
    ['nombre_ubicacion', 'nombre', 'ubicacion']
);
$colResponsable = buscarColumna(
    $conn,
    'responsable',
    ['nombre_responsable', 'nombre', 'responsable']
);
$colEstado = buscarColumna(
    $conn,
    'estado_activo',
    ['nombre_estado', 'estado', 'nombre']
);
$nombreUbicacion = $colUbicacion
    ? "u.`$colUbicacion`"
    : "CAST($idUbicacionActual AS CHAR)";
$nombreResponsable = $colResponsable
    ? "CONCAT_WS(' ', NULLIF(r.`$colResponsable`, ''), NULLIF(r.apellido, ''))"
    : "CAST($idResponsableActual AS CHAR)";
$nombreEstado = $colEstado
    ? "e.`$colEstado`"
    : "CAST(a.id_estado AS CHAR)";
$buscar = trim($_GET['buscar'] ?? '');
$mensaje = '';
$tipoMensaje = 'info';
if (isset($_GET['baja'])) {
    $mensaje = 'El activo se dio de baja correctamente.';
    $tipoMensaje = 'success';
} elseif (isset($_GET['error_baja'])) {
    $mensaje = 'No se pudo dar de baja el activo. Verifica que exista y que el estado Baja esté configurado.';
    $tipoMensaje = 'danger';
} elseif (isset($_GET['sin_permiso'])) {
    $mensaje = 'No tienes permisos para realizar esa operación.';
    $tipoMensaje = 'warning';
} elseif (isset($_GET['error'])) {
    $mensaje = 'Ocurrió un error al procesar la operación.';
    $tipoMensaje = 'danger';
}
$sql = "
    SELECT
        a.id_activo,
        a.codigo,
        a.nombre,
        a.marca,
        a.modelo,
        a.fecha_adquisicion,
        a.valor,
        $idUbicacionActual AS id_ubicacion_actual,
        $idResponsableActual AS id_responsable_actual,
        a.id_estado,
        $nombreUbicacion AS ubicacion_nombre,
        $nombreResponsable AS responsable_nombre,
        $nombreEstado AS estado_nombre
    FROM activo a
    $joinAsignacion
    LEFT JOIN ubicacion u
        ON u.id_ubicacion = $idUbicacionActual
    LEFT JOIN responsable r
        ON r.id_responsable = $idResponsableActual
    LEFT JOIN estado_activo e
        ON e.id_estado = a.id_estado";
if ($buscar !== '') {
    $sql .= "
        WHERE a.codigo LIKE ?
           OR a.nombre LIKE ?
           OR a.marca LIKE ?
           OR a.modelo LIKE ?
  ";
}
$sql .= " ORDER BY a.id_activo ASC";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log('Error al preparar listado de activos: ' . $conn->error);
    http_response_code(500);
    exit('No se pudo cargar el listado de activos. Verifica la estructura de la base de datos.');
}
if ($buscar !== '') {
    $termino = '%' . $buscar . '%';
    $stmt->bind_param('ssss', $termino, $termino, $termino, $termino);
}
if (!$stmt->execute()) {
    error_log('Error al consultar activos: ' . $stmt->error);
    $stmt->close();
    http_response_code(500);
    exit('Ocurrió un error al consultar los activos.');
}
$resultado = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de activos - INAC Activos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../style.css">
    <script src="../JavaScript/script.js" defer></script>
    <style>
        body {
            margin: 0;
            padding: 20px;
            background: #F4F6F8;
            color: #263445;
            font-family: 'Roboto', sans-serif;
        }
        h2, h3, h4, h5, .btn {
            font-family: 'Poppins', sans-serif;
        }
        .page-title {
            color: #123B63;
            font-weight: 600;
        }
        .panel {
            background: #FFFFFF;
            border-radius: 12px;
            padding: 22px;
            box-shadow: 0 3px 12px rgba(18, 59, 99, 0.07);
            margin-bottom: 20px;
        }
        .btn-primary {
            background: #2F80ED;
            border-color: #2F80ED;
        }
        .btn-primary:hover {
            background: #216AC8;
            border-color: #216AC8;
        }
        .table {
            margin-bottom: 0;
        }
        .table th {
            background: #123B63;
            color: #FFFFFF;
            white-space: nowrap;
        }
        .table td {
            vertical-align: middle;
        }
        .badge-estado {
            display: inline-block;
            padding: 6px 9px;
            border-radius: 20px;
            font-size: 12px;
            background: #E8F1FC;
            color: #123B63;
        }
        .table-responsive {
            border-radius: 8px;
        }
        .acciones {
            min-width: 175px;
        }
        .acciones .btn {
            display: inline-flex;
            justify-content: center;
            align-items: center;
            min-width: 32px;
        }
        @media (max-width: 576px) {
            body {
                padding: 10px;
            }
            .panel {
                padding: 14px;
            }
        }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h2 class="page-title mb-1">
                <i class="bi bi-pc-display"></i>
                Gestión de activos
            </h2>
            <p class="text-secondary mb-0">
                Consulta y control de los activos institucionales.
            </p>
        </div>
        <?php if ($puedeEditar): ?>
            <a href="nuevoActivo.php" class="btn btn-primary">
                <i class="bi bi-plus-circle"></i>
                Registrar activo
            </a>
        <?php endif; ?>
    </div>
    <?php if ($mensaje !== ''): ?>
        <div class="alert alert-<?= escapar($tipoMensaje) ?> alert-dismissible fade show" role="alert">
            <?= escapar($mensaje) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
        </div>
    <?php endif; ?>
    <section class="panel">
        <form method="GET" class="row g-2">
            <div class="col-md-9">
                <input
                    type="search"
                    name="buscar"
                    class="form-control"
                    placeholder="Buscar por código, nombre, marca o modelo..."
                    value="<?= escapar($buscar) ?>"
                    aria-label="Buscar activos">
            </div>
            <div class="col-md-3 d-flex gap-2">
                <button type="submit" class="btn btn-primary flex-fill">
                    <i class="bi bi-search"></i> Buscar
                </button>
                <a href="activos.php" class="btn btn-outline-secondary">Limpiar</a>
            </div>
        </form>
    </section>
    <section class="panel">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <h5 class="mb-0">Activos registrados</h5>
            <span class="text-secondary small">
                Rol: <?= escapar($rolActual) ?>
            </span>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nombre</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Ubicación actual</th>
                        <th>Responsable actual</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($resultado->num_rows > 0): ?>
                    <?php while ($activo = $resultado->fetch_assoc()): ?>
                        <?php
                        $estadoActual = strtolower(
                            trim((string)($activo['estado_nombre'] ?? ''))
                        );
                        $estaDeBaja = ($estadoActual === 'baja');
                        ?>
                        <tr>
                            <td><?= escapar($activo['codigo']) ?></td>
                            <td><?= escapar($activo['nombre']) ?></td>
                            <td><?= escapar($activo['marca']) ?></td>
                            <td><?= escapar($activo['modelo']) ?></td>
                            <td>
                                <?= escapar($activo['ubicacion_nombre'] ?: 'Sin ubicación') ?>
                            </td>
                            <td>
                                <?= escapar($activo['responsable_nombre'] ?: 'Sin responsable') ?>
                            </td>
                            <td>
                                <span class="badge-estado">
                                    <?= escapar($activo['estado_nombre'] ?? 'Sin estado') ?>
                                </span>
                            </td>
                            <td class="acciones">
                                <div class="d-flex flex-wrap gap-1">
                                    <a
                                        href="verActivo.php?id=<?= (int)$activo['id_activo'] ?>"
                                        class="btn btn-sm btn-outline-primary"
                                        title="Ver detalles"
                                        aria-label="Ver detalles">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a
                                        href="historialAsignaciones.php?id=<?= (int)$activo['id_activo'] ?>"
                                        class="btn btn-sm btn-outline-info"
                                        title="Historial de asignaciones"
                                        aria-label="Historial de asignaciones">
                                        <i class="bi bi-clock-history"></i>
                                    </a>
                                    <?php if ($puedeEditar): ?>
                                        <a
                                            href="editarActivo.php?id=<?= (int)$activo['id_activo'] ?>"
                                            class="btn btn-sm btn-outline-secondary"
                                            title="Editar activo"
                                            aria-label="Editar activo">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <?php if (!$estaDeBaja): ?>
                                            <form
                                                action="darBajaActivo.php"
                                                method="POST"
                                                class="d-inline"
                                                onsubmit="return confirm('¿Seguro que deseas dar de baja este activo? Esta acción cerrará su asignación vigente.');">
                                                <input
                                                    type="hidden"
                                                    name="id_activo"
                                                    value="<?= (int)$activo['id_activo'] ?>">
                                                <button
                                                    type="submit"
                                                    class="btn btn-sm btn-outline-danger"
                                                    title="Dar de baja"
                                                    aria-label="Dar de baja">
                                                    <i class="bi bi-x-circle"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center py-4 text-secondary">
                            <?php if ($buscar !== ''): ?>
                                No se encontraron activos que coincidan con la búsqueda.
                            <?php else: ?>
                                No hay activos registrados.
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
$stmt->close();
?>