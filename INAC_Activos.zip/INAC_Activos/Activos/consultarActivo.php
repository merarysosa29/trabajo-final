<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
function e($valor) {
    return htmlspecialchars((string)($valor ?? ''), ENT_QUOTES, 'UTF-8');
}
$idActivo = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$idActivo || $idActivo < 1) {
    $idActivo = filter_input(INPUT_GET, 'id_activo', FILTER_VALIDATE_INT);
}
if (!$idActivo || $idActivo < 1) {
    header('Location: activos.php');
    exit;
}
$sql = "SELECT
            a.*,
            ea.nombre_estado AS estado_nombre,
            u.nombre AS ubicacion_nombre,
            r.nombre AS responsable_nombre,
            r.apellido AS responsable_apellido,
            aa.id_asignacion AS asignacion_vigente
        FROM activo a
        LEFT JOIN estado_activo ea
            ON ea.id_estado = a.id_estado
        LEFT JOIN asignacion_activo aa
            ON aa.id_activo = a.id_activo
           AND aa.fecha_fin IS NULL
        LEFT JOIN ubicacion u
            ON u.id_ubicacion = COALESCE(aa.id_ubicacion, a.id_ubicacion)
        LEFT JOIN responsable r
            ON r.id_responsable = COALESCE(aa.id_responsable, a.id_responsable)
        WHERE a.id_activo = ?
        ORDER BY aa.id_asignacion DESC
        LIMIT 1";
$stmt = mysqli_prepare($conn, $sql);
if (!$stmt) {
    exit('No se pudo preparar la consulta del activo.');
}
mysqli_stmt_bind_param($stmt, 'i', $idActivo);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);
$activo = mysqli_fetch_assoc($resultado);
mysqli_stmt_close($stmt);
if (!$activo) {
    header('Location: activos.php?no_encontrado=1');
    exit;
}
$tipoNombre = 'No especificado';
$stmtTipo = mysqli_prepare(
    $conn,
    "SELECT *
     FROM tipo_activo
     WHERE id_tipo_activo = ?
     LIMIT 1"
);
if ($stmtTipo) {
    mysqli_stmt_bind_param(
        $stmtTipo,
        'i',
        $activo['id_tipo_activo']
    );
    mysqli_stmt_execute($stmtTipo);
    $resultadoTipo = mysqli_stmt_get_result($stmtTipo);
    $tipo = mysqli_fetch_assoc($resultadoTipo);
    mysqli_stmt_close($stmtTipo);
    if ($tipo) {
        foreach ([
            'nombre',
            'nombre_tipo',
            'nombre_tipo_activo',
            'tipo',
            'descripcion'
        ] as $campo) {
            if (!empty($tipo[$campo])) {
                $tipoNombre = $tipo[$campo];
                break;
            }
        }
    }
}
$sqlHistorial = "SELECT
                    aa.id_asignacion,
                    aa.fecha_asignacion,
                    aa.fecha_fin,
                    aa.observaciones,
                    u.nombre AS ubicacion_nombre,
                    r.nombre AS responsable_nombre,
                    r.apellido AS responsable_apellido
                 FROM asignacion_activo aa
                 LEFT JOIN ubicacion u
                    ON u.id_ubicacion = aa.id_ubicacion
                 LEFT JOIN responsable r
                    ON r.id_responsable = aa.id_responsable
                 WHERE aa.id_activo = ?
                 ORDER BY aa.id_asignacion DESC";
$stmtHistorial = mysqli_prepare($conn, $sqlHistorial);
if (!$stmtHistorial) {
    exit('No