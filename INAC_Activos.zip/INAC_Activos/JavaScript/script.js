document.addEventListener('DOMContentLoaded', function () {
    let formularioPendiente = null;
    let botonFormulario = null;
    let enlacePendiente = null;
    const estilos = document.createElement('style');
    estilos.textContent = `
        .modal-confirmacion-fondo {
            position: fixed;
            inset: 0;
            z-index: 20000;
            display: none;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: rgba(12, 28, 45, 0.65);
            backdrop-filter: blur(3px);
        }
        .modal-confirmacion-fondo.visible {
            display: flex;
        }
        .modal-confirmacion {
            width: 100%;
            max-width: 430px;
            padding: 28px;
            background: #FFFFFF;
            border-radius: 16px;
            box-shadow: 0 18px 55px rgba(0, 0, 0, 0.25);
            animation: aparecerConfirmacion 0.2s ease;
        }
        .modal-confirmacion-icono {
            width: 58px;
            height: 58px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 18px;
            border-radius: 50%;
            background: #FFF3CD;
            color: #9A6700;
            font-size: 27px;
        }
        .modal-confirmacion h3 {
            margin: 0 0 10px;
            color: #123B63;
            text-align: center;
            font-size: 21px;
            font-weight: 700;
        }
        .modal-confirmacion p {
            margin: 0;
            color: #64748B;
            text-align: center;
            line-height: 1.6;
            overflow-wrap: anywhere;
        }
        .modal-confirmacion-botones {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 26px;
        }
        .modal-confirmacion-botones button {
            min-height: 42px;
            padding: 10px 17px;
            border-radius: 9px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.2s;
        }
        .modal-confirmacion-cancelar {
            border: 1px solid #D5DDE5;
            background: #FFFFFF;
            color: #334155;
        }
        .modal-confirmacion-cancelar:hover {
            background: #F1F5F9;
        }
        .modal-confirmacion-aceptar {
            border: 1px solid #123B63;
            background: #123B63;
            color: #FFFFFF;
        }
        .modal-confirmacion-aceptar:hover {
            background: #2F80ED;
            border-color: #2F80ED;
        }
        @keyframes aparecerConfirmacion {
            from {
                opacity: 0;
                transform: translateY(10px) scale(0.98);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }
        @media (max-width: 480px) {
            .modal-confirmacion {
                padding: 22px 18px;
            }
            .modal-confirmacion-botones {
                flex-direction: column-reverse;
            }
            .modal-confirmacion-botones button {
                width: 100%;
            }
        }
    `;
    document.head.appendChild(estilos);
    const fondo = document.createElement('div');
    fondo.className = 'modal-confirmacion-fondo';
    fondo.innerHTML = `
        <section
            class="modal-confirmacion"
            role="dialog"
            aria-modal="true"
            aria-labelledby="tituloConfirmacion"
            aria-describedby="mensajeConfirmacion">
            <div class="modal-confirmacion-icono" aria-hidden="true">
                <i class="bi bi-exclamation-triangle"></i>
            </div>
            <h3 id="tituloConfirmacion">Confirmar acción</h3>
            <p id="mensajeConfirmacion">
                ¿Estás seguro de que deseas continuar?
            </p>
            <div class="modal-confirmacion-botones">
                <button
                    type="button"
                    class="modal-confirmacion-cancelar"
                    id="cancelarConfirmacion">
                    Cancelar
                </button>
                <button
                    type="button"
                    class="modal-confirmacion-aceptar"
                    id="aceptarConfirmacion">
                    Confirmar
                </button>
            </div>
        </section>`;
    document.body.appendChild(fondo);
    const titulo = fondo.querySelector('#tituloConfirmacion');
    const mensaje = fondo.querySelector('#mensajeConfirmacion');
    const botonCancelar = fondo.querySelector('#cancelarConfirmacion');
    const botonAceptar = fondo.querySelector('#aceptarConfirmacion');
    let elementoAnterior = null;
    function mostrarConfirmacion(texto, tipo) {
        elementoAnterior = document.activeElement;
        formularioPendiente = null;
        botonFormulario = null;
        enlacePendiente = null;
        mensaje.textContent = texto || '¿Deseas continuar?';
        if (tipo === 'eliminar') {
            titulo.textContent = 'Confirmar eliminación';
            botonAceptar.textContent = 'Sí, eliminar';
            botonAceptar.style.background = '#C63D3D';
            botonAceptar.style.borderColor = '#C63D3D';
        } else if (tipo === 'salir') {
            titulo.textContent = 'Cerrar sesión';
            botonAceptar.textContent = 'Sí, salir';
            botonAceptar.style.background = '#C63D3D';
            botonAceptar.style.borderColor = '#C63D3D';
        } else {
            titulo.textContent = 'Confirmar acción';
            botonAceptar.textContent = 'Confirmar';
            botonAceptar.style.background = '#123B63';
            botonAceptar.style.borderColor = '#123B63';
        }
        fondo.classList.add('visible');
        botonCancelar.focus();
    }
    function cerrarConfirmacion() {
        fondo.classList.remove('visible');
        formularioPendiente = null;
        botonFormulario = null;
        enlacePendiente = null;
        if (elementoAnterior && elementoAnterior.isConnected) {
            elementoAnterior.focus();
        }
    }
    document.addEventListener('click', function (evento) {
        const enlace = evento.target.closest('a[data-confirm]');
        if (!enlace) {
            return;
        }
        evento.preventDefault();
        const texto = enlace.getAttribute('data-confirm');
        const tipo = enlace.dataset.confirmType || '';
        mostrarConfirmacion(texto, tipo);
        enlacePendiente = enlace;
    });
    document.addEventListener('submit', function (evento) {
        const formulario = evento.target;
        if (!(formulario instanceof HTMLFormElement)) {
            return;
        }
        if (formulario.dataset.confirmado === 'si') {
            delete formulario.dataset.confirmado;
            return;
        }
        if (!formulario.checkValidity()) {
            evento.preventDefault();
            formulario.reportValidity();
            return;
        }
        const texto = formulario.dataset.confirm;
        if (texto) {
            evento.preventDefault();
            const tipo = formulario.dataset.confirmType || '';
            mostrarConfirmacion(texto, tipo);
            formularioPendiente = formulario;
            botonFormulario = evento.submitter || null;
        }
    });
    botonCancelar.addEventListener('click', cerrarConfirmacion);
    botonAceptar.addEventListener('click', function () {
        if (formularioPendiente) {
            const formulario = formularioPendiente;
            const boton = botonFormulario;
            cerrarConfirmacion();
            formulario.dataset.confirmado = 'si';
            if (boton && boton.form === formulario) {
                formulario.requestSubmit(boton);
            } else {
                formulario.requestSubmit();
            }
            return;
        }
        if (enlacePendiente) {
            const enlace = enlacePendiente;
            cerrarConfirmacion();
            window.location.href = enlace.href;
        }
    });
    fondo.addEventListener('click', function (evento) {
        if (evento.target === fondo) {
            cerrarConfirmacion();
        }
    });
    document.addEventListener('keydown', function (evento) {
        if (
            evento.key === 'Escape' &&
            fondo.classList.contains('visible')
        ) {
            cerrarConfirmacion();
        }
    });
});