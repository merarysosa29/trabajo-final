<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$activos=(int)$conexion->query("SELECT COUNT(*) total FROM activo")->fetch_assoc()['total'];
$valor=(float)$conexion->query("SELECT COALESCE(SUM(valor),0) total FROM activo")->fetch_assoc()['total'];
$mantenimientos=(int)$conexion->query("SELECT COUNT(*) total FROM mantenimiento")->fetch_assoc()['total'];
$costo=(float)$conexion->query("SELECT COALESCE(SUM(costo),0) total FROM mantenimiento")->fetch_assoc()['total'];
$porTipo=$conexion->query("SELECT t.nombre,COUNT(a.id_activo) cantidad
FROM tipo_activo t LEFT JOIN activo a ON t.id_tipo_activo=a.id_tipo_activo
GROUP BY t.id_tipo_activo,t.nombre ORDER BY cantidad DESC");
$porEstado=$conexion->query("SELECT e.nombre_estado,COUNT(a.id_activo) cantidad
FROM estado_activo e LEFT JOIN activo a ON e.id_estado=a.id_estado
GROUP BY e.id_estado,e.nombre_estado ORDER BY cantidad DESC");
$porMantenimiento=$conexion->query("SELECT tm.nombre,COUNT(m.id_mantenimiento) cantidad,
COALESCE(SUM(m.costo),0) costo
FROM tipo_mantenimiento tm LEFT JOIN mantenimiento m
ON tm.id_tipo_mantenimiento=m.id_tipo_mantenimiento
GROUP BY tm.id_tipo_mantenimiento,tm.nombre ORDER BY cantidad DESC");
$pendientes=(int)$conexion->query("SELECT COUNT(*) total FROM mantenimiento WHERE estado_mantenimiento='Pendiente'")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Estadísticas | INAC Activos</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:#F4F6F8;font-family:Arial}
h2{color:#123B63}.tarjeta{background:white;border-radius:12px;padding:22px;box-shadow:0 2px 10px #0001;height:100%}
.numero{font-size:28px;font-weight:bold;color:#123B63}
.panel{background:white;border-radius:12px;padding:20px}
.btn-inac{background:#123B63;color:white}
@media print{.no-print{display:none!important}body{background:white}}
</style>
</head>
<body>
<div class="container-fluid p-4">
<div class="d-flex justify-content-between align-items-center mb-4">
<h2>Reporte estadístico</h2>
<div class="no-print">
<a href="generarReporteEstadistico.php" class="btn btn-success">Generar reporte</a>
<button onclick="window.print()" class="btn btn-inac">Imprimir</button>
</div>
</div>
<p>Resumen general al <?= date('d/m/Y') ?></p>
<div class="row g-3 mb-4">
<div class="col-md-3"><div class="tarjeta"><div>Activos registrados</div><div class="numero"><?= $activos ?></div></div></div>
<div class="col-md-3"><div class="tarjeta"><div>Valor total de activos</div><div class="numero">$<?= number_format($valor,2) ?></div></div></div>
<div class="col-md-3"><div class="tarjeta"><div>Mantenimientos registrados</div><div class="numero"><?= $mantenimientos ?></div></div></div>
<div class="col-md-3"><div class="tarjeta"><div>Mantenimientos pendientes</div><div class="numero"><?= $pendientes ?></div></div></div>
</div>
<div class="panel mb-4">
<h5>Activos por tipo</h5>
<div class="table-responsive"><table class="table table-striped">
<thead><tr><th>Tipo de activo</th><th>Cantidad</th><th>Porcentaje</th></tr></thead><tbody>
<?php while($x=$porTipo->fetch_assoc()): $porcentaje=$activos>0?($x['cantidad']/$activos)*100:0; ?>
<tr><td><?= e($x['nombre']) ?></td><td><?= (int)$x['cantidad'] ?></td><td><?= number_format($porcentaje,1) ?>%</td></tr>
<?php endwhile; ?>
</tbody></table></div>
</div>
<div class="panel mb-4">
<h5>Activos por estado</h5>
<div class="table-responsive"><table class="table table-striped">
<thead><tr><th>Estado</th><th>Cantidad</th><th>Porcentaje</th></tr></thead><tbody>
<?php while($x=$porEstado->fetch_assoc()): $porcentaje=$activos>0?($x['cantidad']/$activos)*100:0; ?>
<tr><td><?= e($x['nombre_estado']) ?></td><td><?= (int)$x['cantidad'] ?></td><td><?= number_format($porcentaje,1) ?>%</td></tr>
<?php endwhile; ?>
</tbody></table></div>
</div>
<div class="panel mb-4">
<h5>Mantenimientos por tipo</h5>
<div class="table-responsive"><table class="table table-striped">
<thead><tr><th>Tipo de mantenimiento</th><th>Cantidad</th><th>Costo total</th></tr></thead><tbody>
<?php while($x=$porMantenimiento->fetch_assoc()): ?>
<tr><td><?= e($x['nombre']) ?></td><td><?= (int)$x['cantidad'] ?></td><td>$<?= number_format((float)$x['costo'],2) ?></td></tr>
<?php endwhile; ?>
</tbody></table></div>
<h5 class="text-end">Costo total de mantenimientos: $<?= number_format($costo,2) ?></h5>
</div>
<a href="reportes.php" class="btn btn-outline-secondary no-print">Volver a reportes</a>
</div>
</body>
</html>