<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
function e($v) {
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8');
}
$desde = $_GET['desde'] ?? '';
$hasta = $_GET['hasta'] ?? '';
$tipo = (int)($_GET['tipo'] ?? 0);
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $desde)) {
    $desde = '';
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $hasta)) {
    $hasta = '';
}
$sql = "SELECT
            a.codigo,
            a.nombre AS activo,
            tm.nombre AS tipo,
            m.fecha,
            m.descripcion,
            m.reparacion_realizada,
            m.costo,
            m.estado_mantenimiento,
            m.proxima_fecha
        FROM mantenimiento m
        INNER JOIN activo a ON m.id_activo = a.id_activo
        INNER JOIN tipo_mantenimiento tm
            ON m.id_tipo_mantenimiento = tm.id_tipo_mantenimiento
        WHERE 1=1";
if ($desde !== '') {
    $desdeSQL = $conexion->real_escape_string($desde);
    $sql .= " AND m.fecha >= '$desdeSQL'";
}
if ($hasta !== '') {
    $hastaSQL = $conexion->real_escape_string($hasta);
    $sql .= " AND m.fecha <= '$hastaSQL'";
}
if ($tipo > 0) {
    $sql .= " AND m.id_tipo_mantenimiento = $tipo";
}
$sql .= " ORDER BY m.fecha DESC";
$res = $conexion->query($sql);
if (!$res) {
    exit('Error al generar el reporte.');
}
$cantidad = $res->num_rows;
$total = 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Reporte de mantenimientos - INAC</title>
<style>
body {
    font-family: Arial, sans-serif;
    color: #222;
    margin: 25px;
}
h1, h2 {
    color: #123B63;
}
table {
    width: 100%;
    border-collapse: collapse;
    font-size: 12px;
}
th, td {
    border: 1px solid #bbb;
    padding: 7px;
    text-align: left;
}
th {
    background: #123B63;
    color: white;
}
.acciones {
    margin-bottom: 20px;
}
.acciones button {
    padding: 8px 12px;
    margin-right: 5px;
    cursor: pointer;
}
@media print {
    .acciones {
        display: none;
    }
}
</style>
</head>
<body>
<div class="acciones">
    <button onclick="window.print()">Imprimir / Guardar como PDF</button>
    <button onclick="location.href='reporteMantenimientos.php'">Volver</button>
</div>
<h1>INAC Activos</h1>
<h2>Reporte de mantenimientos</h2>
<p>Fecha de generación: <?= date('d/m/Y H:i') ?></p>
<table>
<thead>
<tr>
    <th>Activo</th>
    <th>Tipo</th>
    <th>Fecha</th>
    <th>Descripción</th>
    <th>Reparación</th>
    <th>Costo</th>
    <th>Estado</th>
    <th>Próxima fecha</th>
</tr>
</thead>
<tbody>
<?php while ($m = $res->fetch_assoc()): ?>
<?php $total += (float)$m['costo']; ?>
<tr>
    <td><?= e($m['codigo'] . ' - ' . $m['activo']) ?></td>
    <td><?= e($m['tipo']) ?></td>
    <td><?= e($m['fecha']) ?></td>
    <td><?= e($m['descripcion']) ?></td>
    <td><?= e($m['reparacion_realizada'] ?: 'No registrada') ?></td>
    <td>$<?= number_format((float)$m['costo'], 2) ?></td>
    <td><?= e($m['estado_mantenimiento']) ?></td>
    <td><?= e($m['proxima_fecha'] ?: 'No programada') ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
<h3>Mantenimientos incluidos: <?= $cantidad ?></h3>
<h3>Costo total: $<?= number_format($total, 2) ?></h3>
</body>
</html>