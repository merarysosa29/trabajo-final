<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
function e($v) {
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8');
}
$tipo = (int)($_GET['tipo'] ?? 0);
$estado = (int)($_GET['estado'] ?? 0);
$ubicacion = (int)($_GET['ubicacion'] ?? 0);
$sql = "SELECT a.codigo, a.nombre, a.fecha_adquisicion, a.valor,
               t.nombre AS tipo, e.nombre_estado, u.nombre AS ubicacion,
               CONCAT(COALESCE(r.nombre,''),' ',COALESCE(r.apellido,'')) AS responsable
        FROM activo a
        INNER JOIN tipo_activo t ON a.id_tipo_activo = t.id_tipo_activo
        INNER JOIN estado_activo e ON a.id_estado = e.id_estado
        INNER JOIN ubicacion u ON a.id_ubicacion = u.id_ubicacion
        LEFT JOIN responsable r ON a.id_responsable = r.id_responsable
        WHERE 1=1";
if ($tipo > 0) {
    $sql .= " AND a.id_tipo_activo = $tipo";
}
if ($estado > 0) {
    $sql .= " AND a.id_estado = $estado";
}
if ($ubicacion > 0) {
    $sql .= " AND a.id_ubicacion = $ubicacion";
}
$sql .= " ORDER BY a.nombre";
$res = $conexion->query($sql);
if (!$res) {
    exit('Error al consultar los activos.');
}
$cantidad = $res->num_rows;
$total = 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Reporte de activos - INAC</title>
<style>
body {
    font-family: Arial, sans-serif;
    color: #222;
    margin: 25px;
}
h1, h2 {
    color: #123B63;
}
table {
    width: 100%;
    border-collapse: collapse;
    font-size: 12px;
}
th, td {
    border: 1px solid #bbb;
    padding: 7px;
    text-align: left;
}
th {
    background: #123B63;
    color: white;
}
.acciones {
    margin-bottom: 20px;
}
.acciones button {
    padding: 8px 12px;
    margin-right: 5px;
    cursor: pointer;
}
@media print {
    .acciones {
        display: none;
    }
}
</style>
</head>
<body>
<div class="acciones">
    <button onclick="window.print()">Imprimir / Guardar como PDF</button>
    <button onclick="location.href='reporteActivos.php'">Volver</button>
</div>
<h1>INAC Activos</h1>
<h2>Reporte de activos fijos</h2>
<p>Fecha de generación: <?= date('d/m/Y H:i') ?></p>
<table>
<thead>
<tr>
    <th>Código</th>
    <th>Activo</th>
    <th>Tipo</th>
    <th>Estado</th>
    <th>Ubicación</th>
    <th>Responsable</th>
    <th>Adquisición</th>
    <th>Valor</th>
</tr>
</thead>
<tbody>
<?php while ($a = $res->fetch_assoc()): ?>
<?php $total += (float)$a['valor']; ?>
<tr>
    <td><?= e($a['codigo']) ?></td>
    <td><?= e($a['nombre']) ?></td>
    <td><?= e($a['tipo']) ?></td>
    <td><?= e($a['nombre_estado']) ?></td>
    <td><?= e($a['ubicacion']) ?></td>
    <td><?= e(trim($a['responsable'])) ?: 'Sin asignar' ?></td>
    <td><?= e($a['fecha_adquisicion'] ?: 'No registrada') ?></td>
    <td>$<?= number_format((float)$a['valor'], 2) ?></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
<h3>Activos incluidos: <?= $cantidad ?></h3>
<h3>Valor total: $<?= number_format($total, 2) ?></h3>
</body>
</html>