...,<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
function e($v) {
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8');
}
$activos = (int)$conexion->query(
    "SELECT COUNT(*) AS total FROM activo"
)->fetch_assoc()['total'];
$valor = (float)$conexion->query(
    "SELECT COALESCE(SUM(valor), 0) AS total FROM activo"
)->fetch_assoc()['total'];
$mantenimientos = (int)$conexion->query(
    "SELECT COUNT(*) AS total FROM mantenimiento"
)->fetch_assoc()['total'];
$costo = (float)$conexion->query(
    "SELECT COALESCE(SUM(costo), 0) AS total FROM mantenimiento"
)->fetch_assoc()['total'];
$pendientes = (int)$conexion->query(
    "SELECT COUNT(*) AS total
     FROM mantenimiento
     WHERE estado_mantenimiento = 'Pendiente'"
)->fetch_assoc()['total'];
$tipos = $conexion->query(
    "SELECT t.nombre, COUNT(a.id_activo) AS cantidad
     FROM tipo_activo t
     LEFT JOIN activo a ON t.id_tipo_activo = a.id_tipo_activo
     GROUP BY t.id_tipo_activo, t.nombre
     ORDER BY cantidad DESC"
);
$estados = $conexion->query(
    "SELECT e.nombre_estado, COUNT(a.id_activo) AS cantidad
     FROM estado_activo e
     LEFT JOIN activo a ON e.id_estado = a.id_estado
     GROUP BY e.id_estado, e.nombre_estado
     ORDER BY cantidad DESC"
);
$mant = $conexion->query(
    "SELECT tm.nombre,
            COUNT(m.id_mantenimiento) AS cantidad,
            COALESCE(SUM(m.costo), 0) AS costo
     FROM tipo_mantenimiento tm
     LEFT JOIN mantenimiento m
        ON tm.id_tipo_mantenimiento = m.id_tipo_mantenimiento
     GROUP BY tm.id_tipo_mantenimiento, tm.nombre
     ORDER BY cantidad DESC"
);
if (!$tipos || !$estados || !$mant) {
    exit('Error al consultar los datos estadísticos.');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Reporte estadístico - INAC Activos</title>
<style>
body {
    font-family: Arial, sans-serif;
    color: #222;
    margin: 25px;
}
h1, h2, h3 {
    color: #123B63;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 25px;
}
th, td {
    border: 1px solid #bbb;
    padding: 8px;
    text-align: left;
}
th {
    background: #123B63;
    color: white;
}
.acciones {
    margin-bottom: 20px;
}
.acciones button {
    padding: 8px 12px;
    margin-right: 5px;
    cursor: pointer;
}
@media print {
    .acciones {
        display: none;
    }
}
</style>
</head>
<body>
<div class="acciones">
    <button onclick="window.print()">Imprimir / Guardar como PDF</button>
    <button onclick="location.href='reporteEstadistico.php'">Volver</button>
</div>
<h1>INAC Activos</h1>
<h2>Reporte estadístico de activos y mantenimiento</h2>
<p>Fecha de generación: <?= date('d/m/Y H:i') ?></p>
<h3>Resumen general</h3>
<table>
<tr><th>Indicador</th><th>Resultado</th></tr>
<tr><td>Activos registrados</td><td><?= $activos ?></td></tr>
<tr><td>Valor total de activos</td><td>$<?= number_format($valor, 2) ?></td></tr>
<tr><td>Mantenimientos registrados</td><td><?= $mantenimientos ?></td></tr>
<tr><td>Mantenimientos pendientes</td><td><?= $pendientes ?></td></tr>
<tr><td>Costo total de mantenimientos</td><td>$<?= number_format($costo, 2) ?></td></tr>
</table>
<h3>Activos por tipo</h3>
<table>
<tr><th>Tipo</th><th>Cantidad</th><th>Porcentaje</th></tr>
<?php while ($x = $tipos->fetch_assoc()): ?>
<tr>
    <td><?= e($x['nombre']) ?></td>
    <td><?= (int)$x['cantidad'] ?></td>
    <td><?= $activos > 0
        ? number_format(((int)$x['cantidad'] / $activos) * 100, 1)
        : '0.0' ?>%</td>
</tr>
<?php endwhile; ?>
</table>
<h3>Activos por estado</h3>
<table>
<tr><th>Estado</th><th>Cantidad</th><th>Porcentaje</th></tr>
<?php while ($x = $estados->fetch_assoc()): ?>
<tr>
    <td><?= e($x['nombre_estado']) ?></td>
    <td><?= (int)$x['cantidad'] ?></td>
    <td><?= $activos > 0
        ? number_format(((int)$x['cantidad'] / $activos) * 100, 1)
        : '0.0' ?>%</td>
</tr>
<?php endwhile; ?>
</table>
<h3>Mantenimientos por tipo</h3>
<table>
<tr><th>Tipo</th><th>Cantidad</th><th>Costo total</th></tr>
<?php while ($x = $mant->fetch_assoc()): ?>
<tr>
    <td><?= e($x['nombre']) ?></td>
    <td><?= (int)$x['cantidad'] ?></td>
    <td>$<?= number_format((float)$x['costo'], 2) ?></td>
</tr>
<?php endwhile; ?>
</table>
</body>
</html>