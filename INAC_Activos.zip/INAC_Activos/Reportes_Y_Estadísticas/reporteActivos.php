<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
$rolActual = $_SESSION['rol'] ?? '';
if (!in_array($rolActual, ['Administrador', 'Editor', 'Operativo'], true)) {
    http_response_code(403);
    exit('No tienes permiso para consultar los reportes.');
}
function e($valor) {
    return htmlspecialchars((string)($valor ?? ''), ENT_QUOTES, 'UTF-8');
}
$tipo = filter_input(INPUT_GET, 'tipo', FILTER_VALIDATE_INT);
$estado = filter_input(INPUT_GET, 'estado', FILTER_VALIDATE_INT);
$ubicacion = filter_input(INPUT_GET, 'ubicacion', FILTER_VALIDATE_INT);
$tipo = ($tipo !== false && $tipo !== null && $tipo > 0) ? $tipo : 0;
$estado = ($estado !== false && $estado !== null && $estado > 0) ? $estado : 0;
$ubicacion = ($ubicacion !== false && $ubicacion !== null && $ubicacion > 0) ? $ubicacion : 0;
$tipos = $conn->query("
    SELECT id_tipo_activo, nombre
    FROM tipo_activo
    ORDER BY nombre
");
$estados = $conn->query("
    SELECT id_estado, nombre_estado
    FROM estado_activo
    ORDER BY nombre_estado
");
$ubicaciones = $conn->query("
    SELECT id_ubicacion, nombre
    FROM ubicacion
    ORDER BY nombre
");
if (!$tipos || !$estados || !$ubicaciones) {
    error_log('Error al cargar filtros del reporte de activos: ' . $conn->error);
    http_response_code(500);
    exit('No se pudieron cargar los filtros del reporte.');
}
$sql = "
    SELECT
        a.id_activo,
        a.codigo,
        a.nombre,
        a.marca,
        a.modelo,
        a.fecha_adquisicion,
        a.valor,
        t.nombre AS tipo,
        ea.nombre_estado,
        u.nombre AS ubicacion,
        CONCAT_WS(' ', r.nombre, r.apellido) AS responsable
    FROM activo a
    LEFT JOIN tipo_activo t
        ON a.id_tipo_activo = t.id_tipo_activo
    LEFT JOIN estado_activo ea
        ON a.id_estado = ea.id_estado
    LEFT JOIN ubicacion u
        ON a.id_ubicacion = u.id_ubicacion
    LEFT JOIN responsable r
        ON a.id_responsable = r.id_responsable
    WHERE 1 = 1
";
$parametros = [];
$tiposParametros = '';
if ($tipo > 0) {
    $sql .= " AND a.id_tipo_activo = ?";
    $parametros[] = $tipo;
    $tiposParametros .= 'i';
}
if ($estado > 0) {
    $sql .= " AND a.id_estado = ?";
    $parametros[] = $estado;
    $tiposParametros .= 'i';
}
if ($ubicacion > 0) {
    $sql .= " AND a.id_ubicacion = ?";
    $parametros[] = $ubicacion;
    $tiposParametros .= 'i';
}
$sql .= " ORDER BY a.codigo ASC";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    error_log('Error al preparar reporte de activos: ' . $conn->error);
    http_response_code(500);
    exit('No se pudo preparar el reporte de activos.');
}
if ($parametros) {
    $stmt->bind_param($tiposParametros, ...$parametros);
}
if (!$stmt->execute()) {
    error_log('Error al ejecutar reporte de activos: ' . $stmt->error);
    $stmt->close();
    http_response_code(500);
    exit('No se pudo generar el reporte de activos.');
}
$resultado = $stmt->get_result();
$activos = $resultado->fetch_all(MYSQLI_ASSOC);
$stmt->close();
if (isset($_GET['exportar']) && $_GET['exportar'] === 'csv') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="reporte_activos_filtrado.csv"');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
    $salida = fopen('php://output', 'w');
    fwrite($salida, "\xEF\xBB\xBF");
    fputcsv($salida, [
        'Código',
        'Activo',
        'Tipo',
        'Estado',
        'Ubicación',
        'Responsable',
        'Marca',
        'Modelo',
        'Fecha de adquisición',
        'Valor'
    ], ';');
    foreach ($activos as $a) {
        fputcsv($salida, [
            $a['codigo'],
            $a['nombre'],
            $a['tipo'],
            $a['nombre_estado'],
            $a['ubicacion'],
            $a['responsable'],
            $a['marca'],
            $a['modelo'],
            $a['fecha_adquisicion'],
            $a['valor']
        ], ';');
    }
    fclose($salida);
    exit;
}
$totalValor = 0;
foreach ($activos as $a) {
    $totalValor += (float)($a['valor'] ?? 0);
}
$queryExportar = http_build_query([
    'tipo' => $tipo,
    'estado' => $estado,
    'ubicacion' => $ubicacion,
    'exportar' => 'csv'
]);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reporte de activos | INAC Activos</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<style>
body {
    background: #F4F6F8;
    color: #263445;
    font-family: Arial, sans-serif;
}
h2 {
    color: #123B63;
    font-weight: 700;
}
.panel {
    background: white;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 2px 10px #0000000f;
    margin-bottom: 20px;
}
.btn-inac {
    background: #123B63;
    color: white;
}
.btn-inac:hover {
    background: #0c2c4b;
    color: white;
}
.tabla th {
    background: #123B63;
    color: white;
    white-space: nowrap;
}
.resumen {
    color: #123B63;
    font-weight: 700;
}
@media print {
    body {
        background: white !important;
        padding: 0;
    }
    .no-print {
        display: none !important;
    }
    .panel {
        box-shadow: none;
        border: 1px solid #ddd;
    }
    .table-responsive {
        overflow: visible !important;
    }
    table {
        font-size: 9pt;
    }
    .tabla th {
        background: #123B63 !important;
        color: white !important;
        print-color-adjust: exact;
        -webkit-print-color-adjust: exact;
    }
}
</style>
</head>
<body>
<div class="container-fluid p-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
            <h2><i class="bi bi-clipboard-data"></i> Reporte detallado de activos</h2>
            <p class="text-secondary mb-0">
                Consulta los activos por tipo, estado y ubicación.
            </p>
        </div>
        <button type="button" onclick="window.print()" class="btn btn-inac no-print">
            <i class="bi bi-printer"></i> Imprimir reporte
        </button>
    </div>
    <div class="panel no-print">
        <h5 class="mb-3"><i class="bi bi-funnel"></i> Filtrar activos</h5>
        <form method="GET" class="row g-3">
            <div class="col-md-4">
                <label for="tipo" class="form-label">Tipo de activo</label>
                <select name="tipo" id="tipo" class="form-select">
                    <option value="0">Todos los tipos</option>
                    <?php while ($x = $tipos->fetch_assoc()): ?>
                        <option
                            value="<?= (int)$x['id_tipo_activo'] ?>"
                            <?= $tipo === (int)$x['id_tipo_activo'] ? 'selected' : '' ?>>
                            <?= e($x['nombre']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label for="estado" class="form-label">Estado</label>
                <select name="estado" id="estado" class="form-select">
                    <option value="0">Todos los estados</option>
                    <?php while ($x = $estados->fetch_assoc()): ?>
                        <option
                            value="<?= (int)$x['id_estado'] ?>"
                            <?= $estado === (int)$x['id_estado'] ? 'selected' : '' ?>>
                            <?= e($x['nombre_estado']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label for="ubicacion" class="form-label">Ubicación</label>
                <select name="ubicacion" id="ubicacion" class="form-select">
                    <option value="0">Todas las ubicaciones</option>
                    <?php while ($x = $ubicaciones->fetch_assoc()): ?>
                        <option
                            value="<?= (int)$x['id_ubicacion'] ?>"
                            <?= $ubicacion === (int)$x['id_ubicacion'] ? 'selected' : '' ?>>
                            <?= e($x['nombre']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-12 d-flex flex-wrap gap-2">
                <button type="submit" class="btn btn-inac">
                    <i class="bi bi-search"></i> Aplicar filtros
                </button>
                <a href="reporteActivos.php" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-counterclockwise"></i> Limpiar
                </a>
                <a href="reporteActivos.php?<?= e($queryExportar) ?>" class="btn btn-success">
                    <i class="bi bi-filetype-csv"></i> Exportar CSV
                </a>
            </div>
        </form>
    </div>
    <div class="panel">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
            <div>
                <h5 class="mb-1">Resultados del reporte</h5>
                <p class="text-secondary small mb-0">
                    Fecha de generación: <?= date('d/m/Y') ?>
                </p>
            </div>
            <span class="badge text-bg-primary">
                <?= count($activos) ?> activo(s)
            </span>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered align-middle tabla">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Activo</th>
                        <th>Tipo</th>
                        <th>Estado</th>
                        <th>Ubicación</th>
                        <th>Responsable</th>
                        <th>Adquisición</th>
                        <th>Valor</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (count($activos) > 0): ?>
                    <?php foreach ($activos as $a): ?>
                        <tr>
                            <td><?= e($a['codigo']) ?></td>
                            <td>
                                <?= e($a['nombre']) ?>
                                <br>
                                <small class="text-secondary">
                                    <?= e(trim(($a['marca'] ?? '') . ' ' . ($a['modelo'] ?? ''))) ?>
                                </small>
                            </td>
                            <td><?= e($a['tipo'] ?: 'Sin tipo') ?></td>
                            <td><?= e($a['nombre_estado'] ?: 'Sin estado') ?></td>
                            <td><?= e($a['ubicacion'] ?: 'Sin ubicación') ?></td>
                            <td><?= e($a['responsable'] ?: 'Sin responsable') ?></td>
                            <td><?= e($a['fecha_adquisicion'] ?: 'No registrada') ?></td>
                            <td>$<?= number_format((float)$a['valor'], 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center py-4 text-secondary">
                            No se encontraron activos con los filtros seleccionados.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="d-flex flex-wrap justify-content-between gap-2 mt-3">
            <p class="mb-0">
                Total de activos mostrados: <strong><?= count($activos) ?></strong>
            </p>
            <h5 class="resumen mb-0">
                Valor total: $<?= number_format($totalValor, 2) ?>
            </h5>
        </div>
    </div>
    <a href="reportes.php" class="btn btn-outline-secondary no-print">
        <i class="bi bi-arrow-left"></i> Volver a reportes
    </a>
</div>
</body>
</html>