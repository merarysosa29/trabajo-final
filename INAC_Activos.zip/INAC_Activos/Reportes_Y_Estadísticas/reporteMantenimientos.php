<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$desde = $_GET['desde'] ?? '';
$hasta = $_GET['hasta'] ?? '';
$tipo = (int)($_GET['tipo'] ?? 0);
if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$desde)) $desde='';
if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$hasta)) $hasta='';
$tipos = $conexion->query("SELECT id_tipo_mantenimiento,nombre FROM tipo_mantenimiento ORDER BY nombre");
$sql = "SELECT m.id_mantenimiento,a.codigo,a.nombre AS activo,
        tm.nombre AS tipo,CONCAT(u.nombre,' ',u.apellido) AS usuario,
        m.fecha,m.fecha_falla,m.descripcion,m.reparacion_realizada,
        m.costo,m.estado_mantenimiento,m.proxima_fecha
        FROM mantenimiento m
        INNER JOIN activo a ON m.id_activo=a.id_activo
        INNER JOIN tipo_mantenimiento tm ON m.id_tipo_mantenimiento=tm.id_tipo_mantenimiento
        INNER JOIN usuario u ON m.id_usuario=u.id_usuario
        WHERE 1=1";
if($desde!=='') $sql .= " AND m.fecha >= '".$conexion->real_escape_string($desde)."'";
if($hasta!=='') $sql .= " AND m.fecha <= '".$conexion->real_escape_string($hasta)."'";
if($tipo>0) $sql .= " AND m.id_tipo_mantenimiento=$tipo";
$sql .= " ORDER BY m.fecha DESC";
$res=$conexion->query($sql);
if(!$res) exit('No se pudo consultar el reporte de mantenimientos.');
$total=0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reporte de mantenimientos</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:#F4F6F8;font-family:Arial}
h2{color:#123B63}.panel{background:white;padding:20px;border-radius:12px}
.btn-inac{background:#123B63;color:white}
@media print{.no-print{display:none!important}body{background:white}}
</style>
</head>
<body>
<div class="container-fluid p-4">
<div class="d-flex justify-content-between mb-3">
<h2>Reporte de mantenimientos</h2>
<button onclick="window.print()" class="btn btn-inac no-print">Imprimir</button>
</div>
<div class="panel mb-4 no-print">
<form method="GET" class="row g-3">
<div class="col-md-3"><label class="form-label">Fecha desde</label>
<input type="date" name="desde" class="form-control" value="<?= e($desde) ?>"></div>
<div class="col-md-3"><label class="form-label">Fecha hasta</label>
<input type="date" name="hasta" class="form-control" value="<?= e($hasta) ?>"></div>
<div class="col-md-4"><label class="form-label">Tipo de mantenimiento</label>
<select name="tipo" class="form-select"><option value="0">Todos</option>
<?php while($t=$tipos->fetch_assoc()): ?>
<option value="<?= $t['id_tipo_mantenimiento'] ?>" <?= $tipo==$t['id_tipo_mantenimiento']?'selected':'' ?>><?= e($t['nombre']) ?></option>
<?php endwhile; ?>
</select></div>
<div class="col-12">
<button class="btn btn-inac">Aplicar filtros</button>
<a href="reporteMantenimientos.php" class="btn btn-outline-secondary">Limpiar</a>
<a href="generarReporteMantenimientos.php?desde=<?= urlencode($desde) ?>&hasta=<?= urlencode($hasta) ?>&tipo=<?= $tipo ?>" class="btn btn-success">Generar reporte</a>
</div>
</form>
</div>
<div class="panel">
<p><strong>Fecha del reporte:</strong> <?= date('d/m/Y') ?></p>
<div class="table-responsive">
<table class="table table-bordered table-striped">
<thead class="table-dark">
<tr><th>Activo</th><th>Tipo</th><th>Fecha</th><th>Descripción</th><th>Reparación</th><th>Costo</th><th>Estado</th><th>Próxima fecha</th></tr>
</thead><tbody>
<?php while($m=$res->fetch_assoc()): $total+=(float)$m['costo']; ?>
<tr>
<td><?= e($m['codigo'].' - '.$m['activo']) ?></td><td><?= e($m['tipo']) ?></td>
<td><?= e($m['fecha']) ?></td><td><?= e($m['descripcion']) ?></td>
<td><?= e($m['reparacion_realizada'] ?: 'No registrada') ?></td>
<td>$<?= number_format((float)$m['costo'],2) ?></td><td><?= e($m['estado_mantenimiento']) ?></td>
<td><?= e($m['proxima_fecha'] ?: 'No programada') ?></td>
</tr>
<?php endwhile; ?>
</tbody></table>
</div>
<h5 class="text-end">Costo total: $<?= number_format($total,2) ?></h5>
<p>Total de mantenimientos: <?= $res->num_rows ?></p>
</div>
<a href="reportes.php" class="btn btn-outline-secondary mt-3 no-print">Volver a reportes</a>
</div>
</body>
</html>