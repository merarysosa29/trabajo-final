<?php
require_once '../Sesiones.php';
require_once '../Conexion.php';
$rolActual = $_SESSION['rol'] ?? '';
if (!in_array($rolActual, ['Administrador', 'Editor', 'Operativo'], true)) {
    http_response_code(403);
    exit('No tienes permiso para consultar los reportes.');
}
function h($valor) {
    return htmlspecialchars((string)($valor ?? ''), ENT_QUOTES, 'UTF-8');
}
$totalActivos = 0;
$valorTotalActivos = 0;
$totalMantenimientos = 0;
$pendientes = 0;
$enProceso = 0;
$realizados = 0;
$costoTotalMantenimientos = 0;
$sqlActivos = "
    SELECT
        COUNT(*) AS total,
        COALESCE(SUM(valor), 0) AS valor_total
    FROM activo
";
$resultado = $conn->query($sqlActivos);
if ($resultado) {
    $datos = $resultado->fetch_assoc();
    $totalActivos = (int)$datos['total'];
    $valorTotalActivos = (float)$datos['valor_total'];
}
$sqlMantenimiento = "
    SELECT
        COUNT(*) AS total,
        COALESCE(SUM(CASE
            WHEN LOWER(estado_mantenimiento) = 'pendiente'
            THEN 1 ELSE 0
        END), 0) AS pendientes,
        COALESCE(SUM(CASE
            WHEN LOWER(estado_mantenimiento) IN ('en proceso', 'en_proceso')
            THEN 1 ELSE 0
        END), 0) AS en_proceso,
        COALESCE(SUM(CASE
            WHEN LOWER(estado_mantenimiento) IN ('realizado', 'realizada', 'completado', 'completada')
            THEN 1 ELSE 0
        END), 0) AS realizados,
        COALESCE(SUM(costo), 0) AS costo_total
    FROM mantenimiento
";
$resultado = $conn->query($sqlMantenimiento);
if ($resultado) {
    $datos = $resultado->fetch_assoc();
    $totalMantenimientos = (int)$datos['total'];
    $pendientes = (int)$datos['pendientes'];
    $enProceso = (int)$datos['en_proceso'];
    $realizados = (int)$datos['realizados'];
    $costoTotalMantenimientos = (float)$datos['costo_total'];
}
$activosPorTipo = $conn->query("
    SELECT
        ta.nombre AS tipo,
        COUNT(a.id_activo) AS total
    FROM tipo_activo ta
    LEFT JOIN activo a
        ON a.id_tipo_activo = ta.id_tipo_activo
    GROUP BY ta.id_tipo_activo, ta.nombre
    ORDER BY ta.nombre
");
$activosPorEstado = $conn->query("
    SELECT
        ea.nombre_estado AS estado,
        COUNT(a.id_activo) AS total
    FROM estado_activo ea
    LEFT JOIN activo a
        ON a.id_estado = ea.id_estado
    GROUP BY ea.id_estado, ea.nombre_estado
    ORDER BY ea.nombre_estado
");
$mantenimientosPorTipo = $conn->query("
    SELECT
        tm.nombre AS tipo,
        COUNT(m.id_mantenimiento) AS total,
        COALESCE(SUM(m.costo), 0) AS costo_total
    FROM tipo_mantenimiento tm
    LEFT JOIN mantenimiento m
        ON m.id_tipo_mantenimiento = tm.id_tipo_mantenimiento
    GROUP BY tm.id_tipo_mantenimiento, tm.nombre
    ORDER BY tm.nombre
");
$listaActivos = $conn->query("
    SELECT
        a.codigo,
        a.nombre AS activo,
        ta.nombre AS tipo,
        ea.nombre_estado AS estado,
        u.nombre AS ubicacion,
        CONCAT_WS(' ', r.nombre, r.apellido) AS responsable,
        a.valor
    FROM activo a
    LEFT JOIN tipo_activo ta
        ON ta.id_tipo_activo = a.id_tipo_activo
    LEFT JOIN estado_activo ea
        ON ea.id_estado = a.id_estado
    LEFT JOIN ubicacion u
        ON u.id_ubicacion = a.id_ubicacion
    LEFT JOIN responsable r
        ON r.id_responsable = a.id_responsable
    ORDER BY a.codigo ASC
");
$listaMantenimientos = $conn->query("
    SELECT
        a.codigo,
        a.nombre AS activo,
        tm.nombre AS tipo,
        m.fecha,
        m.fecha_falla,
        m.proxima_fecha,
        m.descripcion,
        m.reparacion_realizada,
        m.costo,
        m.estado_mantenimiento
    FROM mantenimiento m
    LEFT JOIN activo a
        ON a.id_activo = m.id_activo
    LEFT JOIN tipo_mantenimiento tm
        ON tm.id_tipo_mantenimiento = m.id_tipo_mantenimiento
    ORDER BY m.fecha DESC, m.id_mantenimiento DESC
");
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reportes y estadísticas | INAC Activos</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
    margin: 0;
    background: #F4F6F8;
    color: #263445;
    font-family: Arial, sans-serif;
}
.contenedor {
    max-width: 1500px;
    margin: 25px auto;
    padding: 0 18px;
}
.encabezado,
.panel,
.tarjeta-indicador {
    background: #fff;
    border-radius: 12px;
    padding: 22px;
    margin-bottom: 20px;
    box-shadow: 0 3px 12px rgba(18, 59, 99, 0.08);
}
.encabezado {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    flex-wrap: wrap;
}
h1 {
    color: #123B63;
    font-size: 27px;
    font-weight: bold;
    margin-bottom: 8px;
}
h2 {
    color: #123B63;
    font-size: 20px;
    font-weight: bold;
    margin-bottom: 18px;
}
h3 {
    color: #123B63;
    font-size: 17px;
    font-weight: bold;
    margin-bottom: 15px;
}
.subtitulo {
    color: #667788;
    margin: 0;
}
.btn-principal {
    background: #123B63;
    color: #fff;
    border: none;
}
.btn-principal:hover {
    background: #0c2b49;
    color: #fff;
}
.indicador {
    color: #667788;
    font-size: 14px;
    margin-bottom: 8px;
}
.valor-indicador {
    color: #123B63;
    font-size: 27px;
    font-weight: bold;
    overflow-wrap: anywhere;
}
.tabla-contenedor {
    overflow-x: auto;
}
.table {
    vertical-align: middle;
    font-size: 13px;
    margin-bottom: 0;
}
.table thead th {
    background: #123B63;
    color: #fff;
    white-space: nowrap;
}
.table td {
    overflow-wrap: anywhere;
}
.seccion {
    scroll-margin-top: 20px;
}
.enlaces-reporte {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 20px;
}
@media print {
    body {
        background: #fff;
        color: #000;
        font-size: 10px;
    }
    .contenedor {
        max-width: none;
        margin: 0;
        padding: 0;
    }
    .encabezado,
    .panel,
    .tarjeta-indicador {
        box-shadow: none;
        border: 1px solid #ddd;
        border-radius: 0;
        padding: 10px;
        margin-bottom: 10px;
        break-inside: avoid;
    }
    .encabezado {
        display: block;
    }
    .no-imprimir {
        display: none !important;
    }
    h1 {
        font-size: 20px;
    }
    h2 {
        font-size: 15px;
    }
    h3 {
        font-size: 13px;
    }
    .valor-indicador {
        font-size: 17px;
    }
    .table {
        font-size: 9px;
    }
    .table thead th {
        background: #e5e5e5 !important;
        color: #000 !important;
        print-color-adjust: exact;
        -webkit-print-color-adjust: exact;
    }
    .tabla-contenedor {
        overflow: visible;
    }
    .table-responsive {
        overflow: visible !important;
    }
    a {
        color: #000 !important;
        text-decoration: none !important;
    }
    @page {
        size: landscape;
        margin: 10mm;
    }
}
</style>
</head>
<body>
<div class="contenedor">
    <header class="encabezado">
        <div>
            <h1>Reportes y estadísticas</h1>
            <p class="subtitulo">
                Sistema de gestión de activos fijos y mantenimiento preventivo y correctivo.
            </p>
        </div>
        <div class="no-imprimir">
            <button type="button" class="btn btn-principal" onclick="window.print()">
                Imprimir todos los reportes
            </button>
        </div>
    </header>
    <nav class="enlaces-reporte no-imprimir">
        <a href="#resumen" class="btn btn-outline-primary">Resumen general</a>
        <a href="#activos" class="btn btn-outline-primary">Reporte de activos</a>
        <a href="#mantenimientos" class="btn btn-outline-primary">Reporte de mantenimientos</a>
        <a href="#estadisticas" class="btn btn-outline-primary">Estadísticas</a>
    </nav>
    <section id="resumen" class="seccion">
        <h2>Resumen general</h2>
        <div class="row g-3">
            <div class="col-md-4">
                <div class="tarjeta-indicador">
                    <div class="indicador">Total de activos registrados</div>
                    <div class="valor-indicador">
                        <?= number_format($totalActivos) ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="tarjeta-indicador">
                    <div class="indicador">Valor total de los activos</div>
                    <div class="valor-indicador">
                        $<?= number_format($valorTotalActivos, 2) ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="tarjeta-indicador">
                    <div class="indicador">Total de mantenimientos</div>
                    <div class="valor-indicador">
                        <?= number_format($totalMantenimientos) ?>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="tarjeta-indicador">
                    <div class="indicador">Mantenimientos pendientes</div>
                    <div class="valor-indicador">
                        <?= number_format($pendientes) ?>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="tarjeta-indicador">
                    <div class="indicador">Mantenimientos en proceso</div>
                    <div class="valor-indicador">
                        <?= number_format($enProceso) ?>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="tarjeta-indicador">
                    <div class="indicador">Mantenimientos realizados</div>
                    <div class="valor-indicador">
                        <?= number_format($realizados) ?>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="tarjeta-indicador">
                    <div class="indicador">Costo acumulado de mantenimiento</div>
                    <div class="valor-indicador">
                        $<?= number_format($costoTotalMantenimientos, 2) ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="activos" class="panel seccion">
        <h2>Reporte general de activos fijos</h2>
        <p>
            <strong>Total de activos:</strong>
            <?= number_format($totalActivos) ?>
            &nbsp; | &nbsp;
            <strong>Valor total:</strong>
            $<?= number_format($valorTotalActivos, 2) ?>
        </p>
        <div class="tabla-contenedor">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Activo</th>
                        <th>Tipo</th>
                        <th>Estado</th>
                        <th>Ubicación actual</th>
                        <th>Responsable</th>
                        <th>Valor</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($listaActivos && $listaActivos->num_rows > 0): ?>
                    <?php while ($activo = $listaActivos->fetch_assoc()): ?>
                        <tr>
                            <td><?= h($activo['codigo']) ?></td>
                            <td><?= h($activo['activo']) ?></td>
                            <td><?= h($activo['tipo'] ?: 'Sin tipo') ?></td>
                            <td><?= h($activo['estado'] ?: 'Sin estado') ?></td>
                            <td><?= h($activo['ubicacion'] ?: 'Sin ubicación') ?></td>
                            <td><?= h(trim($activo['responsable'] ?? '') ?: 'Sin responsable') ?></td>
                            <td>$<?= number_format((float)$activo['valor'], 2) ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center">
                            No hay activos registrados.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="6" class="text-end">
                            Valor total de los activos:
                        </th>
                        <th>$<?= number_format($valorTotalActivos, 2) ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </section>
    <section id="mantenimientos" class="panel seccion">
        <h2>Reporte general de mantenimientos</h2>
        <p>
            <strong>Total de registros:</strong>
            <?= number_format($totalMantenimientos) ?>
            &nbsp; | &nbsp;
            <strong>Costo acumulado:</strong>
            $<?= number_format($costoTotalMantenimientos, 2) ?>
        </p>
        <div class="tabla-contenedor">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Código del activo</th>
                        <th>Activo</th>
                        <th>Tipo de mantenimiento</th>
                        <th>Fecha</th>
                        <th>Fecha de falla</th>
                        <th>Próxima fecha</th>
                        <th>Descripción</th>
                        <th>Reparación realizada</th>
                        <th>Estado</th>
                        <th>Costo</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($listaMantenimientos && $listaMantenimientos->num_rows > 0): ?>
                    <?php while ($mantenimiento = $listaMantenimientos->fetch_assoc()): ?>
                        <tr>
                            <td><?= h($mantenimiento['codigo'] ?: 'Sin código') ?></td>
                            <td><?= h($mantenimiento['activo'] ?: 'Sin activo') ?></td>
                            <td><?= h($mantenimiento['tipo'] ?: 'Sin tipo') ?></td>
                            <td>
                                <?= !empty($mantenimiento['fecha'])
                                    ? h(date('d/m/Y', strtotime($mantenimiento['fecha'])))
                                    : 'No registrada' ?>
                            </td>
                            <td>
                                <?= !empty($mantenimiento['fecha_falla'])
                                    ? h(date('d/m/Y', strtotime($mantenimiento['fecha_falla'])))
                                    : 'No aplica' ?>
                            </td>
                            <td>
                                <?= !empty($mantenimiento['proxima_fecha'])
                                    ? h(date('d/m/Y', strtotime($mantenimiento['proxima_fecha'])))
                                    : 'No programada' ?>
                            </td>
                            <td><?= h($mantenimiento['descripcion'] ?: 'Sin descripción') ?></td>
                            <td><?= h($mantenimiento['reparacion_realizada'] ?: 'No registrada') ?></td>
                            <td><?= h($mantenimiento['estado_mantenimiento']) ?></td>
                            <td>$<?= number_format((float)$mantenimiento['costo'], 2) ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="10" class="text-center">
                            No hay mantenimientos registrados.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
    <section id="estadisticas" class="seccion">
        <h2>Estadísticas de activos y mantenimiento</h2>
        <div class="panel">
            <h3>Activos por tipo</h3>
            <div class="tabla-contenedor">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Tipo de activo</th>
                            <th>Cantidad</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($activosPorTipo && $activosPorTipo->num_rows > 0): ?>
                        <?php while ($fila = $activosPorTipo->fetch_assoc()): ?>
                            <tr>
                                <td><?= h($fila['tipo']) ?></td>
                                <td><?= number_format((int)$fila['total']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="2">No hay datos disponibles.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="panel">
            <h3>Activos por estado</h3>
            <div class="tabla-contenedor">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Estado del activo</th>
                            <th>Cantidad</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($activosPorEstado && $activosPorEstado->num_rows > 0): ?>
                        <?php while ($fila = $activosPorEstado->fetch_assoc()): ?>
                            <tr>
                                <td><?= h($fila['estado']) ?></td>
                                <td><?= number_format((int)$fila['total']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="2">No hay datos disponibles.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="panel">
            <h3>Mantenimientos por tipo</h3>
            <div class="tabla-contenedor">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Tipo de mantenimiento</th>
                            <th>Cantidad</th>
                            <th>Costo acumulado</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($mantenimientosPorTipo && $mantenimientosPorTipo->num_rows > 0): ?>
                        <?php while ($fila = $mantenimientosPorTipo->fetch_assoc()): ?>
                            <tr>
                                <td><?= h($fila['tipo']) ?></td>
                                <td><?= number_format((int)$fila['total']) ?></td>
                                <td>$<?= number_format((float)$fila['costo_total'], 2) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3">No hay datos disponibles.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>
</body>
</html>