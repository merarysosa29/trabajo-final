-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: sql300.infinityfree.com
-- Tiempo de generación: 16-10-2026 a las 09:11:11
-- Versión del servidor: 11.4.13-MariaDB
-- Versión de PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `if0_42034035_inac_activos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `activo`
--

CREATE TABLE `activo` (
  `id_activo` int(11) NOT NULL,
  `codigo` varchar(20) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `marca` varchar(50) DEFAULT NULL,
  `modelo` varchar(50) DEFAULT NULL,
  `numero_serie` varchar(50) DEFAULT NULL,
  `fecha_adquisicion` date DEFAULT NULL,
  `valor` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ubicacion_compra` varchar(150) DEFAULT NULL,
  `id_tipo_activo` int(11) NOT NULL,
  `id_ubicacion` int(11) NOT NULL,
  `id_responsable` int(11) DEFAULT NULL,
  `id_estado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `activo`
--

INSERT INTO `activo` (`id_activo`, `codigo`, `nombre`, `descripcion`, `marca`, `modelo`, `numero_serie`, `fecha_adquisicion`, `valor`, `ubicacion_compra`, `id_tipo_activo`, `id_ubicacion`, `id_responsable`, `id_estado`) VALUES
(1, 'ACT-001', 'Computadora de dirección', 'Equipo para oficina', 'Dell', 'OptiPlex', 'SER001', '2025-01-15', '650.00', 'Proveedor local', 1, 5, 12, 1),
(2, 'ACT-002', 'Laptop administrativa', 'Equipo portátil', 'HP', 'ProBook', 'SER002', '2025-02-10', '720.00', 'Proveedor local', 2, 4, 5, 1),
(3, 'ACT-003', 'Monitor de laboratorio', 'Pantalla de computadora', 'Samsung', 'S24', 'SER003', '2025-03-05', '150.00', 'Tienda informática', 3, 9, 7, 1),
(4, 'ACT-004', 'Impresora de secretaría', 'Impresión de documentos', 'Canon', 'G3110', 'SER004', '2025-03-12', '180.00', 'Tienda informática', 4, 3, 4, 2),
(5, 'ACT-005', 'Proyector de aula 1', 'Proyección de clases', 'Epson', 'X49', 'SER005', '2025-04-01', '480.00', 'Proveedor local', 5, 5, 3, 1),
(6, 'ACT-006', 'Teclado de oficina', 'Periférico de entrada', 'Logitech', 'K120', 'SER006', '2025-04-10', '18.00', 'Tienda informática', 6, 4, 5, 1),
(7, 'ACT-007', 'Ratón de oficina', 'Periférico de entrada', 'Logitech', 'M90', 'SER007', '2025-04-10', '12.00', 'Tienda informática', 7, 4, 5, 1),
(8, 'ACT-008', 'Escáner de secretaría', 'Digitalización de documentos', 'Canon', 'Lide 300', 'SER008', '2025-05-02', '95.00', 'Proveedor local', 8, 3, 4, 2),
(9, 'ACT-009', 'Servidor de informática', 'Servidor institucional', 'Dell', 'PowerEdge', 'SER009', '2025-01-20', '1800.00', 'Proveedor tecnológico', 9, 10, 7, 1),
(10, 'ACT-010', 'Router principal', 'Conectividad de red', 'TP-Link', 'Archer', 'SER010', '2025-02-15', '85.00', 'Tienda informática', 10, 10, 11, 1),
(11, 'ACT-011', 'Switch de laboratorio', 'Conexión de equipos', 'Cisco', 'CBS110', 'SER011', '2025-02-20', '120.00', 'Proveedor tecnológico', 11, 9, 11, 2),
(12, 'ACT-012', 'UPS de servidor', 'Respaldo eléctrico', 'APC', 'Back-UPS', 'SER012', '2025-03-01', '140.00', 'Proveedor tecnológico', 12, 10, 7, 4),
(13, 'ACT-013', 'Teléfono administrativo', 'Comunicación institucional', 'Panasonic', 'KX', 'SER013', '2025-03-18', '45.00', 'Tienda local', 13, 4, 5, 1),
(14, 'ACT-014', 'Tablet de dirección', 'Dispositivo portátil', 'Samsung', 'Tab A', 'SER014', '2025-04-08', '230.00', 'Proveedor local', 14, 1, 1, 1),
(15, 'ACT-015', 'Cámara de auditorio', 'Registro audiovisual', 'Canon', 'EOS', 'SER015', '2025-04-20', '500.00', 'Proveedor audiovisual', 15, 19, 15, 2),
(16, 'ACT-016', 'Micrófono de auditorio', 'Captura de audio', 'Shure', 'SM58', 'SER016', '2025-05-05', '110.00', 'Proveedor audiovisual', 16, 19, 15, 1),
(17, 'ACT-017', 'Bocinas de auditorio', 'Reproducción de sonido', 'JBL', 'Control', 'SER017', '2025-05-10', '260.00', 'Proveedor audiovisual', 17, 19, 15, 1),
(18, 'ACT-018', 'Aire acondicionado', 'Climatización de oficina', 'Mabe', 'Mini Split', 'SER018', '2025-01-25', '600.00', 'Proveedor local', 18, 2, 2, 3),
(19, 'ACT-019', 'Escritorio administrativo', 'Mobiliario de oficina', 'Genérico', 'Estándar', 'SER019', '2025-02-01', '130.00', 'Mueblería local', 19, 4, 5, 1),
(20, 'ACT-020', 'Silla de laboratorio', 'Mobiliario de laboratorio', 'Genérico', 'Ergonómica', 'SER020', '2025-02-05', '75.00', 'Mueblería local', 20, 9, 7, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignacion_activo`
--

CREATE TABLE `asignacion_activo` (
  `id_asignacion` int(11) NOT NULL,
  `id_activo` int(11) NOT NULL,
  `id_responsable` int(11) DEFAULT NULL,
  `id_ubicacion` int(11) NOT NULL,
  `fecha_asignacion` date NOT NULL,
  `fecha_fin` date DEFAULT NULL,
  `observaciones` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `asignacion_activo`
--

INSERT INTO `asignacion_activo` (`id_asignacion`, `id_activo`, `id_responsable`, `id_ubicacion`, `fecha_asignacion`, `fecha_fin`, `observaciones`) VALUES
(1, 1, 1, 1, '2026-10-15', '2026-10-15', 'Registro inicial de la asignación existente'),
(2, 2, 5, 4, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(3, 3, 7, 9, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(4, 4, 4, 3, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(5, 5, 3, 5, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(6, 6, 5, 4, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(7, 7, 5, 4, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(8, 8, 4, 3, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(9, 9, 7, 10, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(10, 10, 11, 10, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(11, 11, 11, 9, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(12, 12, 7, 10, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(13, 13, 5, 4, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(14, 14, 1, 1, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(15, 15, 15, 19, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(16, 16, 15, 19, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(17, 17, 15, 19, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(18, 18, 2, 2, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(19, 19, 5, 4, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(20, 20, 7, 9, '2026-10-15', NULL, 'Registro inicial de la asignación existente'),
(32, 1, 12, 7, '2026-10-15', '2026-10-15', 'Cambio de ubicación o responsable'),
(33, 1, 12, 5, '2026-10-15', NULL, 'Cambio de ubicación o responsable');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_activo`
--

CREATE TABLE `estado_activo` (
  `id_estado` int(11) NOT NULL,
  `nombre_estado` varchar(50) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `estado_activo`
--

INSERT INTO `estado_activo` (`id_estado`, `nombre_estado`, `descripcion`) VALUES
(1, 'Bueno', 'Activo en buen estado'),
(2, 'Regular', 'Activo que requiere seguimiento'),
(3, 'Dañado', 'Activo que presenta daños'),
(4, 'En mantenimiento', 'Activo en proceso de mantenimiento'),
(5, 'Baja', 'Activo retirado del servicio');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mantenimiento`
--

CREATE TABLE `mantenimiento` (
  `id_mantenimiento` int(11) NOT NULL,
  `id_activo` int(11) NOT NULL,
  `id_tipo_mantenimiento` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `fecha_falla` date DEFAULT NULL,
  `descripcion` varchar(255) NOT NULL,
  `reparacion_realizada` varchar(255) DEFAULT NULL,
  `costo` decimal(10,2) NOT NULL DEFAULT 0.00,
  `observaciones` varchar(255) DEFAULT NULL,
  `estado_mantenimiento` varchar(30) NOT NULL DEFAULT 'Pendiente',
  `proxima_fecha` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `mantenimiento`
--

INSERT INTO `mantenimiento` (`id_mantenimiento`, `id_activo`, `id_tipo_mantenimiento`, `id_usuario`, `fecha`, `fecha_falla`, `descripcion`, `reparacion_realizada`, `costo`, `observaciones`, `estado_mantenimiento`, `proxima_fecha`) VALUES
(1, 1, 1, 1, '2026-11-07', NULL, 'Limpieza interna y revisión general del equipo.', 'Limpieza interna y revisión general del equipo.', '15.00', 'Equipo en buen estado.', 'Realizado', '2026-11-27'),
(2, 13, 2, 1, '2026-10-15', '2026-10-14', 'El teléfono presenta interrupciones durante las llamadas y dificultad para escuchar el audio.', 'Pendiente de reparación.', '20.00', 'El equipo continúa presentando fallas. Se encuentra pendiente de revisión técnica para determinar la causa del problema.', 'En proceso', '2027-04-15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `responsable`
--

CREATE TABLE `responsable` (
  `id_responsable` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `cargo` varchar(50) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `estado` varchar(20) NOT NULL DEFAULT 'Activo',
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `responsable`
--

INSERT INTO `responsable` (`id_responsable`, `nombre`, `apellido`, `cargo`, `telefono`, `correo`, `estado`, `foto`) VALUES
(1, 'Carlos', 'Martínez', 'Director', '70000001', 'carlos.martinez@example.com', 'Activo', 'uploads/responsable_0f856621d6a00e4a705af5d36c5d5558.webp'),
(2, 'Ana', 'López', 'Subdirectora', '70000002', 'ana.lopez@example.com', 'Activo', 'uploads/responsable_0d0f620798f9d3347442140dd354a7b0.png'),
(3, 'José', 'Hernández', 'Docente', '70000003', 'jose.hernandez@example.com', 'Activo', NULL),
(4, 'María', 'García', 'Secretaria', '70000004', 'maria.garcia@example.com', 'Activo', NULL),
(5, 'Pedro', 'Ramírez', 'Administrador', '70000005', 'pedro.ramirez@example.com', 'Activo', NULL),
(6, 'Lucía', 'Flores', 'Docente', '70000006', 'lucia.flores@example.com', 'Activo', NULL),
(7, 'Miguel', 'Torres', 'Técnico', '70000007', 'miguel.torres@example.com', 'Activo', NULL),
(8, 'Sofía', 'Rivera', 'Docente', '70000008', 'sofia.rivera@example.com', 'Activo', NULL),
(9, 'David', 'Castro', 'Contador', '70000009', 'david.castro@example.com', 'Activo', NULL),
(10, 'Elena', 'Morales', 'Docente', '70000010', 'elena.morales@example.com', 'Activo', NULL),
(11, 'Daniel', 'Cruz', 'Técnico', '70000011', 'daniel.cruz@example.com', 'Activo', NULL),
(12, 'Patricia', 'Reyes', 'Secretaria', '70000012', 'patricia.reyes@example.com', 'Activo', NULL),
(13, 'Roberto', 'Díaz', 'Docente', '70000013', 'roberto.diaz@example.com', 'Activo', NULL),
(14, 'Gabriela', 'Mendoza', 'Administradora', '70000014', 'gabriela.mendoza@example.com', 'Activo', NULL),
(15, 'Fernando', 'Vásquez', 'Técnico', '70000015', 'fernando.vasquez@example.com', 'Activo', NULL),
(16, 'Andrea', 'Romero', 'Docente', '70000016', 'andrea.romero@example.com', 'Activo', NULL),
(17, 'Óscar', 'Guardado', 'Encargado de bodega', '70000017', 'oscar.guardado@example.com', 'Activo', NULL),
(18, 'Beatriz', 'Aguilar', 'Docente', '70000018', 'beatriz.aguilar@example.com', 'Activo', NULL),
(19, 'Ricardo', 'Peña', 'Técnico', '70000019', 'ricardo.pena@example.com', 'Activo', NULL),
(20, 'Claudia', 'Portillo', 'Administradora', '70000020', 'claudia.portillo@example.com', 'Activo', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

CREATE TABLE `rol` (
  `id_rol` int(11) NOT NULL,
  `nombre_rol` varchar(50) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`id_rol`, `nombre_rol`, `descripcion`) VALUES
(1, 'Administrador', 'Acceso completo al sistema'),
(2, 'Editor', 'Gestiona activos y mantenimientos'),
(3, 'Operativo', 'Consulta y realiza funciones autorizadas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_activo`
--

CREATE TABLE `tipo_activo` (
  `id_tipo_activo` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `tipo_activo`
--

INSERT INTO `tipo_activo` (`id_tipo_activo`, `nombre`, `descripcion`) VALUES
(1, 'Computadora de escritorio', 'Equipo informático'),
(2, 'Laptop', 'Computadora portátil'),
(3, 'Monitor', 'Pantalla de computadora'),
(4, 'Impresora', 'Equipo de impresión'),
(5, 'Proyector', 'Equipo de proyección'),
(6, 'Teclado', 'Periférico de entrada'),
(7, 'Ratón', 'Periférico de entrada'),
(8, 'Escáner', 'Equipo de digitalización'),
(9, 'Servidor', 'Equipo de procesamiento'),
(10, 'Router', 'Equipo de red'),
(11, 'Switch', 'Equipo de conexión de red'),
(12, 'UPS', 'Sistema de alimentación ininterrumpida'),
(13, 'Teléfono', 'Equipo de comunicación'),
(14, 'Tablet', 'Dispositivo portátil'),
(15, 'Cámara', 'Equipo de captura de imagen'),
(16, 'Micrófono', 'Equipo de audio'),
(17, 'Bocinas', 'Equipo de sonido'),
(18, 'Aire acondicionado', 'Equipo de climatización'),
(19, 'Escritorio', 'Mobiliario'),
(20, 'Silla', 'Mobiliario');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_mantenimiento`
--

CREATE TABLE `tipo_mantenimiento` (
  `id_tipo_mantenimiento` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `tipo_mantenimiento`
--

INSERT INTO `tipo_mantenimiento` (`id_tipo_mantenimiento`, `nombre`, `descripcion`) VALUES
(1, 'Preventivo', 'Mantenimiento planificado'),
(2, 'Correctivo', 'Mantenimiento por falla o daño');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubicacion`
--

CREATE TABLE `ubicacion` (
  `id_ubicacion` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `estado` enum('Activa','Inactiva') NOT NULL DEFAULT 'Activa'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `ubicacion`
--

INSERT INTO `ubicacion` (`id_ubicacion`, `nombre`, `descripcion`, `estado`) VALUES
(1, 'Dirección', 'Oficina de dirección', 'Activa'),
(2, 'Subdirección', 'Oficina de subdirección', 'Activa'),
(3, 'Secretaría', 'Área de secretaría', 'Activa'),
(4, 'Administración', 'Área administrativa', 'Activa'),
(5, 'Aula 1', 'Aula de clases', 'Activa'),
(6, 'Aula 2', 'Aula de clases', 'Activa'),
(7, 'Aula 3', 'Aula de clases', 'Activa'),
(8, 'Aula 4', 'Aula de clases', 'Activa'),
(9, 'Laboratorio 1', 'Laboratorio informático', 'Activa'),
(10, 'Laboratorio 2', 'Laboratorio informático', 'Activa'),
(11, 'Biblioteca', 'Área de biblioteca', 'Activa'),
(12, 'Sala de docentes', 'Área de docentes', 'Activa'),
(13, 'Sala de reuniones', 'Área de reuniones', 'Activa'),
(14, 'Bodega', 'Área de almacenamiento', 'Activa'),
(15, 'Recepción', 'Área de recepción', 'Activa'),
(16, 'Contabilidad', 'Área contable', 'Activa'),
(17, 'Recursos Humanos', 'Área de recursos humanos', 'Activa'),
(18, 'Pasillo principal', 'Área de circulación', 'Activa'),
(19, 'Auditorio', 'Área de eventos', 'Activa'),
(20, 'Taller', 'Área de trabajo técnico', 'Activa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL DEFAULT '',
  `usuario` varchar(50) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `id_rol` int(11) NOT NULL,
  `estado` varchar(20) NOT NULL DEFAULT 'Activo'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nombre`, `apellido`, `usuario`, `contrasena`, `id_rol`, `estado`) VALUES
(1, 'Ana', 'Benett', 'Administrador', '$2y$12$zCJU.eAUlw4axbWoXGZNRuF/4sclQN9bSwpnp7HuAZES9mhN2TaQe', 1, 'Activo'),
(2, 'Irina', 'Mijaíl', 'Editor', '$2y$12$v6yhDHn2qd1hpcVh.vwrROjoE1PmPtYEVGlqUexRC1xWx3330hm/2', 2, 'Activo'),
(3, 'Yuri', 'Ivanov', 'Operativo', '$2y$12$j5TnhLCUiyF5g3AOYhAHyePHW9kFYikrrTtwnI/mnxVNNOV9IB272', 3, 'Activo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `activo`
--
ALTER TABLE `activo`
  ADD PRIMARY KEY (`id_activo`),
  ADD UNIQUE KEY `codigo` (`codigo`),
  ADD KEY `id_tipo_activo` (`id_tipo_activo`),
  ADD KEY `id_ubicacion` (`id_ubicacion`),
  ADD KEY `id_responsable` (`id_responsable`),
  ADD KEY `id_estado` (`id_estado`);

--
-- Indices de la tabla `asignacion_activo`
--
ALTER TABLE `asignacion_activo`
  ADD PRIMARY KEY (`id_asignacion`),
  ADD KEY `idx_asignacion_activo` (`id_activo`),
  ADD KEY `idx_asignacion_responsable` (`id_responsable`),
  ADD KEY `idx_asignacion_ubicacion` (`id_ubicacion`);

--
-- Indices de la tabla `estado_activo`
--
ALTER TABLE `estado_activo`
  ADD PRIMARY KEY (`id_estado`),
  ADD UNIQUE KEY `nombre_estado` (`nombre_estado`);

--
-- Indices de la tabla `mantenimiento`
--
ALTER TABLE `mantenimiento`
  ADD PRIMARY KEY (`id_mantenimiento`),
  ADD KEY `id_activo` (`id_activo`),
  ADD KEY `id_tipo_mantenimiento` (`id_tipo_mantenimiento`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `responsable`
--
ALTER TABLE `responsable`
  ADD PRIMARY KEY (`id_responsable`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`id_rol`),
  ADD UNIQUE KEY `nombre_rol` (`nombre_rol`);

--
-- Indices de la tabla `tipo_activo`
--
ALTER TABLE `tipo_activo`
  ADD PRIMARY KEY (`id_tipo_activo`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `tipo_mantenimiento`
--
ALTER TABLE `tipo_mantenimiento`
  ADD PRIMARY KEY (`id_tipo_mantenimiento`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `ubicacion`
--
ALTER TABLE `ubicacion`
  ADD PRIMARY KEY (`id_ubicacion`),
  ADD UNIQUE KEY `uq_ubicacion_nombre` (`nombre`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `usuario` (`usuario`),
  ADD KEY `id_rol` (`id_rol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `activo`
--
ALTER TABLE `activo`
  MODIFY `id_activo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `asignacion_activo`
--
ALTER TABLE `asignacion_activo`
  MODIFY `id_asignacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT de la tabla `estado_activo`
--
ALTER TABLE `estado_activo`
  MODIFY `id_estado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `mantenimiento`
--
ALTER TABLE `mantenimiento`
  MODIFY `id_mantenimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `responsable`
--
ALTER TABLE `responsable`
  MODIFY `id_responsable` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `rol`
--
ALTER TABLE `rol`
  MODIFY `id_rol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `tipo_activo`
--
ALTER TABLE `tipo_activo`
  MODIFY `id_tipo_activo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `tipo_mantenimiento`
--
ALTER TABLE `tipo_mantenimiento`
  MODIFY `id_tipo_mantenimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `ubicacion`
--
ALTER TABLE `ubicacion`
  MODIFY `id_ubicacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `activo`
--
ALTER TABLE `activo`
  ADD CONSTRAINT `activo_ibfk_1` FOREIGN KEY (`id_tipo_activo`) REFERENCES `tipo_activo` (`id_tipo_activo`) ON UPDATE CASCADE,
  ADD CONSTRAINT `activo_ibfk_2` FOREIGN KEY (`id_ubicacion`) REFERENCES `ubicacion` (`id_ubicacion`) ON UPDATE CASCADE,
  ADD CONSTRAINT `activo_ibfk_3` FOREIGN KEY (`id_responsable`) REFERENCES `responsable` (`id_responsable`) ON UPDATE CASCADE,
  ADD CONSTRAINT `activo_ibfk_4` FOREIGN KEY (`id_estado`) REFERENCES `estado_activo` (`id_estado`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `asignacion_activo`
--
ALTER TABLE `asignacion_activo`
  ADD CONSTRAINT `fk_asignacion_activo` FOREIGN KEY (`id_activo`) REFERENCES `activo` (`id_activo`),
  ADD CONSTRAINT `fk_asignacion_responsable` FOREIGN KEY (`id_responsable`) REFERENCES `responsable` (`id_responsable`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_asignacion_ubicacion` FOREIGN KEY (`id_ubicacion`) REFERENCES `ubicacion` (`id_ubicacion`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `mantenimiento`
--
ALTER TABLE `mantenimiento`
  ADD CONSTRAINT `mantenimiento_ibfk_1` FOREIGN KEY (`id_activo`) REFERENCES `activo` (`id_activo`) ON UPDATE CASCADE,
  ADD CONSTRAINT `mantenimiento_ibfk_2` FOREIGN KEY (`id_tipo_mantenimiento`) REFERENCES `tipo_mantenimiento` (`id_tipo_mantenimiento`) ON UPDATE CASCADE,
  ADD CONSTRAINT `mantenimiento_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
